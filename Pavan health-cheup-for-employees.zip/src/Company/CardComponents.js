import * as React from 'react';
import Card from '@mui/material/Card';
import Grid from '@mui/material/Unstable_Grid2';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import Container from '@mui/material/Container';
import ImageList from '@mui/material/ImageList';
import ImageListItem from '@mui/material/ImageListItem';
import AddEmployeeimg from '../CompanyIcons/AddEmployee.png'
import ModifyEmployeeimg from '../CompanyIcons/ModifyEmployee.jpg'
import SetPolicyimg from '../CompanyIcons/SetPolicy.png'
import ChangePolicyimg from '../CompanyIcons/ChangePolicy.jpg'
import AddAgencyimg from '../CompanyIcons/AddAgency.png'
import ModifyAgencyimg from '../CompanyIcons/ModifyAgency.jpg'
import VerifyPolicyUsedimg from '../CompanyIcons/VerifyPolicyUsed.png'
import CheckStatus from '../CompanyIcons/CheckStatus.png'
import { Link } from 'react-router-dom';






export default function Cards() {


    let cards = [
        {
            title: "Add Employees",
            image: AddEmployeeimg,
            link: '/addEmployees',
            id: 1
        },
        {
            title: "Modify Employee",
            image: ModifyEmployeeimg,
            link: '/modifyEmployee',
            id: 2
        },
        {
            title: "Set Policy",
            image: SetPolicyimg,
            link: '/setPolicy',
            id: 3
        },
        {
            title: "Modify Policy",
            image: ChangePolicyimg,
            link: '/modifyPolicy',
            id: 4
        },  
        {
            title: "Verify Policies",            
            image: VerifyPolicyUsedimg,
            link: '/ViewPolicies',
            id: 5
        }, 
        {
            title: "Add  Insurance Agency",        
            image: AddAgencyimg,
            link: '/addAgency',
            id: 6
        }, 
        {
            title: "Modify Insurance Agency",           
            image: ModifyAgencyimg,
            link: '/modifyAgency',
            id: 7
        }, 
        {
            title: "Verify Policy Used",            
            image: CheckStatus,
            link: '/verifyPolicyUsed',
            id: 8
        }, 
        
// 3023628576
//  2993 normal 360
// 3793 hd 360
// 1799 1693  hd 6months

    ]


    return (
       <React.Fragment >
      <Grid   sx={{
            marginTop: 1,
            display: 'flex',
            flexDirection: 'column',
            marginLeft : 3,
            color:'black'
            // alignItems: 'center',
          }}>
       <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 1 }} 
       > 
       Welcome To 'We Success' Home Page
       </Typography> 
         </Grid>
        <Container sx={{ py: 4 }} maxWidth="lg">
            <Grid container spacing={1}>
                {cards.map((card) => (
                    <Grid item key={card.id} xs={12} sm={6} md={4} lg={3}>
                        <CardActionArea  component={Link} to={card.link} boxShadow={10}>
                            <Card sx={{ height: '80%', display: 'flex', flexDirection: 'column',  justifyContent:'center', alignItems:'center' }}>
                                <ImageList sx={{ width: 200, m: 3 }}>
                                    <ImageListItem>
                                        <img src={card.image} alt="Google" />
                                    </ImageListItem>
                                </ImageList>
                                <CardContent sx={{ flexGrow: 1 }}>
                                    <Typography gutterBottom variant="h5" component="h2" sx={{textAlign:'center'}}>
                                        {card.title}
                                    </Typography>
                                
                                </CardContent>
                            </Card>
                        </CardActionArea>
                    </Grid>
                ))}
            </Grid>
        </Container>
        </React.Fragment>
    );
}



