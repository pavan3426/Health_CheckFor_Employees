import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { useState,useEffect } from 'react';
import ClearIcon from '@mui/icons-material/Clear';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import { MenuItem } from '@material-ui/core';
import UpdateIcon from '@mui/icons-material/Update';
import Navbar from '../NavBar';
import axios from 'axios';
import SearchIcon from '@mui/icons-material/Search'
import { Stack, colors } from '@mui/material';

export default function ModifyEmployee() {
  const [CompanyName, setCompanyName] = useState(window.sessionStorage.getItem('organizationName'));
  const [EmployeeName, setEmployeeName] = useState("");
  const [EmployeeId, setEmployeeId] = useState("");
  const [RoleName, setRoleName] = useState("");
  const [ContactNumber, setContactNumber] = useState("");
  const [PermanentAddress, setPermanentAddress] = useState("");
  const [TemporaryAddress, setTemporaryAddress] = useState("");
  const[AadharNumber,setAadharNumber]=useState("");
  const [EmpList, setEmpList] = useState([]);
  const [isSnackbarOpen, setIsSnackbarOpen] = React.useState(false);
  const [SnackbarMessage, setSnackbarMessage] = React.useState('')
  const [isPolicySelected, setisPolicySelected] = useState(false);
  const [isErrorSnackbarOpen, setIsErrorSnackbarOpen] = React.useState(false);
  const [errorSnackbarMessage, setErrorSnackbarMessage] = React.useState('');


 const change =(e) => {
    const selectedEmployeeId = e.target.value;
    setEmployeeId(selectedEmployeeId);

    const selectedEmployee = EmpList.find((emp) => emp.employeeId === selectedEmployeeId);
    if (selectedEmployee) {
      setEmployeeName(selectedEmployee.employeeName);
      setContactNumber(selectedEmployee.contactNumber);
      setPermanentAddress(selectedEmployee.permanentAddress);
      setTemporaryAddress(selectedEmployee.temporaryAddress);
      setRoleName(selectedEmployee.roleName);
      setAadharNumber(selectedEmployee.aadharNumber);
      setisPolicySelected(true);
    }
   
    

 }
 const getRoles ={
  roleName:RoleName,
  companyName :CompanyName
};

const SearchEmployee =(e) => {

  const empDetails={
    companyName:CompanyName,
    employeeId:EmployeeId
  };
  // console.log(empDetails);
    
  axios
  .post("http://localhost:3426/Company/getEmployeeDetails", empDetails)
  .then((response) => {
    // console.log(response.data);
    setEmployeeName(response.data.employeeName);
      setContactNumber(response.data.contactNumber);
      setPermanentAddress(response.data.permanentAddress);
      setTemporaryAddress(response.data.temporaryAddress);
      setRoleName(response.data.roleName);
      setAadharNumber(response.data.aadharNumber);
  })
  .catch((error) => {
    setIsErrorSnackbarOpen(true);
    setErrorSnackbarMessage(`Employee Id is Not Found`);
});
  
    };

 
  function submitHandler(event) {
    event.preventDefault();
    const UpdatedEmployee = {
      companyName:CompanyName,
      employeeId:EmployeeId,
      employeeName:EmployeeName,
      
      roleName:RoleName,
      contactNumber:ContactNumber,
      permanentAddress: PermanentAddress,
      temporaryAddress:TemporaryAddress,
      aadharNumber:AadharNumber
    };

    axios
    .post("http://localhost:3426/Company/updateEmployee",UpdatedEmployee)
    .then((response) => {
      // console.log(UpdatedEmployee);
      setEmployeeName("");
      setEmployeeId("");
      setContactNumber("");
      
      setRoleName("");
      setTemporaryAddress("");
      setPermanentAddress("");
      setAadharNumber("");
    })
    setSnackbarMessage("Employee Updated Successfully")
    setIsSnackbarOpen(true);
    
};


  

  const handleSnackbarClose = () => {
    setIsSnackbarOpen(false);
  };

  const resetFields = () => {
    setEmployeeName("");
    setEmployeeId("");
    setContactNumber("");
   
    setRoleName("");
    setPermanentAddress("");
    setTemporaryAddress("");
    setAadharNumber("");
  };

  return (
    <React.Fragment>
      <Navbar />
      <Container component="main" maxWidth="md">
        <Box
          sx={{
            marginTop: 2,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            boxShadow: 8
          }}
        >
          <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 4 }}>
            Modify Employee
          </Typography>

          <Box component="form" sx={{ mt: 1, width: '100%', maxWidth: '700px' }} onSubmit={submitHandler}>
            <Grid container spacing={2} justifyContent="center">
            
            <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  id="CompanyName"
                  label="Company Name"
                  size='small'
                  onChange={(e) => setCompanyName(e.target.value)}
                  value={CompanyName}
                  aria-readonly
                />
              </Grid>

                <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  id="EmployeeId"
                  label="Employee Id"
                  size='small'
                  onChange={(e) => setEmployeeId(e.target.value.toUpperCase())}
                  value={EmployeeId}
                >
                  
                </TextField>
              </Grid>

              <Grid item xs={4}>
                    <Button
                       variant="contained"
                       endIcon={<SearchIcon />}
                       onClick={SearchEmployee}
                       
                    >
                      Find Employee
                    </Button>

              </Grid>
                 
              <Grid item xs={6}>
                <TextField
                  required
                  fullWidth
                  id="EmployeeName"
                  label="Employee Name"
                  onChange={(e) => setEmployeeName(e.target.value)}
                  value={EmployeeName}
                  size='small'
                />
              </Grid>
                            
            
              <Grid item xs={6}>
                <TextField
                  required
                  fullWidth
                  id="RoleName"
                  label="Role Name"
                  size='small'
                  onChange={(e) => setRoleName(e.target.value)}
                  value={RoleName}
                />
              </Grid>
              
              <Grid item xs={6}>
                <TextField
                  required
                  fullWidth
                  id="ContactNumber"
                  label="Contact Number"
                  size='small'
                  onChange={(e) => setContactNumber(e.target.value)}
                  value={ContactNumber}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  required
                  fullWidth
                  id="AadharNumber"
                  label="Aadhar Number"
                  size='small'
                  onChange={(e) => setAadharNumber(e.target.value)}
                  value={AadharNumber}
                  />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="PermanentAddress"
                  label="Permanent Address"
                  size='small'
                  onChange={(e) => setPermanentAddress(e.target.value)}
                  value={PermanentAddress}
                />
              </Grid>
               
         

              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="Temparory Address"
                  label="Temporary Address"
                  size='small'
                  onChange={(e) => setTemporaryAddress(e.target.value)}
                  value={TemporaryAddress}
                />
              </Grid>

             
                 
              
            </Grid>
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2, mb: 4 }}>
              <Button
                type="reset"
                variant="contained"
                endIcon={<ClearIcon />}
                sx={{ mr: 2 }}
                onClick={resetFields}
              >
                Reset
              </Button>
              <Button
                type="submit"
                variant="contained"
                endIcon={<UpdateIcon />}
              >
               Modify Employee
              </Button>
            </Box>
          </Box>
        </Box>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={3000}
          onClose={handleSnackbarClose}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MuiAlert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
            {SnackbarMessage}
          </MuiAlert>
        </Snackbar>

        <Snackbar
        open={isErrorSnackbarOpen}
        autoHideDuration={3000}
        onClose={() => setIsErrorSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <MuiAlert onClose={() => setIsErrorSnackbarOpen(false)} severity="warning" sx={{ width: '100%' }}>
          {errorSnackbarMessage}
        </MuiAlert>
      </Snackbar>

      </Container>
    </React.Fragment>
  );
}

