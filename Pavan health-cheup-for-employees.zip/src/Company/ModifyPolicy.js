import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { useState, useEffect } from 'react';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import ClearIcon from '@mui/icons-material/Clear';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import { MenuItem, Select } from '@material-ui/core';
import axios from 'axios';

import Navbar from '../NavBar';

const ModifyPolicy = () => {
  const CompanyName = window.sessionStorage.getItem('organizationName');
  const [RoleName, setRoleName] = useState("");
  const [PolicyName, setPolicyName] = useState("");
  const [PolicyDescription, setPolicyDescription] = useState("");
  const [rolesList, setRolesList] = useState([]);
  const [isSnackbarOpen, setIsSnackbarOpen] = React.useState(false);
  const [SnackbarMessage, setSnackbarMessage] = React.useState('')


  useEffect(() => {
    axios
      .get("http://localhost:3426/Company/getAllRoles")
      .then((response) => {
        if (response.data && Array.isArray(response.data)) {
          // const roleList = response.data;
          const roleNames = response.data.map((role) => role);
          setRolesList(roleNames);
        } else {
          console.error("Invalid response format or roles data not found.");
        }
      })
      .catch((error) => {
        // console.error("Error fetching roles:", error);
      });
  }, []);


  // const handleChange = (e) => {
  //   setRoleName(e.target.value);
  // };

  const resetFields = () => {
    setRoleName("");
    setPolicyName("");
    setPolicyDescription("");
  };

  const handleSnackbarClose = () => {
    setIsSnackbarOpen(false);
  };

  function submitHandler(event) {
    event.preventDefault();

    const newPolicy={
      companyName:CompanyName,
      roleName :RoleName,
     policy :[
               {
                policyName : PolicyName,
                 policyDescription : PolicyDescription
              }
            ],
       };

    console.log(newPolicy);
      // Make an HTTP POST request to send data to Spring backend  with the actual backend endpoint URL for adding roles
      console.log('Data from UI:', newPolicy);
      axios
        .post('http://localhost:3426/Policy/setPolicy', newPolicy)
        .then((response) => {
     // Handle the response from the backend (if needed)
      
          setRoleName("");
          setPolicyName("");
          setPolicyDescription("");
          setSnackbarMessage("Existing Policy Updated Successfully")
          setIsSnackbarOpen(true);
        })
        .catch((error) => {
          // Handle errors (if any)
          //  console.error('Error sending data:', error);
          setSnackbarMessage('An error occurred while adding the role');
          setIsSnackbarOpen(true);
        });
    }





  return (
    <React.Fragment>
      <Navbar />
      <Container component="main" maxWidth="md">
        <Box
          sx={{
            marginTop: 8,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            boxShadow: 8
          }}
        >
          <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 4 }}>
            Modify  Policy For Roles
          </Typography>

          <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '600px' }} onSubmit={submitHandler}>
            <Grid container spacing={2} justifyContent="center">

            
            <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    id="CompanyName"
                    // label="Company Name"
                    // onChange={(e) => setCompanyName(e.target.value)}
                    value={CompanyName}
                    size='small'
                    aria-readonly
                  />
                </Grid>

              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  displayEmpty
                  value={RoleName}
                  id="RoleName"
                  size='small'
                  label="Role Name"
                  select
                  onChange={(e) => setRoleName(e.target.value)} // Handle role name selection
                  // onChange={handleChange}
                >
                  <MenuItem value="">Select Role</MenuItem>
                  {rolesList.map((role) => (
                    <MenuItem value={role} key={role}>
                      {role} {/* Display the role name here */}
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="PolicyName"
                  label="Policy Name"
                  onChange={(e) => setPolicyName(e.target.value)}
                  value={PolicyName}
                  size='small'
                />
              </Grid>

              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="PolicyDescription"
                  label="Policy Description"
                  onChange={(e) => setPolicyDescription(e.target.value)}
                  value={PolicyDescription}
                  size='small'
                />
              </Grid>

            </Grid>

            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2, mb: 4 }}>
              <Button
                type="reset"
                variant="contained"
                endIcon={<ClearIcon />}
                sx={{ mr: 2 }}
                onClick={resetFields}
              >
                Reset
              </Button>
              <Button
                type="submit"
                variant="contained"
                endIcon={<PersonAddIcon />}
              >
                Modify Policy
              </Button>
            </Box>
          </Box>
        </Box>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={3000}
          onClose={handleSnackbarClose}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MuiAlert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
            {SnackbarMessage}
          </MuiAlert>
        </Snackbar>
      </Container>
    </React.Fragment>
  )
}

export default ModifyPolicy;
