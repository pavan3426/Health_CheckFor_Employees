import React from "react";
import Grid from '@mui/material/Unstable_Grid2';
import Navbar from "../NavBar";
import Cards from "./CardComponents";


const CompanyHomePage =()=>
{
    return(
        <Grid item xs={6} md={3} style={{ color: 'white', backgroundColor: '#F5F5F5' }}>
            <Navbar></Navbar>
            <Cards></Cards>
        </Grid>
    )
}

export default CompanyHomePage;