import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { useState, useEffect } from 'react';
import SearchIcon from '@mui/icons-material/Search';
import ClearIcon from '@mui/icons-material/Clear';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import { MenuItem } from '@material-ui/core';
import UpdateIcon from '@mui/icons-material/Update';
import Navbar from '../NavBar';
import axios from 'axios';
import { Stack, TablePagination } from '@mui/material';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  FormControl,
  InputLabel

} from '@mui/material';

const ViewPolicies = () => {
  const CompanyName = window.sessionStorage.getItem('organizationName');
  const [RoleName, setRoleName] = useState("");
  const [PolicyName, setPolicyName] = useState("");
  const [PolicyDescription, setPolicyDescription] = useState("");
  const [rolesList, setRolesList] = useState([]);
  const [PoliciesList, setPoliciesList] = useState([]);
  const [isSnackbarOpen, setIsSnackbarOpen] = React.useState(false);
  const [SnackbarMessage, setSnackbarMessage] = React.useState('')
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  useEffect(() => {
    axios
      .get("http://localhost:3426/Company/getAllRoles")
      .then((response) => {
        if (response.data && Array.isArray(response.data)) {
          // const roleList = response.data;
          const roleNames = response.data.map((role) => role);
          setRolesList(roleNames);
        } else {
          console.error("Invalid response format or roles data not found.");
        }
      })
      .catch((error) => {
        console.error("Error fetching roles:", error);
      });
  }, []);

  const resetFields = () => {
    setRoleName("");
    setPolicyName("");
    setPoliciesList([])
  };
  const roleSelect = (e) => {
    // setRoleName("");
    setPolicyDescription("");
    const policyEO = {
      roleName: RoleName,
      companyName: CompanyName

    }
    //  console.log(policyEO);
    axios
      .post("http://localhost:3426/Policy/getPolicies", policyEO)
      .then((response) => {
        setPoliciesList(response.data);
        console.log(response.data);

      })
      .catch((error) => {
        console.error("Error fetching roles:", error);
      });
  }

  const handleSnackbarClose = () => {
    setIsSnackbarOpen(false);
  };





  return (
    <React.Fragment>
      <Navbar />
      <Container component="main" maxWidth="md">
        <Box
          sx={{
            marginTop: 3,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            boxShadow: 8
          }}
        >
          <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 4 }}>
            View  Policies
          </Typography>

          <Box component="form" sx={{ mt: 3, width: '100%' }}  >
            <Grid container spacing={2} justifyContent="center" padding={2}  >

              <Grid item xs={4}  >
                <TextField
                  required
                  fullWidth
                  id="CompanyName"
                  // label="Company Name"
                  // onChange={(e) => setCompanyName(e.target.value)}
                  value={CompanyName}
                  size='small'
                  aria-readonly
                />
              </Grid>


              <Grid item xs={4}>
                {/* <Stack spacing={2} direction="row" alignItems="center" justifyContent="space-between"> */}
                <TextField
                  required
                  fullWidth
                  //   displayEmpty
                  value={RoleName}
                  id="RoleName"
                  size='small'
                  label="Role Name"
                  select
                  onChange={(e) => {
                    setRoleName(e.target.value);
                    // roleSelect(e);
                  }}
                >
                  <MenuItem value="">Select Role</MenuItem>
                  {rolesList.map((role) => (
                    <MenuItem value={role} key={role}>
                      {role}
                    </MenuItem>
                  ))}
                </TextField>
              </Grid>
              <Grid item xs={4}>
                <Button

                  variant="contained"
                  color="secondary"
                  //    sx={{ width: '400px'}}
                  endIcon={<SearchIcon />}
                  onClick={roleSelect}
                >
                  Search
                </Button>
              </Grid>



              <Grid container spacing={2} sx={{mt:3}}>


                {PoliciesList.length > 0 && (
                  <Grid item xs={12} sx={{ maxWidth: '100%', mb: '5px', mt: '8px', ml: 3, mr: 3 }}>

                    <TableContainer component={Paper}>
                      <Table>
                        <TableHead>
                          <TableRow>
                            <TableCell style={{ fontWeight: 'bold', padding: '8px', color: 'black', backgroundColor: '#808080' }}>
                              <Typography variant="subtitle1">Policy Name</Typography>
                            </TableCell>
                            <TableCell style={{ fontWeight: 'bold', padding: '8px', color: 'black', backgroundColor: '#808080' }}>
                              <Typography variant="subtitle1">Policy Description</Typography>
                            </TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {PoliciesList
                            .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            .map((policy) => (
                              <TableRow key={policy.policyName}>
                                <TableCell style={{ padding: '8px' }}>{policy.policyName}</TableCell>
                                <TableCell style={{ padding: '8px' }}>{policy.policyDescription}</TableCell>
                              </TableRow>
                            ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    <TablePagination
                      rowsPerPageOptions={[10, 25, 100]}
                      component="div"
                      count={PoliciesList.length}
                      rowsPerPage={rowsPerPage}
                      page={page}
                      onPageChange={handleChangePage}
                      onRowsPerPageChange={handleChangeRowsPerPage}
                    />
                  </Grid>
                )}
              </Grid>

              <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2, mb: 4 }}>
                <Button
                  type="reset"
                  variant="contained"
                  endIcon={<ClearIcon />}
                  sx={{ mr: 2 }}
                  onClick={resetFields}
                >
                  Reset
                </Button>

              </Box>
            </Grid>
          </Box>
        </Box>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={3000}
          onClose={handleSnackbarClose}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MuiAlert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
            {SnackbarMessage}
          </MuiAlert>
        </Snackbar>
      </Container>
    </React.Fragment>
  )
}
export default ViewPolicies
