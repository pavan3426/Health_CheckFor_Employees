import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { useState } from 'react';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import ClearIcon from '@mui/icons-material/Clear';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import { MenuItem } from '@material-ui/core';
import Navbar from '../NavBar';
import axios from 'axios';
const AddAgency = () => {
  const CompanyName = "We Success";
  const [AgencyName, setAgencyName] = useState("");
  const [InsuranceAgencyId, setInsuranceAgencyId] = useState("");
  const [AgencyAddress,setAgencyAddress] = useState("");
  const [isSnackbarOpen, setIsSnackbarOpen] = React.useState(false);
  const [SnackbarMessage, setSnackbarMessage] = React.useState('')

  const resetFields = () => {
      // setCompanyName("");
      setAgencyName("");
      setInsuranceAgencyId("");
      setAgencyAddress("");
  };

  const handleSnackbarClose = () => {
    setIsSnackbarOpen(false);
  };

  function submitHandler(event) {
    event.preventDefault();
    const newInsuranceAgency ={
      companyName : CompanyName,
      agencyName : AgencyName,
      insuranceAgencyId : InsuranceAgencyId,
      agencyAddress : AgencyAddress
    };

    axios
    .post("http://localhost:3426/Agency/addAgency",newInsuranceAgency)
    .then((response) => {
      console.log(newInsuranceAgency);
      // setCompanyName("");
      setAgencyName("");
      setInsuranceAgencyId("");
      setAgencyAddress("");
      setSnackbarMessage('Successfully Collaborate with new Agency');
      setIsSnackbarOpen(true);
    })
    .catch((error) => {
      // Handle errors (if any)
       console.error('Error sending data:', error);
       console.log(newInsuranceAgency);
      setSnackbarMessage('An error occurred while adding the Agency');
      setIsSnackbarOpen(true);
    });
  };

  return (
    <React.Fragment>
      <Navbar />
      <Container component="main" maxWidth="md">
        <Box
          sx={{
            marginTop: 8,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            boxShadow: 8
          }}
        >
          <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 4 }}>
            Add Health Insurance Agency
          </Typography>
          
            <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '600px' }}  onSubmit={submitHandler}>
              <Grid container spacing={2} justifyContent="center">
                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    id="CompanyName"
                    label="Company Name"
                    // onChange={(e) => setCompanyName(e.target.value)}
                    value={CompanyName}
                    size='small'
                    aria-readonly
                  />
                </Grid>

                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    id="AgencyName"
                    label="Agency Name"
                    onChange={(e) => setAgencyName(e.target.value.toUpperCase())}
                    value={AgencyName}
                    size='small'
                    // inputProps={{style:{textTransform:"uppercase"}}}
                  />
                </Grid>

                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    id="InsuranceAgencyId"
                    label="Insurance Agency Id"
                    onChange={(e) => setInsuranceAgencyId(e.target.value.toUpperCase())}
                    value={InsuranceAgencyId}
                    size='small'
                  />
                </Grid>

                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    id="AgencyAddress"
                    label="Agency Address"
                    onChange={(e) => setAgencyAddress(e.target.value)}
                    value={AgencyAddress}
                    size='small'
                  />
                </Grid>

              </Grid>
            
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2, mb: 4 }}>
              <Button
                type="reset"
                variant="contained"
                endIcon={<ClearIcon />}
                sx={{ mr: 2 }}
                onClick={resetFields}
              >
                Reset
              </Button>
              <Button
                type="submit"
                variant="contained"
                endIcon={<PersonAddIcon />}
              >
                Add Agency
              </Button>
              </Box>
            </Box>
          </Box>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={3000}
          onClose={handleSnackbarClose}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MuiAlert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
            {SnackbarMessage}
          </MuiAlert>
        </Snackbar>
      </Container>
    </React.Fragment>
  )
}

export default AddAgency;
