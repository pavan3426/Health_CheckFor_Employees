import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { useState } from 'react';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import ClearIcon from '@mui/icons-material/Clear';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import { MenuItem } from '@material-ui/core';
import Navbar from '../NavBar';
import axios from 'axios';

export default function AddEmployee() {
  const [CompanyName, setCompanyName] = useState(window.sessionStorage.getItem('organizationName'));
  const [employeeName, setEmployeeName] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  // const [policyName, setPolicyName] = useState("");
  const [roleName, setRoleName] = useState("");
  const [contactNumber, setContactNumber] = useState("");
  const [PermanentAddress, setPermanentAddress] = useState("");
  const [TemporaryAddress, setTemporaryAddress] = useState("");
  const [AadharNumber, setAadharNumber] = useState("");
  const[editableData,setEditableData] = useState("");
  const [isSnackbarOpen, setIsSnackbarOpen] = React.useState(false);
  const [SnackbarMessage, setSnackbarMessage] = React.useState('')

  function submitHandler(event) {
    event.preventDefault();
    const newEmployee = {
      companyName: CompanyName,
      employeeId: employeeId,
      employeeName: employeeName,
      roleName: roleName,
      contactNumber: contactNumber,
      aadharNumber: AadharNumber,
      permanentAddress: PermanentAddress,
      temporaryAddress: TemporaryAddress

    };
    // console.log(newEmployee);
    // Make an HTTP POST request to send data to Spring backend  with the actual backend endpoint URL for adding roles
    axios
      .post('http://localhost:3426/Company/addEmployee', newEmployee)
      .then((response) => {
        // Handle the response from the backend (if needed)
        // console.log('Data from frontend:', response.data);

        setEmployeeName("");
        setEmployeeId("");
        setContactNumber("");

        setRoleName("");
        setTemporaryAddress("");
        setPermanentAddress("");
        setAadharNumber("");
        setSnackbarMessage('New Employee added successfully');
        setIsSnackbarOpen(true);
      })
      .catch((error) => {

        setSnackbarMessage('Employee with Id already there in company');
        setIsSnackbarOpen(true);
      });
  };
  const isAadhaarCardValid = (value) => {

    const aadhaarCardRegex = /^\d{4}\s\d{4}\s\d{4}$/;

    return aadhaarCardRegex.test(value);

  };



  const formatAadharNumber = (value) => {
    // Remove any non-digit characters from the input
    const cleanedValue = value.replace(/\D/g, '');
    // Format the cleaned value in "xxxx xxxx xxxx" format
    const formattedValue = cleanedValue.replace(/(\d{4})(?=\d)/g, '$1 ');
    return formattedValue;
  };

  const handleAadharNumberChange = (event) => {
    const { value } = event.target;
    const formattedAadharNumber = formatAadharNumber(value);
    setAadharNumber(formattedAadharNumber);
  };

  const handleSnackbarClose = () => {
    setIsSnackbarOpen(false);
  };


  const resetFields = () => {
    setEmployeeName("");
    setEmployeeId("");
    setContactNumber("");

    setRoleName("");
    setTemporaryAddress("");
    setPermanentAddress("");
    setAadharNumber("");

  };

  return (
    <React.Fragment>
      < Navbar />
      <Container component="main" maxWidth="md">
        <Box
          sx={{
            marginTop: 8,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            boxShadow: 8
          }}
        >
          <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 4 }}>
            Add Employee
          </Typography>

          <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '600px' }} onSubmit={submitHandler}>
            <Grid container spacing={2} justifyContent="center">

              <Grid item xs={6}>
                <TextField
                  required
                  fullWidth
                  id="CompanyName"
                  label="Company Name"
                  size='small'
                  onChange={(e) => setCompanyName(e.target.value)}
                  value={CompanyName}
                  aria-readonly
                />
              </Grid>

              <Grid item xs={6}>
                <TextField
                  required
                  fullWidth
                  id="EmployeeId"
                  label="Employee Id"
                  onChange={(e) => setEmployeeId(e.target.value)}
                  value={employeeId}
                  size='small'
                />
              </Grid>

              <Grid item xs={6}>
                <TextField
                  required
                  fullWidth
                  id="EmployeeName"
                  label="Employee Name"
                  onChange={(e) => setEmployeeName(e.target.value)}
                  value={employeeName}
                  size='small'
                />
              </Grid>


              <Grid item xs={6}>
                <TextField
                  required
                  fullWidth
                  id="RoleName"
                  label="Role Name"
                  size='small'
                  onChange={(e) => setRoleName(e.target.value)}
                  value={roleName}
                />
              </Grid>

              <Grid item xs={6}>
                <TextField
                  required
                  fullWidth
                  id="ContactNumber"
                  label="Contact Number"
                  size='small'
                  onChange={(e) => setContactNumber(e.target.value)}
                  value={contactNumber}
                />
              </Grid>


              <Grid item xs={6}>
              <TextField
                label="Aadhar Number"
                name="AadharNumber"
                value={AadharNumber}
                onChange={handleAadharNumberChange}
                required
                fullWidth
                size='small'
                inputProps={{

                  maxLength: 14, // Limit the input to 14 characters (including spaces)

              }}

              error={AadharNumber !== '' && !isAadhaarCardValid(AadharNumber)}

              helperText={AadharNumber !== '' && !isAadhaarCardValid(AadharNumber) ? ' Eg:-1234 5678 9012' : ''}
              />
            </Grid> 

              {/* <Grid item xs={6}>
                <TextField
                  required
                  fullWidth
                  id="AadharNumber"
                  label="Aadhar Number"
                  size='small'
                  onChange={(e) => setAadharNumber(e.target.value)}
                  value={AadharNumber}
                  />
              </Grid> */}

              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="PermanentAddress"
                  label="Permanent Address"
                  size='small'
                  onChange={(e) => setPermanentAddress(e.target.value)}
                  value={PermanentAddress}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="Temparory Address"
                  label="Temporary Address"
                  size='small'
                  onChange={(e) => setTemporaryAddress(e.target.value)}
                  value={TemporaryAddress}
                />
              </Grid>

            </Grid>
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2, mb: 4 }}>
              <Button
                type="reset"
                variant="contained"
                endIcon={<ClearIcon />}
                sx={{ mr: 2 }}
                onClick={resetFields}
              >
                Reset
              </Button>
              <Button
                type="submit"
                variant="contained"
                endIcon={<PersonAddIcon />}
              >
                Add Employee
              </Button>
            </Box>
          </Box>
        </Box>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={3000}
          onClose={handleSnackbarClose}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MuiAlert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
            {SnackbarMessage}
          </MuiAlert>
        </Snackbar>
      </Container>
    </React.Fragment>
  );
}

