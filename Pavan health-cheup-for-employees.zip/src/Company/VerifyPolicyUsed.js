
import * as React from 'react';
import { useState } from 'react';
import TextField from '@mui/material/TextField';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import { Radio, RadioGroup, FormLabel, FormControlLabel, TablePagination } from '@mui/material';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Navbar from '../NavBar';
import Button from '@mui/material/Button';
import axios from 'axios';
import { Stack } from '@mui/material';
import { parseISO, format } from 'date-fns';


const VerifyPolicyUsed = () => {
  const [Status, setStatus] = useState("");
  const [filteredRows, setFilteredRows] = useState([]);
  const companyName = window.sessionStorage.getItem('organizationName');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [tableData, setTableData] = useState([]);
  const [appointList, setAppointList] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const headers = ['Employee Id', 'Employee Name', 'Mobile Number', 'Status', 'Policy', 'Date', 'Slot'];

  const filterAndSortData = (startDate, endDate) => {
    const filteredAndSortedData = tableData
      .filter(row => {
        const rowDate = parseISO(row.date);
        return rowDate >= parseISO(startDate) && rowDate <= parseISO(endDate);
      })
      .sort((a, b) => parseISO(a.date) - parseISO(b.date));

    return filteredAndSortedData;
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const fetchData = async () => {
    try {
      const dates = {
        StartDate: startDate,
        EndDate: endDate
      };

      const orgName = {
        companyName: window.sessionStorage.getItem('organizationName')
      };

      const response1 = await axios.get('http://localhost:3426/Company/all');
      setTableData(response1.data);
      // console.log("Comapny from axios", response1.data);
      const response2 = await axios.get('http://localhost:3430/Appointment/allAppointments');
      setAppointList(response2.data);

    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const clearTable = () => {
    setTableData([]);
    setStartDate('');
    setEndDate('');
  };


  return (
    <React.Fragment>
      <Navbar />
      <Container component="main" maxWidth="lg">
        <Box
          sx={{
            marginTop: 1,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            boxShadow: 8,
          }}
        >
          <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 2 }}>
            Check Employees Policy Status
          </Typography>
          <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '100%' }} >

            <Grid container spacing={2} justifyContent="center" >
              <Stack spacing={2} direction="row" alignItems="center" justifyContent="space-between">

                 {/* <TextField
                  required
                  fullWidth
                  id="startDate"
                  onChange={(e) => setStartDate(e.target.value)}
                  // style={{backgroundColor : '#f5f5dc' }}
                  value={startDate}
                  size='small'
                  type='date'
                  sx={{ width: 200 }}
                />
                <TextField
               
                  required
                  fullWidth
                  id="endDate"
                  onChange={(e) => setEndDate(e.target.value)}
                  value={endDate}
                  size='small'
                  type='date'
                  sx={{ width: 200 }}
                />  */}

                <Button variant="contained" color="primary" sx={{ width: 250 }}
                  onClick={fetchData}>
                  Fetch Data
                </Button>
                <Button variant="outlined" color="secondary" sx={{ width: 250 }} onClick={clearTable}>
                  Clear Table
                </Button>
              </Stack>
            </Grid>

            <Grid container spacing={2} justifyContent="center" marginTop={2} marginBottom={2}>
              {/* <Grid item xs={12} sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', ml: 2, mr:3 }}>
                
                 
              </Grid> */}

              <Grid item xs={12} sx={{ maxWidth: '100%', mb: '5px', ml: 3, mr: 3 }}>


                <TableContainer component={Paper}>
                  <Table aria-label="dynamic table" sx={{ maxWidth: '100%' }}>
                    <TableHead>
                      <TableRow>
                        {headers.map((header, index) => (
                          <TableCell key={index} sx={{ fontWeight: 'bold', fontSize: '14px', color: 'black', backgroundColor: '#808080' }}>
                            {header}
                          </TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {tableData
                        .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                        .map((row, rowIndex) => {
                          const appointRow = appointList.find((appointRow) => appointRow.employeeId === row.employeeId);
                          const isUsed = Boolean(appointRow);

                          const status = isUsed ? 'Used' : 'Not Used';

                          return (
                            <TableRow key={rowIndex}>
                              <TableCell sx={{ fontSize: '12px' }}>{row.employeeId}</TableCell>
                              <TableCell sx={{ fontSize: '12px' }}>{row.employeeName}</TableCell>
                              <TableCell sx={{ fontSize: '12px' }}>{row.contactNumber}</TableCell>
                              <TableCell sx={{ fontSize: '12px' }}>{status}</TableCell>
                              <TableCell sx={{ fontSize: '12px' }}>{(isUsed && appointRow.policyName) || row.policy || '-'}</TableCell>

                              <TableCell sx={{ fontSize: '12px' }}>
                                {(isUsed && format(parseISO(appointRow.date), 'dd-MM-yyyy')) || (row.date && format(parseISO(row.date), 'dd-MM-yyyy')) || '-'}
                              </TableCell>
                              <TableCell sx={{ fontSize: '12px' }}>
                                {(isUsed && appointRow.slot) || row.slot || '-'}
                              </TableCell>


                            </TableRow>
                          );
                        })}
                    </TableBody>
                  </Table>
                </TableContainer>
                <TablePagination
                  rowsPerPageOptions={[10, 25, 100]}
                  component="div"
                  count={tableData.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangeRowsPerPage}
                />




              </Grid>
            </Grid>
          </Box>
        </Box>
      </Container>
    </React.Fragment>
  );
};
export default VerifyPolicyUsed;



