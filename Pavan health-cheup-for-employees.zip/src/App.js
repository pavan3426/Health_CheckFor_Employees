import './App.css';
import LoginPage from './LoginPage';
import AddEmployee from './Company/AddEmployee';
import AddAgency from './Company/AddAgency';
import AddPolicy from './Company/AddPolicy';
import ModifyEmployee from './Company/ModifyEmployee';
import ModifyAgency from './Company/ModifyAgency';
import ModifyPolicy from './Company/ModifyPolicy';
import VerifyPolicyUsed from './Company/VerifyPolicyUsed';
import AddPartnerHospital from './InsuranceAgency/AddPartner';
import ModifyPartnerHospital from './InsuranceAgency/ModifyPartner';
import AddNewHospital from './Hospital/AddNewHospital';
import ModifyHospitalDetails from './Hospital/ModifyHospitalDetails';
import UpdatePatientDetails from './Hospital/UpdatePatientDetails';
import BookAppointment from './Empoyee/BookAppointment';
import CompanyHomePage from './Company/CompanyHomePage';
// import RoutesRoot from './Routes';
import RoutesRoot from './Routes';


function App() {
  return (
<div>
     {/* <LoginPage /> */}
     {/* <CompanyHomePage /> */}

    {/* <AddEmployee />  */}
    {/* <AddAgency /> */}
    {/* <AddPolicy /> */}
    {/* <ModifyEmployee /> */}
    {/* <ModifyAgency /> */}
    {/* <ModifyPolicy /> */}
    {/* <VerifyPolicyUsed /> */}
    {/* <AddPartnerHospital /> */}
    {/* <ModifyPartnerHospital /> */}
    {/* <AddNewHospital /> */}
    {/* <ModifyHospitalDetails /> */}
    {/* <UpdatePatientDetails /> */}
    {/* <BookAppointment /> */}
   {/* <VerifyPolicyUsed /> */}

   <RoutesRoot />


</div>
  
  );
}

export default App;
