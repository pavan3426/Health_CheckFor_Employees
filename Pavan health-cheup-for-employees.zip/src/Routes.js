import React from 'react';
// import * from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import CompanyHomePage from './Company/CompanyHomePage';
import AddEmployee from './Company/AddEmployee';
import ModifyEmployee from './Company/ModifyEmployee';
import AddPolicy from './Company/AddPolicy';
import ModifyPolicy from './Company/ModifyPolicy';
import AddAgency from './Company/AddAgency';
import ModifyAgency from './Company/ModifyAgency';
import VerifyPolicyUsed from './Company/VerifyPolicyUsed';
import HospitalHomePage from './Hospital/HospitalHomePage';
import AddNewHospital from './Hospital/AddNewHospital';
import ModifyHospitalDetails from './Hospital/ModifyHospitalDetails';
import UpdatePatientDetails from './Hospital/UpdatePatientDetails';
import InsuranceHomePage from './InsuranceAgency/InsuranceHomePage';
import ModifyPartnerHospital from './InsuranceAgency/ModifyPartner';
import AddPartnerHospital from './InsuranceAgency/AddPartner';
import EmployeeHomePage from './Empoyee/EmployeeHomePage';
import BookAppointment from './Empoyee/BookAppointment';
import CheckStatus from './Empoyee/CheckStatus';
import RescheduleAppointment from './Empoyee/RescheduleAppointment';
import CancelAppointment from './Empoyee/CancelAppointment';
import LoginPage from './LoginPage';
import CheckPolicies from './Empoyee/CheckPolicies';
import Bookings from './Hospital/Bookings';
import ViewPolicies from './Company/ViewPolicies';
import AppointmentRequests from './InsuranceAgency/AppointmentRequests';
import SearchAppointment from './InsuranceAgency/SearchAppointment';
import PoliciesByAgency from './InsuranceAgency/viewPoliciesByAgency';
import SearchEmployee from './InsuranceAgency/SearchEmployee';

const RoutesRoot = () => {
  return (
    <div>
            <BrowserRouter>

                <Routes>
                <Route exact path="/" element={ <LoginPage /> }></Route>
                    {/* CompanyHomePage */}
                    <Route  path ="/CompanyHomePage" element={ <CompanyHomePage /> }></Route> 
                    <Route path="/addEmployees" element={<AddEmployee />}></Route>
                    <Route path="/modifyEmployee" element={<ModifyEmployee />}></Route>
                    <Route path="/setPolicy" element={<AddPolicy/>}></Route>
                    <Route path="/modifyPolicy" element={<ModifyPolicy/>}></Route>
                    <Route path="/addAgency" element={<AddAgency/>}></Route>
                    <Route path="/modifyAgency" element={<ModifyAgency />}></Route>
                    <Route path="/verifyPolicyUsed" element={<VerifyPolicyUsed/>}></Route>
                    <Route path="/ViewPolicies" element={<ViewPolicies/>}></Route>
                    
                     
                     {/*  HospitalHomePage */ }

                     <Route  path="/HospitalHomePage" element={ <HospitalHomePage /> }></Route>
                     {/* <Route  path="/addNewHospital" element={ <AddNewHospital /> }></Route>
                     <Route  path="/modifyHospitalDetails" element={ <ModifyHospitalDetails /> }></Route> */}
                     <Route  path="/updatePatientStatus" element={ <UpdatePatientDetails /> }></Route>
                     <Route  path="/viewBookings" element={ <Bookings /> }></Route>
                    

                     Book2
                      {/* /* Insurance */}
                      {/* InsuranceHomePage */}
                     <Route path="/InsuranceHomePage" element={ <InsuranceHomePage /> }></Route>
                     <Route  path="/addPartnerHospital" element={ <AddPartnerHospital /> }></Route>
                     <Route  path="/modifyPartnerHospital" element={ <ModifyPartnerHospital /> }></Route>
                     <Route  path="/appointmentRequests" element={ <AppointmentRequests /> }></Route>
                     <Route  path="/searchAppointments" element={ <SearchAppointment /> }></Route>
                     <Route path="/viewPoliciesByAgency" element={<PoliciesByAgency />} />
                     <Route path="/searchEmployee" element={<SearchEmployee />} />
                     searchAppointments
                     
                     {/* EmployeeHomePage*/}

                     <Route  path="/EmployeeHomePage" element={ <EmployeeHomePage /> }></Route>
                     <Route  path="/bookAppointment" element={ <BookAppointment /> }></Route>
                     <Route  path="/rescheduleAppointment" element={ <RescheduleAppointment /> }></Route>
                     <Route path ="/Healthstatus" element={< CheckStatus/>}> </Route>
                     <Route path="/cancelAppointment" element ={ <CancelAppointment /> } ></Route>
                     <Route path="/CheckPolicies" element ={ <CheckPolicies /> } ></Route>

                     



                </Routes>
            </BrowserRouter>
    </div>
  )
}

export default RoutesRoot
