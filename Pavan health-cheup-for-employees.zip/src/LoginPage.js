import { useState } from "react";
import CssBaseline from "@mui/material/CssBaseline";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import FormControlLabel from "@mui/material/FormControlLabel";

import Link from "@mui/material/Link";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import {Routes,Route} from "react-router-dom";
// import AdminPage from "../Admin/AdminPage";



//use sesion storage for authentaction





const LoginPage = (props) => {

  const navigate = useNavigate();
  const [username, setusername] = useState("");
  const [password, setpassword] = useState("");
  const[organizationName,setOrganizationName] = useState("");
  const[roleName,setRoleName] = useState("");
  
  const handleSubmit = async (e) => {

    // Clear organizationName in sessionStorage
    sessionStorage.removeItem("organizationName");

    try {
      var response = await axios({
        method: "POST",
        url: "http://localhost:3426/LoginPage/getRoleAndOrganization",
        headers: { "content-type": "application/json" },
        data: {
          userName: username,
          password: password
        }
      });
  
      if (response && response.data) {
        const { roleName, organizationName } = response.data;
        setRoleName(roleName);
        setOrganizationName(organizationName);
  
        // Store organizationName in sessionStorage
        sessionStorage.setItem('organizationName', organizationName);
  
        // console.log(response.data);
  
        // Perform navigation based on roleName
        if (roleName === "COMPANY") {
          navigate("/CompanyHomePage");
        } else if (roleName === "HOSPITAL") {
          navigate("/HospitalHomePage");
        } else if (roleName === "AGENCY") {
          navigate("/InsuranceHomePage");
        } else if (roleName === "EMPLOYEE") {
          navigate("/EmployeeHomePage");
        }
      } 
      // else {
      //   alert("User credentials not found/mismatched");
      // }
    } catch (e) {
      // console.log(e);
      alert("Credentials Not Matched. Please Try Again!");
    }
  };
  



  return (
    <div>
      <Container component="main" maxWidth="lg">
        <Box
          sx={{
            marginTop: 8,
          }}
        >
          <Grid container>
            <CssBaseline />
            <Grid
              item
              xs={false}
              sm={4}
              md={7}
              sx={{
                backgroundImage: "url('./LoginPage.jpg')",
                backgroundRepeat: "no-repeat",
                backgroundSize: "cover",
                backgroundPosition: "center",
              }}
            />
            <Grid
              item
              xs={12}
              sm={8}
              md={5}
              component={Paper}
              elevation={6}
              square
            >
              <Box
                sx={{
                  my: 8,
                  mx: 4,
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
              >
                <Typography component="h1" variant="h5">
                Health Checkup for Employees
                </Typography>
                {/* <Typography component="h2" variant="h5" mt={2}>
                  Sign in
                </Typography> */}
                <Box
                  component="form"
                  noValidate

                  sx={{ mt: 1 }}
                >
                  <TextField
                    margin="normal"
                    required
                    fullWidth
                    id="userName"
                    label="UserName"
                    name="username"
                    autoComplete="enter username"
                    value={username}
                    onChange={(e) => setusername(e.target.value)}
                    autoFocus

                  />
                  <TextField
                    margin="normal"
                    required
                    fullWidth
                    name="password"
                    label="Password"
                    type="password"
                    id="password"
                    value={password}
                    onChange={(e) => setpassword(e.target.value)}
                    // autoComplete="current-password"
                   
                  />
                  {/* <FormControlLabel
                  control={<Checkbox value="remember" color="primary" />}
                  label="Remember me"
                /> */}
                  <Button
                    type="button"
                    fullWidth
                    variant="contained"
                    sx={{ mt: 3, mb: 2 }}
                    onClick={handleSubmit}
                  >
                    Sign In
                  </Button>
                 
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Box>
      </Container>
    </div>
  );
};



export default LoginPage;