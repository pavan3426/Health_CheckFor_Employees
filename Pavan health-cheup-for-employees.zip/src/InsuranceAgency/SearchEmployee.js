import React, { useState, useEffect } from 'react';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import axios from 'axios';
import { Card, TextField, CardContent } from '@mui/material';
import { Stack } from "@mui/material";
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import Navbar from '../NavBar';
import { Search } from '@material-ui/icons';
import { Clear } from '@material-ui/icons';

const SearchEmployee = () => {
    const[employeeId, setEmployeeId] = useState("");
    const [empDetails, setEmpDetails] = useState("");
    const [isErrorSnackbarOpen, setIsErrorSnackbarOpen] = React.useState(false);
    const [errorSnackbarMessage, setErrorSnackbarMessage] = React.useState('');
    const [applicationIdError, setApplicationIdError] = useState(false);
  const CancelData = () =>{
    setEmployeeId("");
    setEmpDetails("");
  }
    const fetchData = async () => {
        const empRef ={
            employeeId : employeeId,
        }
        if (employeeId.trim() === "") {
          setApplicationIdError(true);
          return; // Stop further processing
        } else {
          setApplicationIdError(false);
        }
        // console.log(app);
        try {
            const response2 = await axios.post('http://localhost:3426/Company/getRoleById',empRef);
            setEmpDetails(response2.data);
            if(response2.data == null){
              setIsErrorSnackbarOpen(true);
              setErrorSnackbarMessage(`No Employee Id Found With ${employeeId}`);
              setEmpDetails("");
            }
            // console.log("response: =" ,response2.data);
        } catch (error) {
          setIsErrorSnackbarOpen(true);
          setErrorSnackbarMessage(`Something went wrong!`);
        }
        
      };
      // console.log(appointment);

   

    return (
      <React.Fragment >
          <Navbar />
        <Container component="main" maxWidth="lg">
            <Box
                sx={{
                    marginTop: 2,
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    boxShadow: 8,
                }}
            >
                <Typography component="h1" variant="h5" fontWeight="bold" sx={{ mt: 3 }}>
                    Search Appointment
                </Typography>
               
                <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '100%' }}>
                    <Grid container spacing={2} justifyContent="center">
                        <Stack spacing={2} direction="row" alignItems="center" justifyContent="space-between">

                            <TextField
                            sx={{ maxWidth: 250 }}
                                required
                                fullWidth
                                id="employeeId"
                                label="Employee Id"
                                onChange={(e) => setEmployeeId(e.target.value.toUpperCase())}
                                // style={{backgroundColor : '#f5f5dc' }}
                                value={employeeId}
                                size='small'
                                type='text'
                                error={applicationIdError}
                                helperText={applicationIdError ? 'Application ID is required' : ''}
                            />

                            <Button variant="contained" color="primary" sx={{ width: 250 }} onClick={fetchData} endIcon={<Search />}>
                                Search Appointment
                            </Button>
                            <Button variant="contained" color="primary" sx={{ width: 200 }} onClick={CancelData} endIcon= {<Clear />}>
                                Clear
                            </Button>
                        </Stack>

                    </Grid>
                    <Grid container spacing={2} justifyContent="center" marginTop={1} marginBottom={2}>
                        <Grid item xs={6} sx={{ maxWidth: '100%', mb: '5px', ml: 3, mr: 3 }}>
 {/* Object.keys(appointment).length > 0          */}
         {Object.keys(empDetails).length > 0 && (
        <Card sx={{ mt: 1, boxShadow :'8' }}>
          <CardContent>
          <Typography variant="h6" fontWeight="bold" textAlign="center">
                        Employee Details
                      </Typography>
            </CardContent>
            <Stack direction='row'>
            <Box  sx={{ display: 'flex', flexDirection: 'column', ml :3 , marginBottom:2}}>

              <Typography>
              <strong>Company Name</strong>
            </Typography>
            <Typography>
              <strong>Employee ID</strong> 
            </Typography>
            <Typography>
              <strong>Employee Name</strong> 
            </Typography>
            <Typography>
              <strong>Role Name</strong> 
            </Typography>
            <Typography>
              <strong>Contact Number</strong>
            </Typography>
            <Typography>
              <strong>Aadhar Number</strong>
            </Typography>
            <Typography>
              <strong>Permanent Address</strong> 
            </Typography>
            <Typography>
              <strong>Temporary Address</strong> 
            </Typography>
            
            </Box>

            <Box  sx={{ display: 'flex', flexDirection: 'column' , ml :2 , marginBottom:2}}>
            <Typography>
              : {empDetails.companyName}
            </Typography>
            <Typography>
             : {empDetails.employeeId}
            </Typography>
            <Typography>
              : {empDetails.employeeName}
            </Typography>
            <Typography>
              : {empDetails.roleName}
            </Typography>
            <Typography>
              : {empDetails.contactNumber}
            </Typography>
            <Typography>
              : {empDetails.aadharNumber}
            </Typography>
            <Typography>
              : {empDetails.permanentAddress}
            </Typography>
            <Typography>
              : {empDetails.temporaryAddress}
            </Typography>
            
            </Box>
            </Stack>
          {/* </CardContent> */}
        </Card>
      )}
                        </Grid>
                    </Grid>
                </Box>
            </Box>
            <Snackbar
        open={isErrorSnackbarOpen}
        autoHideDuration={3000}
        onClose={() => setIsErrorSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <MuiAlert onClose={() => setIsErrorSnackbarOpen(false)} severity="warning" sx={{ width: '100%' }}>
          {errorSnackbarMessage}
        </MuiAlert>
      </Snackbar>

        </Container>
        </React.Fragment>
    );
};

export default SearchEmployee;

