
import React, { useState, useEffect } from 'react';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import axios from 'axios';
import { parseISO, format } from 'date-fns';
import ThumbUpOffAltIcon from '@mui/icons-material/ThumbUpOffAlt';
import ThumbDownOffAltIcon from '@mui/icons-material/ThumbDownOffAlt';
import Navbar from '../NavBar';
import { TablePagination } from '@mui/material';


const AppointmentRequests = () => {
  const [appointList, setAppointList] = useState([]);
  const [agencyName, setAgencyName] = useState(window.sessionStorage.getItem('organizationName'));
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);


  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const columns = [
    { id: 'applicationId', label: 'Application Id', minWidth: 100, align: 'left' },
    { id: 'employeeId', label: 'Employee Id', minWidth: 100, align: 'left' },
    { id: 'employeeName', label: 'Patient Name', minWidth: 110, align: 'left' },
    { id: 'hospitalId', label: 'Hospital Id', minWidth: 90, align: 'left' },
    { id: 'policyName', label: 'Policy Name', minWidth: 100, align: 'left' },
    { id: 'date', label: 'Date', minWidth: 70, align: 'left' },
    { id: 'slot', label: 'Slot', minWidth: 150, align: 'left' },
    { label: 'Action', minWidth: 250, align: 'left' },


  ];

  useEffect(() => {
    fetchData();
  }, []);
  

  
  const fetchData = async () => {
    const appoint = {
      agencyName: agencyName
    };
    // console.log(appoint);
    try {
      // console.log(agencyName);
      const response2 = await axios.post('http://localhost:3430/Appointment/all', appoint);
      setAppointList(response2.data.filter(row => row.status === 'Pending'));
      // console.log(response2.data);
  
    } catch (error) {
      console.error('Error fetching data:');
    }
  };
  
  

  const handleAccept = async (appointment) => {
    try {
      axios.post(`http://localhost:3430/Appointment/approved`, {
        ...appointment,
        status: 'Approved',
      });

      setTimeout(() => {
        window.location.reload();
      }, 0);
      // console.log(appointment);
      setAppointList(prevList => prevList.filter(item => item._id !== appointment._id));
    } catch (error) {
      console.error('Error updating status:');
    }
  };

  const handleReject = async (appointment) => {
    try {
      await axios.post(`http://localhost:3430/Appointment/rejected`, {
        ...appointment,
        status: 'Rejected'
      });
      window.loading.reload();
      setAppointList(prevList => prevList.filter(item => item._id !== appointment._id));
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  return (

    <React.Fragment >
      <Navbar />
      <Container component="main" maxWidth="lg">
        <Box
          sx={{
            marginTop: 2,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            boxShadow: 8,
          }}
        >
          <Typography component="h1" variant="h5" fontWeight="bold" sx={{ mt: 2 }}>
            Appointment Requests
          </Typography>
          <Box component="form" sx={{ mt: 2, width: '100%', maxWidth: '100%' }}>

            <Grid container spacing={2} justifyContent="center" padding={3} >
              <Grid item xs={12} sx={{ maxWidth: '100%', mb: '5px', ml: 3, mr: 3 }}>
                <TableContainer component={Paper}>
                  <Table aria-label="dynamic table" sx={{ maxWidth: '100%' }}>
                    <TableHead>

                      <TableRow>
                        {columns.map((column) => (
                          <TableCell key={column.id} align={column.align}
                            style={{ minWidth: column.minWidth, fontWeight: 'bold', color: 'black', backgroundColor: '#808080' }}

                          >
                            {column.label}
                          </TableCell>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {appointList
                      .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                        // .filter(row => row.status === 'Pending')
                        .map((row) => (
                          <TableRow key={row._id}>
                            <TableCell sx={{ fontSize: '12px' }}>{row.applicationId}</TableCell>
                            <TableCell sx={{ fontSize: '12px' }}>{row.employeeId}</TableCell>
                            <TableCell sx={{ fontSize: '12px' }}>{row.employeeName}</TableCell>
                            <TableCell sx={{ fontSize: '12px' }}>{row.hospitalId}</TableCell>
                            <TableCell sx={{ fontSize: '12px' }}>{row.policyName || '-'}</TableCell>
                            <TableCell sx={{ fontSize: '12px' }}>
                              {format(parseISO(row.date), 'dd-MM-yyyy')}
                            </TableCell>
                            <TableCell sx={{ fontSize: '12px' }}>{row.slot}</TableCell>
                            <TableCell sx={{ fontSize: '12px' }}>
                              <Button
                                variant="contained"
                                color="primary"
                                size="small"
                                endIcon={<ThumbUpOffAltIcon />}
                                onClick={() => handleAccept(row)}
                                sx={{ marginRight: 1 }}
                              >
                                Accept
                              </Button>
                              <Button
                                variant="contained"
                                color="secondary"
                                size="small"
                                endIcon={<ThumbDownOffAltIcon />}
                                onClick={() => handleReject(row)}
                              >
                                Reject
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </TableContainer>
                <TablePagination
                  rowsPerPageOptions={[10, 25, 100]}
                  component="div"
                  count={appointList.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  onPageChange={handleChangePage}
                  onRowsPerPageChange={handleChangeRowsPerPage}
                />
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Container>
    </React.Fragment>
  );
};

export default AppointmentRequests;
