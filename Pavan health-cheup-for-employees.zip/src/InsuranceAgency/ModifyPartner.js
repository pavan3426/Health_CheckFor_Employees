import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { useState } from 'react';
import ClearIcon from '@mui/icons-material/Clear';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import { MenuItem } from '@material-ui/core';
import UpdateIcon from '@mui/icons-material/Update';
import Navbar from '../NavBar';
import { MenuList, Stack } from '@mui/material';
import { Search } from '@material-ui/icons';
import axios from 'axios';

const ModifyPartnerHospital = () => {
  const [AgencyId, setAgencyId] = useState("");
  const [AgencyName, setAgencyName] = useState(window.sessionStorage.getItem('organizationName'));
  const [HospitalName, setHospitalName] = useState("");
  const [HospitalId, setHospitalId] = useState("");
  const [HospitalAddress, setHospitalAddress] = useState("");
  const [isSnackbarOpen, setIsSnackbarOpen] = React.useState(false);
  const [SnackbarMessage, setSnackbarMessage] = React.useState('')
  const [AgencyDetails, setAgencyDetails] = useState(null);
  const resetFields = () => {
    setAgencyId("");
  
    setHospitalName("");
    setHospitalId("");
    setHospitalAddress("");

  };

  const handleHospitalIdChange = (selectedHospitalId) => {
    setHospitalId(selectedHospitalId);

    // Find the selected partner in the partners array
    const selectedPartner = AgencyDetails?.partners?.find(partner => partner.hospitalId === selectedHospitalId);

    if (selectedPartner) {
      setHospitalName(selectedPartner.hospitalName);
      setHospitalAddress(selectedPartner.hospitalAddress);
    } else {
      // If the selected partner is not found, reset Hospital Name and Address
      setHospitalName("");
      setHospitalAddress("");
    }
  };



  const handleSearch = () => {
    const agency ={
      id:AgencyId,
      agencyName: AgencyName,
    };
    // console.log(agency);
    axios
      .post(`http://localhost:3428/Agency/getPartners`,agency)
      .then(response => {
        // Set the fetched agency details to the state
        setAgencyDetails(response.data);
        // Extract relevant data and set in the form
        setAgencyName(response.data.agencyName);
        // You can add similar lines for HospitalName, HospitalId, and HospitalAddress
      })
      .catch(error => {
        console.error('Error fetching agency details:', error);
      });
  };
  // console.log(AgencyDetails);



  function submitHandler(event) {
    event.preventDefault();
  
    // Construct the updated agency object
    const updatedAgency = {
      id: AgencyId,
      agencyName: AgencyName,
      partners:[
        {
        hospitalId:HospitalId,
        hospitalName:HospitalName,
        hospitalAddress: HospitalAddress
        }
      ],
    };
  
    // Send PUT request to update the agency
    axios
      .post(`http://localhost:3428/Agency/setAgency`, updatedAgency)
      .then(response => {
        // Handle success if needed
        console.log('Agency updated:', response.data);
        // setAgencyName("");
        setHospitalName("");
        setHospitalId("");
        setHospitalAddress("");
        setSnackbarMessage("Partnered Hospital Modified Successfully")
        setIsSnackbarOpen(true);
      })
      .catch(error => {
        console.error('Error updating agency:', error);
        // Handle error if needed
      });
  }

  const handleSnackbarClose = () => {
    setIsSnackbarOpen(false);
  };

  return (
    <React.Fragment>
      <Navbar />
      <Container component="main" maxWidth="md">
        <Box
          sx={{
            marginTop: 4,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            boxShadow: 8
          }}
        >
          <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 4 }}>
            Modify Partner Hospital
          </Typography>

          <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '600px' }} onSubmit={submitHandler}>
            <Grid container spacing={2} justifyContent="center">


              <Grid item xs={13}>
                <TextField
                  required
                  fullWidth
                  id="AgencyName"
                  label="Agency Name"
                  onChange={(e) => setAgencyName(e.target.value)}
                  value={AgencyName}
                  aria-readonly
                  size='small'
                  inputProps={{ style: { textTransform: "uppercase" } }}
                >
                </TextField>
              </Grid>
              
              <Grid item xs={12}>
                <Stack spacing={2} direction="row" alignItems="center" justifyContent="space-between">

                  <TextField
                    required
                    fullWidth
                    id="AgencyId"
                    label="Agency Id"
                    onChange={(e) => setAgencyId(e.target.value)}
                    value={AgencyId}
                    size='small'
                  // inputProps={{style:{textTransform:"uppercase"}}}
                  >
                  </TextField>

                  <Button
                    variant="contained"
                    color="secondary"
                    sx={{ width: '130px' }}
                    endIcon={<Search />}
                    // sx={{  }} 
                    onClick={handleSearch}
                  >
                    Search
                  </Button>
                </Stack>
              </Grid>



              <Grid item xs={12}>
        <TextField
          required
          fullWidth
          id="HospitalId"
          label="Hospital Id"
          onChange={(e) => handleHospitalIdChange(e.target.value)}  
          value={HospitalId}
          size='small'
          select
        >
          <MenuItem value="">Select Hospital Id</MenuItem>
          {AgencyDetails?.partners?.map(partner => (
            <MenuItem key={partner.hospitalId} value={partner.hospitalId}>
              {partner.hospitalId}
            </MenuItem>
          ))}
        </TextField>
      </Grid>

              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="HospitalName"
                  label="Hospital Name"
                  onChange={(e) => setHospitalName(e.target.value.toUpperCase())}
                  value={HospitalName}
                  size='small'
                >

                </TextField>
              </Grid>


              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="HospitalAddress"
                  label="Hospital Address"
                  onChange={(e) => setHospitalAddress(e.target.value)}
                  value={HospitalAddress}
                  size='small'
                />
              </Grid>

            </Grid>

            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2, mb: 4 }}>
              <Button
                type="reset"
                variant="contained"
                endIcon={<ClearIcon />}
                sx={{ mr: 2 }}
                onClick={resetFields}
              >
                Reset
              </Button>
              <Button
                type="submit"
                variant="contained"
                endIcon={<UpdateIcon />}
              >
                Modify Partner Hospital
              </Button>
            </Box>
          </Box>
        </Box>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={3000}
          onClose={handleSnackbarClose}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MuiAlert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
            {SnackbarMessage}
          </MuiAlert>
        </Snackbar>
      </Container>
    </React.Fragment>
  )
}

export default ModifyPartnerHospital;