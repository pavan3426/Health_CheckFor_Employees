import React, { useState, useEffect } from 'react';
import Container from '@mui/material/Container';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import Button from '@mui/material/Button';
import axios from 'axios';
import { Card, TextField, CardContent } from '@mui/material';
import { Stack } from "@mui/material";
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import Navbar from '../NavBar';


const SearchAppointment = () => {
  const [ApplicationId, setAppllicationId] = useState("");
  const [appointment, setAppointment] = useState("");
  const [isErrorSnackbarOpen, setIsErrorSnackbarOpen] = React.useState(false);
  const [errorSnackbarMessage, setErrorSnackbarMessage] = React.useState('');
  const [applicationIdError, setApplicationIdError] = useState(false);

  const CancelData = () => {
    setAppllicationId("");
    setAppointment("");
  }
  const fetchData = async () => {
    const app = {
      applicationId: ApplicationId,
      agencyName: window.sessionStorage.getItem('organizationName')
    }
    // console.log(app);
    // if (ApplicationId.trim() === "") {
    //   setApplicationIdError(true);
    //   return; // Stop further processing
    // } else {
    //   setApplicationIdError(false);
    // }
    try {
      const response2 = await axios.post('http://localhost:3430/Appointment/appointment', app);
      setAppointment(response2.data);
      if (response2.data == null) {
        setIsErrorSnackbarOpen(true);
        setErrorSnackbarMessage(`No Appointment  Found With ${ApplicationId} Id in Our Agency`);
        setAppointment([]);
      }
      // console.log("response: =" ,response2.data);
    } catch (error) {
      setIsErrorSnackbarOpen(true);
      setErrorSnackbarMessage(`Something went wrong!`);
    }

  };
  // console.log(appointment);



  return (
    <React.Fragment >
      <Navbar />
      <Container component="main" maxWidth="lg">
        <Box
          sx={{
            marginTop: 2,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            boxShadow: 8,
          }}
        >
          <Typography component="h1" variant="h5" fontWeight="bold" sx={{ mt: 3 }}>
            Search Appointment
          </Typography>

          <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '100%' }} >
            <Grid container spacing={2} justifyContent="center">
              <Stack spacing={2} direction="row" alignItems="center" justifyContent="space-between">

                <TextField
                  required
                  fullWidth
                  label="Application Id"
                  id="ApplicationId"
                  onChange={(e) => setAppllicationId(e.target.value)}
                  // style={{backgroundColor : '#f5f5dc' }}
                  value={ApplicationId}
                  size='small'
                  type='text'
                  error={applicationIdError}
                  helperText={applicationIdError ? 'Application ID is required' : ''}
                />

                <Button variant="contained" color="primary" sx={{ width: 350 }} onClick={fetchData} >
                  Search Appointment
                </Button>
                <Button variant="contained" color="primary" sx={{ width: 350 }} onClick={CancelData}>
                  Cancel
                </Button>
              </Stack>

            </Grid>
            <Grid container spacing={2} justifyContent="center" marginTop={1} marginBottom={2}>
              <Grid item xs={6} sx={{ maxWidth: '100%', mb: '5px', ml: 3, mr: 3 }}>
                {/* Object.keys(appointment).length > 0          */}
                {Object.keys(appointment).length > 0 && (
                  <Card sx={{ mt: 1, boxShadow: '8' }}>
                    <CardContent>
                      <Typography variant="h6" fontWeight="bold" textAlign="center">
                        Appointment Details
                      </Typography>
                    </CardContent>
                    <Stack direction='row'>
                      <Box sx={{ display: 'flex', flexDirection: 'column', ml: 3, marginBottom: 2 }}>

                        <Typography>
                          <strong>Company Name</strong>
                        </Typography>
                        <Typography>
                          <strong>Employee ID</strong>
                        </Typography>
                        <Typography>
                          <strong>Agency Name</strong>
                        </Typography>
                        <Typography>
                          <strong>Employee Name</strong>
                        </Typography>
                        <Typography>
                          <strong>Hospital ID</strong>
                        </Typography>
                        <Typography>
                          <strong>Hospital Name</strong>
                        </Typography>
                        <Typography>
                          <strong>Hospital Address</strong>
                        </Typography>
                        <Typography>
                          <strong>Policy Name</strong>
                        </Typography>
                        <Typography>
                          <strong>Purpose</strong>
                        </Typography>
                        <Typography>
                          <strong>Date</strong>
                        </Typography>
                        <Typography>
                          <strong>Slot</strong>
                        </Typography>
                        <Typography>
                          <strong>Email</strong>
                        </Typography>
                        <Typography>
                          <strong>Status</strong>
                        </Typography>
                      </Box>

                      <Box sx={{ display: 'flex', flexDirection: 'column', ml: 2, marginBottom: 2 }}>
                        <Typography>
                          : {appointment.companyName}
                        </Typography>
                        <Typography>
                          : {appointment.employeeId}
                        </Typography>
                        <Typography>
                          : {appointment.agencyName}
                        </Typography>
                        <Typography>
                          : {appointment.employeeName}
                        </Typography>
                        <Typography>
                          : {appointment.hospitalId}
                        </Typography>
                        <Typography>
                          : {appointment.hospitalName}
                        </Typography>
                        <Typography>
                          : {appointment.hospitalAddress}
                        </Typography>
                        <Typography>
                          : {appointment.policyName}
                        </Typography>
                        <Typography>
                          : {appointment.purpose}
                        </Typography>
                        <Typography>
                          : {new Date(appointment.date).toLocaleDateString()}
                        </Typography>
                        <Typography>
                          : {appointment.slot}
                        </Typography>
                        <Typography>
                          : {appointment.email}
                        </Typography>
                        <Typography>
                          : {appointment.status}
                        </Typography>
                      </Box>
                    </Stack>
                    {/* </CardContent> */}
                  </Card>
                )}
              </Grid>
            </Grid>
          </Box>
        </Box>
        <Snackbar
          open={isErrorSnackbarOpen}
          autoHideDuration={3000}
          onClose={() => setIsErrorSnackbarOpen(false)}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MuiAlert onClose={() => setIsErrorSnackbarOpen(false)} severity="warning" sx={{ width: '100%' }}>
            {errorSnackbarMessage}
          </MuiAlert>
        </Snackbar>

      </Container>
    </React.Fragment>
  );
};

export default SearchAppointment;

