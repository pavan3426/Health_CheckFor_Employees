import React from 'react'
import Card from '@mui/material/Card';
import Grid from '@mui/material/Unstable_Grid2';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import Container from '@mui/material/Container';
import ImageList from '@mui/material/ImageList';
import ImageListItem from '@mui/material/ImageListItem';
import Navbar from '../NavBar'
import AddpartnerImg from '../InsuranceAgencyIcons/AddPartner.png'
import ModifypartnerImg from '../InsuranceAgencyIcons/ModifyPartner.png'
import requests from '../InsuranceAgencyIcons/requests.jpg'
import SearchAppointment from '../InsuranceAgencyIcons/SearchAppointment.jpg'
import VerifyPolicyUsedimg from '../CompanyIcons/VerifyPolicyUsed.png'
import { Link } from 'react-router-dom';
import SearchEmployee from '../InsuranceAgencyIcons/SearchEmployee.png';

const InsuranceHomePage = () => {
  let cards = [
    {
        title: "Add Partner Hospital",
        image: AddpartnerImg,
        link: '/addPartnerHospital',
        id: 1
    },
    {
        title: "Modify Partner Hospital",
        image:ModifypartnerImg,
        link: '/modifyPartnerHospital',
        id: 2
    },
    {
      title: "Appointment Requests",
      image:requests,
      link: '/appointmentRequests',
      id: 3
  },
  {
    title: "Search Appointments",
    image:SearchAppointment,
    link: '/searchAppointments',
    id: 4
},  
 {
  title: "View Policies",            
  image:VerifyPolicyUsedimg,
  link: '/viewPoliciesByAgency',
  id: 5
},
{
  title: "Search Employee",            
  image:SearchEmployee,
  link: '/searchEmployee',
  id: 6
},
    
  ]
  const agencyName = window.sessionStorage.getItem('organizationName');

  return (
    <React.Fragment>
      <Navbar />
      <Grid   sx={{
            marginTop: 1,
            display: 'flex',
            flexDirection: 'column',
            marginLeft : 3
            // alignItems: 'center',
          }}>
       <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 1 }} 
       > 
       Welcome To {agencyName} Insurance Home Page
       </Typography> 
         </Grid>

      <Container sx={{ py: 4 }} maxWidth="lg" >
        <Grid container spacing={4}>
          {cards.map((card) => (
            <Grid item key={card.id} xs={12} sm={6} md={4} lg={4}>
              <CardActionArea  component={Link} to={card.link}>
                <Card sx={{ height: '70%', display: 'flex', flexDirection: 'column',  justifyContent:'center', alignItems:'center' }}>
                  <ImageList sx={{ width: 200, m: 1 }}>
                    <ImageListItem>
                      <img src={card.image} alt={card.title} />
                    </ImageListItem>
                  </ImageList>
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Typography gutterBottom variant="h5" component="h2">
                      {card.title}
                    </Typography>
                    <Typography>
                      {card.description}
                    </Typography>
                  </CardContent>
                </Card>
              </CardActionArea>
            </Grid>
          ))}
        </Grid>
      </Container>
    </React.Fragment>
  )
}

export default InsuranceHomePage
