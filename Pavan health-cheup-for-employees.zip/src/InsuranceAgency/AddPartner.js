import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { useState, useEffect } from 'react';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import { Search } from '@material-ui/icons';
import ClearIcon from '@mui/icons-material/Clear';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import Navbar from '../NavBar';
import axios from 'axios'
import { Stack } from '@mui/material';


const AddPartnerHospital = () => {
  const [AgencyId, setAgencyId] =useState("");
  const [AgencyName, setAgencyName] = useState(window.sessionStorage.getItem('organizationName'));
  const [HospitalName, setHospitalName] = useState("");
  const [HospitalId, setHospitalId] = useState("");
  const[HospitalAddress, setHospitalAddress] =useState("");
  const[HospitalList,setHospitalList]=useState([]);
  const [isSnackbarOpen, setIsSnackbarOpen] = React.useState(false);
  const [SnackbarMessage, setSnackbarMessage] = React.useState('')

  const resetFields = () => {
    setAgencyName("");
    setHospitalName("");
    setHospitalId("");
    setHospitalAddress("");

  };

  // New useEffect to fetch data from the backend and store it in 'roles' state
  useEffect(() => {
    // const fetchRoles = () => {
      axios
      .get('http://localhost:3427/Hospital/findAll')
      .then((response) => {
        // Handle the response from the backend and store the data in 'roles' state
        setHospitalList(response.data);
      })
      .catch((error) => {
        // Handle errors (if any)
        console.error('Error fetching data:', error);
        setSnackbarMessage('An error occurred while fetching roles');
        setIsSnackbarOpen(true);
      });
    // };
  },[]);
  // console.log(HospitalList);


   const handleSearch = () => {
    // Find the hospital with the entered HospitalId in the HospitalList
    const foundHospital = HospitalList.find(hospital => hospital.hospitalId === HospitalId);
// console.log(foundHospital);
    if (foundHospital) {
      setHospitalName(foundHospital.hospitalName);
      setHospitalAddress(foundHospital.hospitalAddress);
    } else {
      // Display an alert or snackbar message if hospital ID is not found
      setSnackbarMessage('Hospital ID not found in the list');
      setIsSnackbarOpen(true);
    }
  };

  function submitHandler(event) {
    event.preventDefault();
  
    
    // Create an agency object to send to the backend
      const createAgency = {
        id: AgencyId,
        agencyName: AgencyName,
        partners: [
          {
          hospitalId:HospitalId,
          hospitalName:HospitalName,
          hospitalAddress: HospitalAddress
          }
        ],
      };
  
      
  console.log(createAgency);
      // First create the agency
      axios
      .post(`http://localhost:3428/Agency/setAgency`, createAgency)
      .then(response => {
        // Handle success if needed
        // console.log('Agency updated:', response.data);
        setAgencyName("");
        setHospitalName("");
        setHospitalId("");
        setHospitalAddress("");
        setSnackbarMessage("Partnerd Hospital added Successfully")
        setIsSnackbarOpen(true);
      })
      .catch(error => {
        console.error('Error updating agency:', error);
        // Handle error if needed
      });
    }

    function myTimeout() {
      window.location.reload(true);
    } 
    

  const handleSnackbarClose = () => {
    setIsSnackbarOpen(false);
  };

  return (
    <React.Fragment>
      <Navbar />
      <Container component="main" maxWidth="md">
        <Box
          sx={{
            marginTop: 8,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            boxShadow: 8
          }}
        >
          <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 4 }}>
            Add Partner Hospital
          </Typography>
          
            <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '600px' }}  onSubmit={submitHandler}>
              <Grid container spacing={2} justifyContent="center">
                

                <Grid item xs={6}>
                <TextField
                    required
                    fullWidth
                    id="AgencyId"
                    label="Agency Id"
                    onChange={(e) => setAgencyId(e.target.value.toUpperCase())}
                    value={AgencyId}
                    size='small'
                    // inputProps={{style:{textTransform:"uppercase"}}}
                  >
                  </TextField>
                  </Grid>
                  <Grid item xs={6}>
                  <TextField
                    required
                    fullWidth
                    id="AgencyName"
                    label="Agency Name"
                    onChange={(e) => setAgencyName(e.target.value)}
                    value={AgencyName}
                    size='small'
                    inputProps={{style:{textTransform:"uppercase"}}}
                  >
                  </TextField>
                </Grid>
                <Grid item xs={12}> {/* Full width */}
                <Stack spacing={2} direction="row" alignItems="center" justifyContent="space-between">
                  <TextField
                    required
                    fullWidth
                    id="HospitalId"
                    label="Hospital Id"
                    onChange={(e) => setHospitalId(e.target.value.toUpperCase())}
                    value={HospitalId}
                    size='small'
                  />
                  <Button
                   variant="contained"
                   color="secondary"
                   sx={{ width: '130px'}}
                    endIcon={<Search />}
                    // sx={{  }} 
                    onClick={handleSearch}
                  >
                    Search
                  </Button>
                </Stack>
                </Grid>

                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    id="HospitalName"
                    label="Hospital Name"
                    onChange={(e) => setHospitalName(e.target.value)}
                    value={HospitalName}
                    size='small'
                    inputProps={{style:{textTransform:"uppercase"}}}
                  />
                </Grid>

                
                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    id="HospitalAddress"
                    label="Hospital Address"
                    onChange={(e) => setHospitalAddress(e.target.value)}
                    value={HospitalAddress}
                    size='small'
                  />
                </Grid>

              </Grid>
            
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2, mb: 4 }}>
              <Button
                type="reset"
                variant="contained"
                endIcon={<ClearIcon />}
                sx={{ mr: 2 }}
                onClick={resetFields}
              >
                Reset
              </Button>
              <Button
                type="submit"
                variant="contained"
                endIcon={<PersonAddIcon />}
              >
               Add Partner Hospital
              </Button>
              </Box>
            </Box>
          </Box>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={3000}
          onClose={handleSnackbarClose}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MuiAlert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
            {SnackbarMessage}
          </MuiAlert>
        </Snackbar>
      </Container>
    </React.Fragment>
  )
}

export default AddPartnerHospital;
