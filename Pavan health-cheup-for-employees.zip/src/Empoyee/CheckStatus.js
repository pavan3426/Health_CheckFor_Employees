import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { useState, useEffect } from 'react';
import ClearIcon from '@mui/icons-material/Clear';
import Navbar from '../NavBar';
import { Radio, RadioGroup, FormLabel, FormControlLabel, TablePagination } from '@mui/material';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import axios from 'axios';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import { Search } from '@material-ui/icons';
import { Clear } from '@material-ui/icons';

const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear().toString().slice(-2);
    return `${day}-${month}-${year}`;
};


function base64ToFile(base64Data, fileName) {
    const mimeType = base64Data.split(';')[0].split(':')[1];
    const byteCharacters = atob(base64Data.split(',')[1]);
    const byteArrays = [];

    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
        const slice = byteCharacters.slice(offset, offset + 512);

        const byteNumbers = new Array(slice.length);
        for (let i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
        }

        const byteArray = new Uint8Array(byteNumbers);
        byteArrays.push(byteArray);
    }

    const blob = new Blob(byteArrays, { type: mimeType });
    const file = new File([blob], fileName, { type: mimeType });

    return file;
}



const CheckStatus = () => {
    const [FromDate, setFromDate] = useState("");
    const [ToDate, setToDate] = useState("");
    const [filteredRows, setFilteredRows] = useState([]);
    const [EmployeeId, setEmployeeId] = useState(window.sessionStorage.getItem('organizationName'));
    const [AppointmentsList, setAppointmentsList] = useState([]);
    const [isErrorSnackbarOpen, setIsErrorSnackbarOpen] = React.useState(false);
    const [errorSnackbarMessage, setErrorSnackbarMessage] = React.useState('');
    // const headers = ['Employee Id', 'Application Id', 'Hospital Name', 'Hospital Address', 'Agency Name', 'Policy', 
    // 'Test Name', 'Date', 'Slot', 'Status', 'Health Status'];
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(5);

    const headers = [
        { id: 'employeeId', label: 'Employee Id', minWidth: 100, align: 'left' },
        { id: 'applicationId', label: 'Application Id', minWidth: 100, align: 'left' },
        { id: 'hospitalName', label: 'Hospital Name', minWidth: 140, align: 'left' },
        { id: 'hospitalAddress', label: 'Hospital Address', minWidth: 180, align: 'left' },
        { id: 'agencyName', label: 'Agency Name', minWidth: 150, align: 'left' },
        { id: 'policyName', label: 'Policy Name', minWidth: 100, align: 'left' },
        { id: 'purpose', label: 'Purpose', minWidth: 100, align: 'left' },
        { id: 'date', label: 'Date', minWidth: 65, align: 'left' },
        { id: 'slot', label: 'Slot', minWidth: 150, align: 'left' },
        { id: 'status', label: 'Status', minWidth: 120, align: 'left' },
        { id: 'healthStatus', label: 'Health Status', minWidth: 100, align: 'left' },


    ];
    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };


    const handleDownload = (applicationId, e) => {
        e.preventDefault();
        console.log(applicationId);
        axios.get(`http://localhost:3430/Appointment/reports/${applicationId}`, { responseType: 'blob' })
            .then(response => {
                // Create a blob from the response data
                const blob = new Blob([response.data], { type: response.headers['content-type'] });
                // Create a URL for the blob
                const url = window.URL.createObjectURL(blob);
                // Create a temporary anchor element to trigger the download
                const a = document.createElement('a');
                a.href = url;
                a.download = applicationId; // Set desired filename
                document.body.appendChild(a);
                a.click();
                // Clean up
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            })
            .catch(error => {
                // console.error(error);
                // Display error message or perform error handling
            });
    };

    const handleFind = async (e) => {
        e.preventDefault();
        const appRef = {
            employeeId: EmployeeId
        };

        try {
            const response = await axios.post(`http://localhost:3430/Appointment/healthStatusByEmpId`, appRef);
            setFilteredRows(response.data);
            // console.log(response.data);
            getBlobFromBase64(filteredRows[2].healthStatus);
            console.log(getBlobFromBase64(filteredRows[2].healthStatus));
        }
        catch (error) {
            // setIsErrorSnackbarOpen(true);
            // setErrorSnackbarMessage('No Reports Found On This Employee Id');

        }
    };

    const ResetFields = () => {
        setFromDate("");
        setToDate("");
        setFilteredRows([]);
    };


    //Code to chnage the Image  from byte array to Normal Image

    const getBlobFromBase64 = (base64String) => {

        const binaryString = window.atob(base64String);

        const bytes = new Uint8Array(binaryString.length);

        for (let i = 0; i < binaryString.length; i++) {

            bytes[i] = binaryString.charCodeAt(i);

        }

        // console.log( new Blob([bytes], { type: 'image/jpeg, .pdf' }) ); // Update the MIME type if needed
        return new Blob([bytes], { type: 'image/png, .pdf' });
    };

    return (
        <React.Fragment>
            <Navbar />

            <Container component="main" maxWidth="lg">
                <Box
                    sx={{
                        marginTop: 2,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        boxShadow: 8
                    }}
                >
                    <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 4 }}>
                        Check Status!
                    </Typography>

                    <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '1000px' }} >
                        <Grid container spacing={2} justifyContent="center">

                            <Grid item xs={12} sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', ml: 2, mr: 3 }}>
                                <TextField
                                    required
                                    sx={{ ml: 2, mr: 2 }}
                                    id="EmployeeId"
                                    label="Employee Id"
                                    // onChange={(e) => setEmployeeId(e.target.value)}
                                    value={EmployeeId}
                                    size='small'
                                    aria-readonly
                                // sx={{maxWidth:''}}
                                />
                                <Button
                                    type="submit"
                                    variant="contained"
                                    endIcon={<Search />}
                                    sx={{ mr: 2 }}
                                    onClick={handleFind}
                                >
                                    Find Reports
                                </Button>
                                <Button
                                    type="reset"
                                    variant="contained"
                                    endIcon={<Clear />}
                                    sx={{ mr: 2 }}
                                    onClick={ResetFields}
                                >
                                    Clear Table
                                </Button>
                            </Grid>
                            <Box component="form" sx={{ mt: 2, width: '100%', maxWidth: '100%' }}>
                                <Grid container spacing={2} justifyContent="center" >
                                    <Grid item xs={12} sx={{ maxWidth: '100%', mb: '5px', ml: 3, mr: 3 }}>
                                        <TableContainer component={Paper}>
                                            <Table aria-label="dynamic table" sx={{ maxWidth: '100%' }}>
                                                <TableHead>
                                                    <TableRow>
                                                        {headers.map((header) => (
                                                            <TableCell key={header.id} align={header.align}
                                                                style={{ minWidth:header.minWidth, fontWeight: 'bold', color: 'black', backgroundColor: '#808080' }}

                                                            >
                                                                {header.label}
                                                            </TableCell>
                                                        ))}
                                                    </TableRow>
                                                </TableHead>

                                                <TableBody>
                                                    {filteredRows
                                                        .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                                        .reverse()
                                                        .map((row, rowIndex) => (
                                                            <TableRow key={rowIndex}>
                                                                <TableCell >{row.employeeId}</TableCell>
                                                                <TableCell>{row.applicationId}</TableCell>
                                                                <TableCell>{row.hospitalName}</TableCell>
                                                                <TableCell>{row.hospitalAddress}</TableCell>
                                                                <TableCell>{row.agencyName}</TableCell>
                                                                <TableCell>{row.policyName}</TableCell>
                                                                <TableCell>{row.purpose}</TableCell>
                                                                <TableCell>{formatDate(row.date)}</TableCell>
                                                                <TableCell>{row.slot}</TableCell>
                                                                <TableCell>{row.status}</TableCell>
                                                                <TableCell>
                                                                    {row.status !== 'Pending' && row.status !== 'Approved' && row.status !== 'Cancelled by the Patient' ? (
                                                                        <button onClick={(e) => handleDownload(row.applicationId, e)}>Download</button>
                                                                    ) : null}
                                                                    {/* <button onClick={() => handleDownload(row.applicationId)}>Download</button> */}
                                                                </TableCell>

                                                            </TableRow>
                                                        ))}
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                        <TablePagination
                                            rowsPerPageOptions={[10, 25, 100]}
                                            component="div"
                                            count={filteredRows.length}
                                            rowsPerPage={rowsPerPage}
                                            page={page}
                                            onPageChange={handleChangePage}
                                            onRowsPerPageChange={handleChangeRowsPerPage}
                                        />
                                    </Grid>
                                </Grid>
                            </Box>
                        </Grid>
                    </Box>
                </Box>
                <Snackbar
                    open={isErrorSnackbarOpen}
                    autoHideDuration={3000}
                    onClose={() => setIsErrorSnackbarOpen(false)}
                    anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                >
                    <MuiAlert onClose={() => setIsErrorSnackbarOpen(false)} severity="warning" sx={{ width: '100%' }}>
                        {errorSnackbarMessage}
                    </MuiAlert>
                </Snackbar>
            </Container>
        </React.Fragment>
    )
}

export default CheckStatus;

