import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { useState } from 'react';
import ClearIcon from '@mui/icons-material/Clear';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import CancelIcon from '@mui/icons-material/Cancel';
import SearchIcon from '@mui/icons-material/Search';
import { Radio, RadioGroup, FormLabel, FormControlLabel, Card, CardContent } from '@mui/material';
import Navbar from '../NavBar';
import MenuItem from '@mui/material/MenuItem';
import { Stack } from '@mui/material';
import axios, { HttpStatusCode } from 'axios';




const CancelAppointment = () => {
    const emp = window.sessionStorage.getItem('organizationName');

    const [isSnackbarOpen, setIsSnackbarOpen] = React.useState(false);
    const [backDate, setBackDate] = useState("");
    const [ApplicationId, setApplicationId] = useState("");
    const [SnackbarMessage, setSnackbarMessage] = React.useState('');
    const [isErrorSnackbarOpen, setIsErrorSnackbarOpen] = React.useState(false);
    const [errorSnackbarMessage, setErrorSnackbarMessage] = React.useState('');
    const [isInfoSnackbarOpen, setIsInfoSnackbarOpen] = React.useState(false);
    const [infoSnackbarMessage, setInfoSnackbarMessage] = React.useState('');
    const [showAppointmentDetails, setShowAppointmentDetails] = useState(false);
    const isCancelDisabled = !showAppointmentDetails;
    const resetFields = () => {
        setShowAppointmentDetails("");
        setApplicationId("");
    };

    const handleSnackbarClose = () => {
        setIsSnackbarOpen(false);
    };

    const toggleDetailsVisibility = () => {
        setShowAppointmentDetails(!showAppointmentDetails);
    };

    const ApplicationIdHandle = (e) => {
        e.preventDefault();

        if (!ApplicationId) {
            setIsErrorSnackbarOpen(true);
            setErrorSnackbarMessage('Application Id is required');
            return;
        }
        setShowAppointmentDetails("");
        const applicationId = {
            applicationId: ApplicationId,
            employeeId: emp
        }

        axios
            .post('http://localhost:3430/Appointment/Reschedule', applicationId)
            .then((response) => {
                setShowAppointmentDetails(response.data);
                if (response.data === "Not Found") {

                    setIsErrorSnackbarOpen(true);
                    setErrorSnackbarMessage(`No Application Id Found  On your Employee Id with ${ApplicationId}`);
                    setShowAppointmentDetails("");
                }

            })
            .catch((error) => {
                setIsErrorSnackbarOpen(true);
                setErrorSnackbarMessage(`No Application Id Found  On your Employee Id with ${ApplicationId}`);
            })
    }

    function submitHandler(event) {
        event.preventDefault(); // Prevent form submission from triggering a page refresh

        const updatedData = {
            ...showAppointmentDetails,
            status: "Cancelled by the Patient"
        };
        // console.log(updatedData);

        setInfoSnackbarMessage("Don't go Back Your Appointment Cancellation is in Process...")
        setIsInfoSnackbarOpen(true);

        axios
            .post('http://localhost:3430/Appointment/Update', updatedData)
            .then((response) => {
                setSnackbarMessage("Your Appointment is Cancelled Successfully")
                setIsSnackbarOpen(true);
                setShowAppointmentDetails("");
            })
            .catch(error => {
                setIsErrorSnackbarOpen(true);
                setErrorSnackbarMessage(`Something went wrong!`);
            });
    }

    return (
        <React.Fragment>
            <Navbar />
            <Container component="main" maxWidth="lg">

                <Box
                    sx={{
                        marginTop: 2,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        boxShadow: 8
                    }}
                >
                    <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 2 }}>
                        Cancel Appointment!
                    </Typography>

                    <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '100%' }} onSubmit={submitHandler} >
                        <Grid container spacing={2} justifyContent="center">

                            <Stack spacing={2} direction="row" alignItems="center" justifyContent="space-between">
                                <TextField
                                    required
                                    fullWidth
                                    id="ApplicationId"
                                    label="Application Id"
                                    onChange={(e) => setApplicationId(e.target.value)}
                                    value={ApplicationId}
                                    size='small'

                                >
                                </TextField>
                                <Button

                                    variant="contained"
                                    color="secondary"
                                    sx={{ width: '250px' }}
                                    endIcon={<SearchIcon />}
                                    onClick={ApplicationIdHandle}
                                >
                                    Search
                                </Button>
                            </Stack>

                        </Grid>

                        <Box sx={{ mt: 1, }} >


                            <Grid container spacing={2} justifyContent="center" marginTop={1} marginBottom={2}>
                                <Grid item xs={7} sx={{ maxWidth: '100%', mb: '5px', ml: 3, mr: 3 }}>
                                    {Object.keys(showAppointmentDetails).length > 0 && (

                                        <Card sx={{ m: 2, boxShadow: '8' }}>
                                            <CardContent>
                                                <Typography variant="h6" fontWeight={'bold'} textAlign="center">Appointment Details</Typography>
                                                <Stack direction='row'>
                                                    <Box sx={{ display: 'flex', flexDirection: 'column', ml: 2, marginBottom: 2 }}>

                                                        <Typography ><b>Employee Name</b></Typography>
                                                        <Typography><b>Employee Id       </b></Typography>
                                                        <Typography><b>Company Name      </b></Typography>
                                                        <Typography><b>EMail             </b></Typography>
                                                        <Typography><b>Policy Name       </b></Typography>
                                                        <Typography><b>Purpose           </b></Typography>
                                                        <Typography><b>Date              </b></Typography>
                                                        <Typography><b>Slot              </b></Typography>
                                                        <Typography><b>Agency Name       </b></Typography>
                                                        <Typography><b>Hospital Id       </b></Typography>
                                                        <Typography><b>Hospital Name     </b></Typography>
                                                        <Typography><b>Hospital Address  </b></Typography>
                                                        <Typography><b>Appointment Status</b></Typography>
                                                    </Box>
                                                    <Box sx={{ display: 'flex', flexDirection: 'column', ml: 2, marginBottom: 2 }}>
                                                        <Typography >: {showAppointmentDetails.employeeName}</Typography>
                                                        <Typography>: {showAppointmentDetails.employeeId}</Typography>
                                                        <Typography>: {showAppointmentDetails.companyName}</Typography>
                                                        <Typography>: {showAppointmentDetails.email}</Typography>
                                                        <Typography>: {showAppointmentDetails.policyName}</Typography>
                                                        <Typography>: {showAppointmentDetails.purpose}</Typography>
                                                        <Typography>: {showAppointmentDetails.date.split("T")[0]}</Typography>
                                                        <Typography>: {showAppointmentDetails.slot}</Typography>
                                                        <Typography>: {showAppointmentDetails.agencyName}</Typography>
                                                        <Typography>: {showAppointmentDetails.hospitalId}</Typography>
                                                        <Typography>: {showAppointmentDetails.hospitalName}</Typography>
                                                        <Typography>: {showAppointmentDetails.hospitalAddress}</Typography>
                                                        <Typography>: {showAppointmentDetails.status}</Typography>
                                                    </Box>
                                                </Stack>
                                            </CardContent>
                                        </Card>
                                    )}
                                </Grid>
                            </Grid>


                            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2, mb: 4 }}>
                                <Button
                                    type="reset"
                                    variant="contained"
                                    endIcon={<ClearIcon />}
                                    sx={{ mr: 2 }}
                                    onClick={resetFields}
                                >
                                    Reset
                                </Button>
                                <Button
                                    type="submit"
                                    variant="contained"
                                    endIcon={<CancelIcon />}
                                    onClick={submitHandler}
                                    disabled={isCancelDisabled}
                                >
                                    Cancel appointment
                                </Button>
                            </Box>
                        </Box>
                    </Box>
                </Box>
                <Snackbar
                    open={isSnackbarOpen}
                    autoHideDuration={3000}
                    onClose={handleSnackbarClose}
                    anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                >
                    <MuiAlert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
                        {SnackbarMessage}
                    </MuiAlert>
                </Snackbar>

                <Snackbar
                    open={isErrorSnackbarOpen}
                    autoHideDuration={3000}
                    onClose={() => setIsErrorSnackbarOpen(false)}
                    anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                >
                    <MuiAlert onClose={() => setIsErrorSnackbarOpen(false)} severity="warning" sx={{ width: '100%' }}>
                        {errorSnackbarMessage}
                    </MuiAlert>
                </Snackbar>
                <Snackbar
                    open={isInfoSnackbarOpen}
                    autoHideDuration={6000}
                    onClose={() => setIsInfoSnackbarOpen(false)}
                    anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                >
                    <MuiAlert onClose={() => setInfoSnackbarMessage(false)} severity="info" sx={{ width: '100%' }}>
                        {infoSnackbarMessage}
                    </MuiAlert>
                </Snackbar>

            </Container>
        </React.Fragment>
    )
}


export default CancelAppointment;
