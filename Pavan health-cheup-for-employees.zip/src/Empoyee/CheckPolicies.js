import React, { useState } from 'react';
import {
  Container,
  Typography,
  TextField,
  Button,
  Table,
  TableContainer,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Paper,
  Box,
  Grid,
  TablePagination,
} from '@mui/material';
import axios from 'axios';
import Navbar from '../NavBar';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import CancelIcon from '@mui/icons-material/Cancel';
import SearchIcon from '@mui/icons-material/Search';

const CheckPolicies = () => {
  const [companyName, setCompanyName] = useState('');
  const [roleName, setRoleName] = useState('');
  const [tableData, setTableData] = useState([]);
  const [isErrorSnackbarOpen, setIsErrorSnackbarOpen] = React.useState(false);
  const [errorSnackbarMessage, setErrorSnackbarMessage] = React.useState('');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  const clearTable = () => {
    setTableData("");
    setCompanyName("");
    setRoleName("");
  }
  const handleSearch = () => {
    const policyData = {
      roleName: roleName,
      companyName: companyName,
    };
    setTableData([]);
    axios
      .post('http://localhost:3426/Policy/getPolicies', policyData)
      .then((response) => {
        setTableData(response.data);
        // console.log(response.data);
      })
      .catch((error) => {
        // console.error('Error fetching data:', error);
        setIsErrorSnackbarOpen(true);
        setErrorSnackbarMessage('Please provide correct Name & Role Name');

      });
  };

  return (
    <React.Fragment>
      <Navbar />
      <Container component="main" maxWidth="lg">
        <Box
          sx={{
            marginTop: 1,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            boxShadow: 10,
            padding: '20px', // Add padding to the left side of the container
          }}
        >
          <Typography component="h1" variant="h5" fontWeight="bold" sx={{ mt: 4 }}>
            Check Policies
          </Typography>

          <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '900px' }}>
            <Grid container spacing={2} justifyContent="center" padding={2}>
              <Grid item xs={12} sm={4}>
                <TextField
                required
                  label="Company Name"
                  variant="outlined"
                  size="small"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  style={{ marginRight: '10px' }}
                />
              </Grid>
              <Grid item xs={12} sm={4}>
                <TextField
                required
                  label="Role Name"
                  variant="outlined"
                  size="small"
                  value={roleName}
                  onChange={(e) => setRoleName(e.target.value)}
                  style={{ marginRight: '10px' }}
                />
              </Grid>
              <Grid item xs={12} sm={4}>
                <Button variant="contained" color="primary" onClick={handleSearch} endIcon={<SearchIcon />}  >
                  Search
                </Button>
                <Button variant="contained" color="primary" onClick={clearTable} endIcon={<CancelIcon />} style={{ marginLeft: '5px' }}  >
                  clear Table
                </Button>
              </Grid>

            </Grid>
            {tableData.length > 0 && (
            <Grid item xs={12} sx={{ maxWidth: '100%', mb: '5px', mt: '8px', ml: 3, mr: 3 }}>

              <TableContainer component={Paper} sx={{ width: '100%', overflowX: 'scroll' }}>
                <Table aria-label="dynamic table" sx={{ maxWidth: '100%' }}>

                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: 'bold', padding: '10px', fontSize: '14px', color: 'black', backgroundColor: '#808080' }}>Policy Name</TableCell>
                      <TableCell sx={{ fontWeight: 'bold', padding: '10px', fontSize: '14px', color: 'black', backgroundColor: '#808080' }}>Policy Description</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {tableData
                      .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                      .map((row) => (
                        <TableRow key={row.policyName}>
                          <TableCell>{row.policyName}</TableCell>
                          <TableCell>{row.policyDescription}</TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </TableContainer>
            <TablePagination
              rowsPerPageOptions={[10, 25, 100]}
              component="div"
              count={tableData.length}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            />
</Grid>
            )}
          </Box>
        </Box>     <Snackbar
          open={isErrorSnackbarOpen}
          autoHideDuration={3000}
          onClose={() => setIsErrorSnackbarOpen(false)}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MuiAlert onClose={() => setIsErrorSnackbarOpen(false)} severity="warning" sx={{ width: '100%' }}>
            {errorSnackbarMessage}
          </MuiAlert>
        </Snackbar>
      </Container>
    </React.Fragment>
  );
};

export default CheckPolicies;
