import * as React from 'react';
import { parseISO, format } from 'date-fns';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { useState } from 'react';
import ClearIcon from '@mui/icons-material/Clear';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import UpdateIcon from '@mui/icons-material/Update';
import SearchIcon from '@mui/icons-material/Search';
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import { Radio, RadioGroup, FormLabel, FormControlLabel, MenuItem } from '@mui/material';
import Navbar from '../NavBar';
import { Stack } from '@mui/material';
import axios from 'axios';

const BookAppointment = () => {
    const [CompanyName, setCompanyName] = useState("");
    const [EmployeeId, setEmployeeId] = useState(window.sessionStorage.getItem('organizationName'));
    const [EmployeeName, setEmployeeName] = useState("");
    const [AgencyName, setAgencyName] = useState("");
    const [HospitalName, setHospitalName] = useState("");
    const [HospitalId, setHospitalId] = useState("");
    const [HospitalAddress, setHospitalAddress] = useState("");
    const [PolicyName, setPolicyName] = useState("");
    const [AgencyList, setAgencyList] = useState("");
    const [EmailId, setEmailId] = useState("");
    const [filteredAgencyNames, setFilteredAgencyNames] = useState([]);
    const [HospitalList, setHospitalList] = useState([]);
    const [RoleName, setRoleName] = useState("");
    const [purpose, setpurpose] = useState("");
    const [policiesList, setPoliciesList] = useState([]);
    // const [isBookingInProgress, setIsBookingInProgress] = useState(false);

    const [Date, setDate] = useState("");
    const [Slot, setSlot] = useState("");

    const [isInfoSnackbarOpen, setIsInfoSnackbarOpen] = React.useState(false);
    const [infoSnackbarMessage, setInfoSnackbarMessage] = React.useState('');
    const [isSnackbarOpen, setIsSnackbarOpen] = React.useState(false);
    const [SnackbarMessage, setSnackbarMessage] = React.useState('');
    // const partnersNames = HospitalList.partners.map(partner => partner.agencyName);

    const resetFields = () => {
        setCompanyName("");
        setEmployeeName("");
        setAgencyName("");
        setHospitalName("");
        setHospitalId("");
        setHospitalAddress("");
        setPolicyName("");
        setpurpose("");
        setDate("");
        setSlot("");
        setEmailId("");

    };

    const handleSnackbarClose = () => {
        setIsSnackbarOpen(false);
    };

    const HandleSearch = () => {
        axios
            .get(`http://localhost:3426/Agency/getAll`)
            .then(response => {
                // Set the fetched agency details to the state
                setAgencyList(response.data);

                const filteredNames = response.data
                    .filter(agency => agency.companyName.toLowerCase().includes(CompanyName.toLowerCase()))
                    .map(agency => agency.agencyName);

                setFilteredAgencyNames(filteredNames);
            })
            .catch(error => {
                console.error('Error fetching agency details:', error);
            })


    }

    const GetHospital = (e) => {
        e.preventDefault();
        setAgencyName(e.target.value);
        const agencyname = {
            agencyName: e.target.value
        };
        // console.log("From getHsptl Method" ,e.target.value);

        axios
            .post('http://localhost:3428/Agency/getHospitals', agencyname)
            .then((response) => {
                setHospitalList(response.data.partners);
                // console.log(response.data.partners);
            })
            .catch(error => {
                console.error('Error fetching agency details:', error);
            });
    }



    function submitHandler(event) {
        event.preventDefault();

        const appointmentDetails = {

            companyName: CompanyName,
            employeeId: EmployeeId,
            agencyName: AgencyName,
            employeeName: EmployeeName,
            hospitalId: HospitalId,
            hospitalAddress: HospitalAddress,
            hospitalName: HospitalName,
            policyName: PolicyName,
            purpose: purpose,
            date: Date,
            slot: Slot,
            email: EmailId,
            status: "Pending",

        }
        //    console.log(appointmentDetails);
        setInfoSnackbarMessage("Don't go Back Your Appointment Booking is in Process...")
        setIsInfoSnackbarOpen(true);
        axios
            .post('http://localhost:3430/Appointment/Book', appointmentDetails)
            .then((response) => {

                console.log(response.data);
                console.log(appointmentDetails);
                // Show the response data in an alert box
                alert(`Please save Application Id for Future.! ${JSON.stringify(response.data)}`);

                setSnackbarMessage("Your Appointment is booked wait for Conformation")
                setIsSnackbarOpen(true);
                setCompanyName("");
                setEmployeeId("");
                setEmployeeName("");
                setAgencyName("");
                setHospitalName("");
                setHospitalId("");
                setHospitalAddress("");
                setPolicyName("");
                setpurpose("");
                setDate("");
                setSlot("");
                setEmailId("");
            }
                // alert('please save Your Application Id for future' ${response.data}),
            )
            .catch(error => {
                console.error('Error fetching agency details:', error);
            });
    };

    return (
        <React.Fragment>
            <Navbar />
            <Container component="main" maxWidth="lg">
                <Box
                    sx={{
                        marginTop: 2,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        boxShadow: 8
                    }}
                >
                    <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 4 }}>
                        Book Appointment Now!
                    </Typography>

                    <Box component="form" sx={{ mt: 1, width: '100%', maxWidth: '1000px' }} onSubmit={submitHandler}>
                        <Grid container spacing={2} justifyContent="center">


                            <Grid item xs={6}>
                                <TextField
                                    required
                                    fullWidth
                                    id="EmployeeId"
                                    label="Employee Id"
                                    onChange={(e) => setEmployeeId(e.target.value)}
                                    value={EmployeeId}
                                    size='small'
                                    InputProps={{
                                        readOnly: 'true'
                                    }}

                                >

                                </TextField>
                            </Grid>

                            <Grid item xs={6}>
                                <TextField
                                    required
                                    fullWidth
                                    id="EmployeeName"
                                    label="Employee Name"
                                    onChange={(e) => setEmployeeName(e.target.value)}
                                    value={EmployeeName}
                                    size='small'
                                >

                                </TextField>
                            </Grid>

                            <Grid item xs={12}>
                                <Stack spacing={2} direction="row" alignItems="center" justifyContent="space-between">
                                    <TextField
                                        required
                                        fullWidth
                                        id="ComanyName"
                                        label="Company Name"
                                        onChange={(e) => setCompanyName(e.target.value)}
                                        value={CompanyName}
                                        size='small'

                                    >

                                    </TextField>
                                    <Button

                                        variant="contained"
                                        color="secondary"
                                        sx={{ width: '400px' }}
                                        // endIcon={<SearchIcon />}
                                        onClick={HandleSearch}
                                    >
                                        Get Partnered Hospitals
                                    </Button>
                                </Stack>
                            </Grid>


                            <Grid item xs={6}>


                                <TextField
                                    required
                                    fullWidth
                                    id="AgencyName"
                                    label="Agency Name"
                                    onChange={GetHospital}
                                    value={AgencyName}
                                    size='small'
                                    select

                                >
                                    <MenuItem value="">select agency</MenuItem>
                                    {filteredAgencyNames.map(name => (
                                        <MenuItem key={name} value={name}>
                                            {name}
                                        </MenuItem>
                                    ))}

                                </TextField>
                            </Grid>

                            <Grid item xs={6}>
                                <TextField
                                    required
                                    fullWidth
                                    id="HospitalName"
                                    label="Hospital Name"
                                    onChange={(e) => {
                                        setHospitalName(e.target.value);

                                        // Find the selected hospital from HospitalList
                                        const selectedHospital = HospitalList.find(hospital => hospital.hospitalName === e.target.value);

                                        // Set the hospital ID and address
                                        if (selectedHospital) {
                                            setHospitalId(selectedHospital.hospitalId);
                                            setHospitalAddress(selectedHospital.hospitalAddress);
                                        } else {
                                            setHospitalId("");
                                            setHospitalAddress("");
                                        }
                                    }}
                                    value={HospitalName}
                                    size='small'
                                    inputProps={{ style: { textTransform: "uppercase" } }}
                                    select
                                >
                                    <MenuItem value="">Select Hospital</MenuItem>
                                    {HospitalList.map((partners) => (

                                        <MenuItem key={partners.hospitalName} value={partners.hospitalName}>
                                            {partners.hospitalName}
                                        </MenuItem>
                                    ))}
                                </TextField>
                            </Grid>

                            <Grid item xs={6}>
                                <TextField
                                    required
                                    fullWidth
                                    id="HospitalId"
                                    label="Hospital Id"
                                    // onChange={(e) => setHospitalId(e.target.value)}
                                    value={HospitalId}
                                    size='small'
                                    InputProps={{
                                        readOnly: 'true' // Set the readOnly attribute to make the field read-only
                                    }}

                                />
                            </Grid>
                            <Grid item xs={6}>
                                <TextField
                                    required
                                    fullWidth
                                    id="HospitalAddress"
                                    label="Hospital Address"
                                    // onChange={ (e) => e.preventDefault()}
                                    value={HospitalAddress}
                                    size='small'
                                    InputProps={{
                                        readOnly: 'true' // Set the readOnly attribute to make the field read-only
                                    }}
                                />
                            </Grid>



                            <Grid item xs={6}>
                                <TextField
                                    required
                                    fullWidth
                                    id="PolicyName"
                                    label="Policy Name"
                                    onChange={(e) => setPolicyName(e.target.value)}
                                    value={PolicyName}
                                    size='small'


                                >

                                </TextField>
                            </Grid>


                            <Grid item xs={6}>
                                <TextField
                                    required
                                    fullWidth
                                    id="purpose"
                                    label="Purpose"
                                    onChange={(e) => setpurpose(e.target.value)}
                                    value={purpose}
                                    size='small'

                                >

                                </TextField>
                            </Grid>


                            <Grid item xs={6}>
                                <TextField
                                    required
                                    fullWidth
                                    id="Date"
                                    // label="Date"
                                    onChange={(e) => {
                                        // setDate(e.target.value);
                                        const isoDate = e.target.value;
                                        const dateObject = parseISO(isoDate);
                                        const formattedDate = format(dateObject, 'yyyy-MM-dd'); // Format as YYYY-MM-DD
                                        setDate(formattedDate);

                                    }
                                    }
                                    value={Date}
                                    size='small'
                                    type='date'

                                />
                            </Grid>

                            <Grid item xs={6}>
                                <TextField
                                    required
                                    fullWidth
                                    id="EmailId"
                                    label="EmailId"
                                    onChange={(e) => setEmailId(e.target.value)}
                                    value={EmailId}
                                    size='small'

                                />
                            </Grid>




                            {/* <Grid item xs={12}  sx={{ flow: 'flex' ,flexDirection: 'column'}} > */}
                            <Grid item xs={12} sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
                                <FormLabel> Choose Slot &nbsp;  &nbsp;</FormLabel>
                                <RadioGroup
                                    row
                                    aria-label="slots"
                                    name="slot"
                                    value={Slot}
                                    onChange={(e) => setSlot(e.target.value)}
                                >
                                    <FormControlLabel value="Morning 9:00 AM - 12 PM" control={<Radio />} label="Morning (9AM-12PM)" />
                                    <FormControlLabel value="Afternoon 12:30 -4:00 PM" control={<Radio />} label="Afternoon (12:30PM-4PM)" />
                                    <FormControlLabel value="Evening 4:00 - 6:30 PM" control={<Radio />} label="Evening (4PM-6:30PM)" />
                                </RadioGroup>
                            </Grid>




                        </Grid>

                        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2, mb: 4 }}>
                            <Button
                                type="reset"
                                variant="contained"
                                endIcon={<ClearIcon />}
                                sx={{ mr: 2 }}
                                onClick={resetFields}
                            >
                                Reset
                            </Button>
                            <Button
                                type="submit"
                                variant="contained"
                                endIcon={<LocalHospitalIcon />}
                            >
                                Book Appointment
                            </Button>
                        </Box>
                    </Box>
                </Box>

                <Snackbar
                    open={isInfoSnackbarOpen}
                    autoHideDuration={8000}
                    onClose={() => setIsInfoSnackbarOpen(false)}
                    anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                >
                    <MuiAlert onClose={() => setInfoSnackbarMessage(false)} severity="info" sx={{ width: '100%' }}>
                        {infoSnackbarMessage}
                    </MuiAlert>
                </Snackbar>

                <Snackbar
                    open={isSnackbarOpen}
                    autoHideDuration={3000}
                    onClose={handleSnackbarClose}
                    anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                >
                    <MuiAlert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
                        {SnackbarMessage}
                    </MuiAlert>
                </Snackbar>
            </Container>
        </React.Fragment>
    )
}

export default BookAppointment;