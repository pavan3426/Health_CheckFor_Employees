import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { useState } from 'react';
import ClearIcon from '@mui/icons-material/Clear';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import UpdateIcon from '@mui/icons-material/Update';
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import { Radio, RadioGroup, FormLabel, FormControlLabel } from '@mui/material';
import Navbar from '../NavBar';
import SearchIcon from '@material-ui/icons/Search';
import axios from 'axios';
import {Stack} from '@mui/material';

const formatDate = (dateString) => {

    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear().toString().slice(-2);

    return `${day}-${month}-${year}`;

  };

const RescheduleAppointment = () => {
    const [CompanyName, setCompanyName] = useState("");
    const [EmployeeId, setEmployeeId] = useState("");
    const emp =window.sessionStorage.getItem('organizationName');
    const [EmployeeName, setEmployeeName] = useState("");
    const [AgencyName, setAgencyName] = useState("");
    const [HospitalName, setHospitalName] = useState("");
    const [HospitalId, setHospitalId] = useState("");
    const [HospitalAddress, setHospitalAddress] = useState("");
    const [PolicyName, setPolicyName] = useState("");
    const [EmailId, setEmailId] = useState("");
    const [purpose, setPurpose] = useState("");
    const [Date, setDate] = useState("");
    const [Slot, setSlot] = useState("");
    const [ApplicationId, setApplicationId] = useState("");
    const [appointmentDetails, setAppointmentDetails]=useState([]);
    const [status, setStatus]=useState("");
    const [isSnackbarOpen, setIsSnackbarOpen] = React.useState(false);
    const [SnackbarMessage, setSnackbarMessage] = React.useState('');
    const [isErrorSnackbarOpen, setIsErrorSnackbarOpen] = React.useState(false);
    const [errorSnackbarMessage, setErrorSnackbarMessage] = React.useState('');
    const [isInfoSnackbarOpen, setIsInfoSnackbarOpen] = React.useState(false);
    const [infoSnackbarMessage, setInfoSnackbarMessage] = React.useState('');
    // const [backDate,setBackDate] =useState("");
    const [isGetApplicationButtonDisabled, setIsGetApplicationButtonDisabled] = useState(true);
   

    const resetFields = () => {
        setCompanyName("");
        setEmployeeId("");
        setEmployeeName("");
        setAgencyName("");
        setHospitalName("");
        setHospitalId("");
        setHospitalAddress("");
        setPolicyName("");
        setPurpose("");
        setDate("");
        setSlot("");
        setEmailId("");
        setStatus("");
        // setBackDate("");

    };

    const handleSnackbarClose = () => {
        setIsSnackbarOpen(false);
    };

    function submitHandler(event) {
        event.preventDefault();
        
        // Construct the updated data object
    const updatedData = {
        applicationId: ApplicationId,
        employeeName: EmployeeName,
        agencyName: AgencyName,
        hospitalName: HospitalName,
        hospitalId: HospitalId,
        hospitalAddress: HospitalAddress,
        policyName: PolicyName,
        purpose: purpose,
        
        date: Date, // Make sure this is in the correct format (MM/DD/YYYY)
        slot: Slot,
        email: EmailId,
        companyName: CompanyName,
        employeeId: EmployeeId,
        status:"Pending"
    };
    // console.log(updatedData);
    setInfoSnackbarMessage("Don't go Back Your Appointment is rescheduling...")
    setIsInfoSnackbarOpen(true);
    // Send the updated data to the backend
    axios
        .post('http://localhost:3430/Appointment/Update', updatedData)
        .then((response) => {
            // setSnackbarMessage("Appointment updated successfully");
            setIsSnackbarOpen(true);
            setCompanyName("");
            setEmployeeId("");
            setEmployeeName("");
            setAgencyName("");
            setHospitalName("");
            setHospitalId("");
            setHospitalAddress("");
            setPolicyName("");
            setPurpose("");
            setDate("");
            setSlot("");
            setEmailId("");
            setStatus("");
            // setBackDate("");
            
            
            setSnackbarMessage("Your Appointment is Rescheduled wait for Conformation")
            setIsSnackbarOpen(true);
        })
        .catch(error => {
            console.error('Error updating appointment:', error);
        });
        // console.log(updatedData);
        // }
    };
    
const ApplicationIdHandle = (e) => {
    e.preventDefault();

    setCompanyName("");
    setEmployeeId("");
    setEmployeeName("");
    setAgencyName("");
    setHospitalName("");
    setHospitalId("");
    setHospitalAddress("");
    setPolicyName("");
    setPurpose("");
    setDate("");
    setSlot("");
    setEmailId("");
    setStatus("");
    // setBackDate("");
    
    const applicationId = {
        applicationId : ApplicationId,
        employeeId:emp
    }
    // console.log(applicationId);
    axios
        .post('http://localhost:3430/Appointment/Reschedule',applicationId)
        .then((response) => {
            console.log(response.data);
            setAppointmentDetails(response.data);
            if(response.data === "Not Found"){
                setAppointmentDetails("");
                setIsErrorSnackbarOpen(true);
                setErrorSnackbarMessage(`No Application Id Found  On your Employee Id with ${ApplicationId}`);
            
            }
            // console.log(response.data);
            // Set the fetched data to the respective state variables
            if(response.data !== "Not Found"){
            setEmployeeName(response.data.employeeName);
            setAgencyName(response.data.agencyName);
            setHospitalName(response.data.hospitalName);
            setHospitalId(response.data.hospitalId);
            setHospitalAddress(response.data.hospitalAddress);
            setPolicyName(response.data.policyName);
            setPurpose(response.data.purpose);
            setCompanyName(response.data.companyName);
            setEmployeeId(response.data.employeeId);
            setEmailId(response.data.email);
            setStatus(response.data.status);
            
            setDate(response.data.date.split("T")[0]);
            }
            
        })


.catch(error => {
    // alert("Your Appointment Id is wrong! Tyr Again");
    setIsErrorSnackbarOpen(true);
    setErrorSnackbarMessage(`No Application Id Found  On your Employee Id with ${ApplicationId}`);

});
}

    return (
        <React.Fragment>
            <Navbar />
            <Container component="main" maxWidth="lg">
                <Box
                    sx={{
                        marginTop: 2,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        boxShadow: 8
                    }}
                >
                    <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 4 }}>
                        Reschedule Appointment Now!
                    </Typography>

                    <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '1000px' }} onSubmit={submitHandler}>
                        <Grid container spacing={2} justifyContent="center">
                            <Grid item xs={12}>
                            <Stack spacing={2} direction="row" alignItems="center" justifyContent="space-between">
                                <TextField
                                    required
                                    fullWidth
                                    id="ApplicationId"
                                    label="Application Id"
                                    onChange={(e) => {
                                        setApplicationId(e.target.value);
                                        setIsGetApplicationButtonDisabled(!e.target.value); // Enable/disable based on input value
                                    }}
                                    value={ApplicationId}
                                    size='small'
                                    
                                    >
                                    </TextField>
                                    <Button

                                        variant="contained"
                                        color="secondary"
                                        sx={{ width: '250px' }}
                                        endIcon={<SearchIcon />}
                                        onClick={ApplicationIdHandle} 
                                        disabled={isGetApplicationButtonDisabled}   
                                    >
                                        Search
                                    </Button>
                                    </Stack>

                            </Grid>

                            <Grid item xs={4}>
                                <TextField
                                    required
                                    fullWidth
                                    id="EmployeeName"
                                    label="Employee Name"
                                    onChange={(e) => setHospitalName(e.target.value)}
                                    value={EmployeeName}
                                    size='small'
                                >

                                </TextField>
                            </Grid>
                            
                            <Grid item xs={4}>
                                <TextField
                                    required
                                    fullWidth
                                    id="EmployeeId"
                                    label="Employee Id"
                                    onChange={(e) => setEmployeeId(e.target.value)}
                                    value={EmployeeId}
                                    size='small'
                                    aria-readonly
                                    disabled={true}
                                >
                                </TextField>


                            </Grid>
                            <Grid item xs={4}>
                                <TextField
                                    required
                                    fullWidth
                                    id="ComanyName"
                                    label="Company Name"
                                    onChange={(e) => setCompanyName(e.target.value)}
                                    value={CompanyName}
                                    size='small'
                                    aria-readonly
                                    disabled={true}

                                >

                                </TextField>
                            </Grid>

                            
                            <Grid item xs={4}>
                                <TextField
                                    required
                                    fullWidth
                                    id="AgencyName"
                                    label="Agency Name"
                                    onChange={(e) => setAgencyName(e.target.value)}
                                    value={AgencyName}
                                    size='small'
                                    aria-readonly
                                    disabled={true}
                                    

                                >

                                </TextField>
                            </Grid>
                            <Grid item xs={4}>
                                <TextField
                                    required
                                    fullWidth
                                    id="HospitalName"
                                    label="Hospital Name"
                                    onChange={(e) => setHospitalName(e.target.value)}
                                    value={HospitalName}
                                    size='small'
                                    inputProps={{ style: { textTransform: "uppercase" } }}
                                    aria-readonly
                                    disabled={true}
                                >

                                </TextField>
                            </Grid>
                           
                            <Grid item xs={4}>
                                <TextField
                                    required
                                    fullWidth
                                    id="HospitalId"
                                    label="Hospital Id"
                                    onChange={(e) => setHospitalId(e.target.value)}
                                    value={HospitalId}
                                    size='small'
                                    aria-readonly
                                    disabled={true}
                                />
                            </Grid>
                            
                            <Grid item xs={8}>
                                <TextField
                                    required
                                    fullWidth
                                    id="HospitalAddress"
                                    label="Hospital Address"
                                    onChange={(e) => setHospitalAddress(e.target.value)}
                                    value={HospitalAddress}
                                    size='small'
                                    aria-readonly
                                    disabled={true}
                                />
                            </Grid>

                            <Grid item xs={4} >
                                <TextField
                                    required
                                    fullWidth
                                    id="status"
                                    label="status"
                                    onChange={(e) => setStatus(e.target.value)}
                                    value={status}
                                    size='small'
                                    aria-readonly
                                    disabled={true}
                                >

                                </TextField>
                            </Grid>

                            <Grid item xs={4}>
                                <TextField
                                    required
                                    fullWidth
                                    id="EmailId"
                                    label="Email Id"
                                    onChange={(e) => setEmailId(e.target.value)}
                                    value={EmailId}
                                    size='small'

                                >

                                </TextField>
                            </Grid>


                            <Grid item xs={4}>
                                <TextField
                                    required
                                    fullWidth
                                    id="PolicyName"
                                    label="Policy Name"
                                    onChange={(e) => setHospitalName(e.target.value)}
                                    value={PolicyName}
                                    size='small'


                                >

                                </TextField>
                            </Grid>
                            


                            <Grid item xs={4}>
                                <TextField
                                    required
                                    fullWidth
                                    id="purpose"
                                    label="Purpose"
                                    onChange={(e) => setPurpose(e.target.value)}
                                    value={purpose}
                                    size='small'

                                >

                                </TextField>
                            </Grid>


                            
                               
                            
                            <Grid item xs={4} >
                                <TextField
                                    required
                                    fullWidth
                                    id="Date"
                                    onChange={(e) => setDate(e.target.value)}
                                    value={Date}
                                    size='small'
                                    type='date'
                                    helperText='Date'

                                />
                            </Grid>
                            

                            <Grid item xs={8} sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
                                <FormLabel> Choose Slot &nbsp;  &nbsp;</FormLabel>
                                <RadioGroup
                                    row
                                    aria-label="slots"
                                    name="slot"
                                    value={Slot}
                                    onChange={(e) => setSlot(e.target.value)}
                                >
                                    <FormControlLabel value="Morning 9:00 AM - 12:00 PM" control={<Radio />} label="Morning (9AM-12PM)" />
                                    <FormControlLabel value="Afternoon 12:30 - 4:00 PM" control={<Radio />} label="Afternoon (12:30PM-4PM)" />
                                    <FormControlLabel value="Evening 4:00 - 6:30 PM" control={<Radio />} label="Evening (4PM-6:30PM)" />
                                </RadioGroup>
                            </Grid>
               
                           


                            




                        </Grid>

                        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2, mb: 4 }}>
                            <Button
                                type="reset"
                                variant="contained"
                                endIcon={<ClearIcon />}
                                sx={{ mr: 2 }}
                                onClick={resetFields}
                            >
                                Reset
                            </Button>
                            <Button
                                type="submit"
                                variant="contained"
                                endIcon={<UpdateIcon />}
                            >
                                Reschedule Appointment
                            </Button>
                        </Box>
            
                    </Box>
                </Box>
                <Snackbar
                    open={isSnackbarOpen}
                    autoHideDuration={3000}
                    onClose={handleSnackbarClose}
                    anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                >
                    <MuiAlert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
                        {SnackbarMessage}
                    </MuiAlert>
                </Snackbar>
                <Snackbar
                    open={isInfoSnackbarOpen}
                    autoHideDuration={4000}
                    onClose={() => setIsInfoSnackbarOpen(false)}
                    anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                >
                    <MuiAlert onClose={() => setInfoSnackbarMessage(false)} severity="info" sx={{ width: '100%' }}>
                        {infoSnackbarMessage}
                    </MuiAlert>
                </Snackbar>

                <Snackbar
        open={isErrorSnackbarOpen}
        autoHideDuration={3000}
        onClose={() => setIsErrorSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <MuiAlert onClose={() => setIsErrorSnackbarOpen(false)} severity="warning" sx={{ width: '100%' }}>
          {errorSnackbarMessage}
        </MuiAlert>
      </Snackbar>

            </Container>
        </React.Fragment>
    )
}

export default RescheduleAppointment;
