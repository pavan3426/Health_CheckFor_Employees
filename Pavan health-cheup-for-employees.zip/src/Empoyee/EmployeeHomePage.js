import React from 'react'
import Card from '@mui/material/Card';
import Grid from '@mui/material/Unstable_Grid2';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import Container from '@mui/material/Container';
import ImageList from '@mui/material/ImageList';
import ImageListItem from '@mui/material/ImageListItem';
import Navbar from '../NavBar'
import BookAppointmentsimg from'../EmployeeIcons/BookAppointment2.png'
import CancelAppointmentsimg from'../EmployeeIcons/CancelAppointment.png'
import RescheduleAppointmentsimg from'../EmployeeIcons/RescheduleAppointment2.png'
import HealthStatusImg from'../EmployeeIcons/HealthStatus.png'
import SearchPolicy from '../EmployeeIcons/SearchPolicy.png'
import { Link } from 'react-router-dom';
const EmployeeHomePage = () => {
  let cards = [
    {
        title: "Book Appointment",
        image: BookAppointmentsimg,
        link: '/bookAppointment',
        id: 1
    },
    {
        title: "Reschedule Appointment",
        image: RescheduleAppointmentsimg,
        link: '/rescheduleAppointment',
        id: 2
    },
    {
        title: "Cancel Appointment",
        image: CancelAppointmentsimg,
        link: '/cancelAppointment',
        id: 3
    },
    {
        title: "Check Health Status",
        image: HealthStatusImg,
        link: '/healthStatus',
        id: 4
    },
    {
      title: "Search Policies",
      image: SearchPolicy,
      link: '/CheckPolicies',
      id: 5
  },
    
    
  ]

  return (
    <React.Fragment>
      <Navbar />
      <Grid   sx={{
            marginTop: 1,
            display: 'flex',
            flexDirection: 'column',
            marginLeft : 3
            // alignItems: 'center',
          }}>
       <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 1 }} 
       > 
       Welcome To Employee Home Page
       </Typography> 
         </Grid>

      <Container sx={{ py: 4 }} maxWidth="lg">
        <Grid container spacing={4}>
          {cards.map((card) => (
            <Grid item key={card.id} xs={12} sm={6} md={4} lg={4} >
              <CardActionArea component={Link} to={card.link}>
                <Card sx={{ height: '70%', display: 'flex', flexDirection: 'column', justifyContent:'center', alignItems:'center' }}>
                  <ImageList sx={{ width: 200,m:1 }}>
                    <ImageListItem>
                      <img src={card.image} alt={card.title} />
                    </ImageListItem>
                  </ImageList>
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Typography gutterBottom variant="h5" component="h2" sx={{textAlign:'center'}} >
                      {card.title}
                    </Typography>
                  </CardContent>
                </Card>
              </CardActionArea>
            </Grid>
          ))}
        </Grid>
      </Container>
    </React.Fragment>
  )
}

export default EmployeeHomePage
