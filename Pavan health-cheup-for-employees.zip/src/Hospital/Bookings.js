import React, { useState } from 'react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import axios from 'axios';
import Navbar from '../NavBar';
import { Stack } from '@mui/material';
import { parseISO, format } from 'date-fns';

const DateRangeDataPage = () => {
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [tableData, setTableData] = useState([]);
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(5);

    const fetchData = () => {
        const dates = {
            StartDate: startDate,
            EndDate: endDate
        };
        // console.log(dates);
        const orgName = {
            hospitalName: window.sessionStorage.getItem('organizationName')
        };

        axios
            .post(`http://localhost:3430/Appointment/ViewBookings/${startDate}/${endDate}`, orgName)
            .then((response) => {
                setTableData(response.data);
                // console.log(response.data);
            })
            .catch((error) => {
                console.error('Error fetching data:', error);
            });
    };

    const clearTable = () => {
        setTableData([]);
        setStartDate('');
        setEndDate('');
    };

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };

    const columns = [
        { id: 'applicationId', label: 'Application Id', minWidth: 100, align: 'left' },
        { id: 'employeeName', label: 'Patient Name', minWidth: 120, align: 'left' },
        { id: 'companyName', label: 'Company Name', minWidth: 170, align: 'left' },
        { id: 'agencyName', label: 'Agency Name', minWidth: 170, align: 'left' },
        // { id: 'hospitalId', label: 'Hospital', minWidth: 170 ,align: 'left'},
        // { id: 'hospitalName', label: 'Name', minWidth: 170 ,align: 'left'},
        // { id: 'name', label: 'Name', minWidth: 170 ,align: 'left'},
        { id: 'policyName', label: 'Policy Name', minWidth: 170, align: 'left' },
        { id: 'purpose', label: 'Purpose', minWidth: 170, align: 'left' },
        { id: 'date', label: 'Date', minWidth: 170, align: 'left' },
        { id: 'slot', label: 'Slot', minWidth: 170, align: 'left' },
        { id: 'status', label: 'Status', minWidth: 170, align: 'left' }


    ];


    return (
        <React.Fragment>
            <Navbar />
            <Container component="main" maxWidth="lg">
                <Box
                    sx={{
                        marginTop: 4,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        boxShadow: 8,
                    }}
                >
                    <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 4 }}>
                        View Bookings
                    </Typography>
                    <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '100%' }} >

                        <Grid container spacing={2} justifyContent="center">
                            <Stack spacing={2} direction="row" alignItems="center" justifyContent="space-between">

                                <TextField
                                    required
                                    fullWidth
                                    id="startDate"
                                    onChange={(e) => setStartDate(e.target.value)}
                                    // style={{backgroundColor : '#f5f5dc' }}
                                    value={startDate}
                                    size='small'
                                    type='date'
                                />
                                <TextField
                                    required
                                    fullWidth
                                    id="endDate"
                                    onChange={(e) => setEndDate(e.target.value)}
                                    value={endDate}
                                    size='small'
                                    type='date'
                                />

                                <Button variant="contained" color="primary" sx={{ width: 350 }} onClick={fetchData}>
                                    Fetch Data
                                </Button>
                                <Button variant="outlined" color="secondary" sx={{ width: 350 }} onClick={clearTable}>
                                    Clear Table
                                </Button>
                            </Stack>
                        </Grid>

                        <Box sx={{ mt: 3, mr: 4, ml: 4, width: '100%', maxWidth: '95%', marginTop: '20px' }}>
                            <TableContainer component={Paper} sx={{ width: '100%', overflowX: 'scroll' }}>
                                <Table sx={{ minWidth: 800 }}>
                                    <TableHead>
                                        <TableRow>
                                            {columns.map((column) => (
                                                <TableCell key={column.id} align={column.align} 
                                                style={{ minWidth: column.minWidth, fontWeight: 'bold', color: 'black',backgroundColor:'#808080' }}
                                                
                                                >
                                                    {column.label}
                                                </TableCell>
                                            ))}
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {tableData
                                            .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                            .map((row) => (
                                                <TableRow hover role="checkbox" tabIndex={-1} key={row.id}>
                                                    {columns.map((column) => {
                                                        const value = row[column.id];
                                                        if (column.id === 'date') {
                                                            // Format the date to display only the date part
                                                            const formattedDate = format(new Date(value), 'dd-MM-yyyy');
                                                            return (
                                                              <TableCell key={column.id} align={column.align}>
                                                                {formattedDate}
                                                              </TableCell>
                                                            );
                                                          }
                                                        return (
                                                            <TableCell key={column.id} align={column.align}>
                                                                {column.format && typeof value === 'number' ? column.format(value) : value}
                                                            </TableCell>
                                                        );
                                                    })}
                                                </TableRow>
                                            ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                            <TablePagination
                                rowsPerPageOptions={[10, 25, 100]}
                                component="div"
                                count={tableData.length}
                                rowsPerPage={rowsPerPage}
                                page={page}
                                onPageChange={handleChangePage}
                                onRowsPerPageChange={handleChangeRowsPerPage}
                            />
                        </Box>
                    </Box>
                </Box>
            </Container>
        </React.Fragment>
    );
};

export default DateRangeDataPage;

