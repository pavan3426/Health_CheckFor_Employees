import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { useState,useEffect } from 'react';
import ClearIcon from '@mui/icons-material/Clear';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import UpdateIcon from '@mui/icons-material/Update';
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import { MenuItem } from '@material-ui/core';
import Navbar from '../NavBar';
import axios from 'axios';


const ModifyHospitalDetails = () => {
  const [HospitalName, setHospitalName] = useState("");
  const [HospitalId, setHospitalId] = useState("");
  const[HospitalList, setHospitalList] = useState([]);
  const[HospitalAddress, setHospitalAddress] =useState("");
  const [isSnackbarOpen, setIsSnackbarOpen] = React.useState(false);
  const [SnackbarMessage, setSnackbarMessage] = React.useState('')

useEffect( ()=> {
  axios
  .get("http://localhost:3427/Hospital/findAll")
      .then((response) => {

          setHospitalList(response.data);
        
      })
      .catch((error) => {
        console.error("Error fetching roles:", error);
      });
  }, []);
  // console.log(HospitalList);

  const resetFields = () => {
    setHospitalName("");
    setHospitalId("");
    setHospitalAddress("");

  };

  const handleSnackbarClose = () => {
    setIsSnackbarOpen(false);
  };

  function submitHandler(event) {
    event.preventDefault();

    const newHospital  ={
      hospitalId:HospitalId,
      hospitalName:HospitalName,
      hospitalAddress: HospitalAddress
    };
    
    console.log(newHospital);
        axios.post('http://localhost:3427/Hospital/updateHospital',newHospital)
        .then((response) => {
          setHospitalName("");
          setHospitalId("");
          setHospitalAddress("");
          setSnackbarMessage("Agency added Successfully")
          setIsSnackbarOpen(true);
        })
        .catch((error) => {
          // console.log("Error sending data:" , error);
          // alert(error.response.data);
          // if (error.response && error.response.data) {
          //   // Set a specific error message based on the response data
          //   setSnackbarMessage('Hospital ID is already present. Please choose another ID.');
          // } else {
            setSnackbarMessage('An error occurred while updating Hospital');
          // }
          setIsSnackbarOpen(true);
        }
        )
    
    // }
  };


  const handleHospitalIdChange = (event) => {
    const selectedHospitalId = event.target.value;
    setHospitalId(selectedHospitalId);

    // Find the selected hospital object from the HospitalList using selectedHospitalId
    const selectedHospital = HospitalList.find((hospital) => hospital.hospitalId === selectedHospitalId);
    if (selectedHospital) {
      setHospitalName(selectedHospital.hospitalName);
      setHospitalAddress(selectedHospital.hospitalAddress);
    }
  };

  

  return (
    <React.Fragment>
      <Navbar />
      <Container component="main" maxWidth="md">
        <Box
          sx={{
            marginTop: 8,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            boxShadow: 8
          }}
        >
          <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 4 }}>
           Modify Hospital Details
           </Typography>
          
            <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '600px' }}  onSubmit={submitHandler}>
              <Grid container spacing={2} justifyContent="center">
                
                 <Grid item xs={12}>

                 <TextField
                  required
                  fullWidth
                  id="HospitalId"
                  label="Hospital Id"
                  onChange={handleHospitalIdChange}
                  value={HospitalId}
                  select // Add select property to indicate it's a dropdown
                  size='small'
                >
                  {/* Render the hospital IDs in the dropdown */}
                  {HospitalList.map((hospital) => (
                    <MenuItem key={hospital.hospitalId} value={hospital.hospitalId}>
                      {hospital.hospitalId}
                    </MenuItem>
                  ))}
                </TextField>
                </Grid>

                  <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    id="HospitalName"
                    label="Hospital Name"
                    onChange={(e) => setHospitalName(e.target.value.toUpperCase())}
                    value={HospitalName}
                    size='small'
                    inputProps={{style:{textTransform:"uppercase"}}}
                    
                   
                  >
                    {/* <MenuItem value ="KIMS" >KIMS</MenuItem> */}
                 
                  </TextField>
                </Grid>


                <Grid item xs={12}>
                  <TextField
                    required
                    fullWidth
                    id="HospitalAddress"
                    label="Hospital Address"
                    onChange={(e) => setHospitalAddress(e.target.value)}
                    value={HospitalAddress}
                    size='small'
                  />
                </Grid>

              </Grid>
            
            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2, mb: 4 }}>
              <Button
                type="reset"
                variant="contained"
                endIcon={<ClearIcon />}
                sx={{ mr: 2 }}
                onClick={resetFields}
              >
                Reset
              </Button>
              <Button
                type="submit"
                variant="contained"
                endIcon={<LocalHospitalIcon />}
              >
              Modify Partner Hospital
              </Button>
              </Box>
            </Box>
          </Box>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={3000}
          onClose={handleSnackbarClose}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MuiAlert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
            {SnackbarMessage}
          </MuiAlert>
        </Snackbar>
      </Container>
    </React.Fragment>
  )
}

export default ModifyHospitalDetails;
