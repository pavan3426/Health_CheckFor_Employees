import * as React from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { useState, useEffect } from 'react';
import ClearIcon from '@mui/icons-material/Clear';
import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import SearchIcon from '@mui/icons-material/Search';
import { MenuItem } from '@material-ui/core';
import MonitorHeartIcon from '@mui/icons-material/MonitorHeart';
import Navbar from '../NavBar';
import axios from 'axios'
import { Stack } from '@mui/material';
import { mt } from 'date-fns/locale';




function arrayBufferToBase64(buffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
 for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

const formatDate = (dateString) => {
  const date = new Date(dateString);
  const day = date.getDate().toString().padStart(2, '0');
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const year = date.getFullYear().toString().slice(-2);
  return `${month}/${day}/${year} [MM-DD-YYYY]`;

};


const UpdatePatientDetails = () => {
  const [CompanyName, setCompanyName] = useState("");
  const [EmployeeId, setEmployeeId] = useState("");
  const [EmployeeName, setEmployeeName] = useState("");
  const [AgencyName, setAgencyName] = useState("");
  const [HospitalName, setHospitalName] = useState("");
  const [HospitalId, setHospitalId] = useState("");
  const [HospitalAddress, setHospitalAddress] = useState("");
  const [PolicyName, setPolicyName] = useState("");
  const [EmailId, setEmailId] = useState("");
  const [purpose, setPurpose] = useState("");
  const [Date, setDate] = useState("");
  const [Slot, setSlot] = useState("");
  const [ApplicationId, setApplicationId] = useState("");
  const [appointmentDetails, setAppointmentDetails] = useState([]);
  const [status, setStatus] = useState("");
  const [isSnackbarOpen, setIsSnackbarOpen] = React.useState(false);
  const [SnackbarMessage, setSnackbarMessage] = React.useState('');
  const [applicationIdError, setApplicationIdError] = useState(false);
  const [imageBytes, setImageBytes] = React.useState(null);
  const [imageField, setImageField] = React.useState('');
  const[DischargeDate,setDischargeDate] = useState("");
  const[dateforBack, setDateForBack] =useState("");
  const [isErrorSnackbarOpen, setIsErrorSnackbarOpen] = React.useState(false);
  const [errorSnackbarMessage, setErrorSnackbarMessage] = React.useState('');


   
  const resetFields = () => {
    setCompanyName("");
    setEmployeeId("");
    setEmployeeName("");
    setAgencyName("");
    setHospitalName("");
    setHospitalId("");
    setHospitalAddress("");
    setPolicyName("");
    setPurpose("");
    setDate("");
    setDateForBack("");
    setSlot("");
    setEmailId("");
    setStatus("");
    setDischargeDate("");
  
  };

  const handleSnackbarClose = () => {
    setIsSnackbarOpen(false);
  };

 
  const ApplicationIdHandle = (e) => {
       // console.log(window.sessionStorage.getItem('organizationName'));
    e.preventDefault();
    setCompanyName("");
    setEmployeeId("");
    setEmployeeName("");
    setAgencyName("");
    setHospitalName("");
    setHospitalId("");
    setHospitalAddress("");
    setPolicyName("");
    setPurpose("");
    setDate("");
    setDateForBack("");
    setSlot("");
    setEmailId("");
    setStatus("");
    setDischargeDate("");
    const orgName = window.sessionStorage.getItem('organizationName');
    const applicationId = {
      applicationId: ApplicationId,
      hospitalName:window.sessionStorage.getItem('organizationName')
    }
    // console.log(applicationId);
    //To get the details of Appointment
    axios
      .post(`http://localhost:3430/Appointment/checkPatient`, applicationId)
      .then((response) => {
        setAppointmentDetails(response.data);
        // Set the fetched data to the respective state variables
        setEmployeeName(response.data.employeeName);
        setAgencyName(response.data.agencyName);
        setHospitalName(response.data.hospitalName);
        setHospitalId(response.data.hospitalId);
        setHospitalAddress(response.data.hospitalAddress);
        setPolicyName(response.data.policyName);
        setPurpose(response.data.purpose);
        setCompanyName(response.data.companyName);
        setEmployeeId(response.data.employeeId);
        setEmailId(response.data.email);
        setDateForBack(response.data.date);
        setSlot(response.data.slot);
       setDate((response.data.date).split("T")[0]);
      }).catch((error) => {
        const mute = error
          
          setIsErrorSnackbarOpen(true);
          setErrorSnackbarMessage('No Application Id Found ');

      });

      
        
    }
    
   
    
  function submitHandler(event) {
    event.preventDefault();
       const updatedData =
     {
      applicationId: ApplicationId,
      employeeName: EmployeeName,
      agencyName: AgencyName,
      hospitalName: HospitalName,
      hospitalId: HospitalId,
      hospitalAddress: HospitalAddress,
      policyName: PolicyName,
      purpose: purpose,
      date: dateforBack,
       // Make sure this is in the correct format (MM/DD/YYYY)
      slot: Slot,
      email: EmailId,
      companyName: CompanyName,
      employeeId: EmployeeId,
      status: status,
      // healthStatus:null,
      dischargeDate:DischargeDate,
      // healthStatus:imageBytes
    };
    // console.log(updatedData);

      if (imageBytes) {
      const reader = new FileReader();
      reader.onload = (e) => {
          const base64Image = e.target.result.split(',')[1];
          // console.log(base64Image);
          sendData(base64Image); // Call the function to send data
      };
      reader.readAsDataURL(imageBytes); // Read the image as Base64
  } else {
      sendData(null); // Call the function to send data without image
  }
    
  const sendData = async (base64Image) => {
      // console.log(base64Image);
      // console.log(updatedData);
    // Send the updated data to the backend
    try{
    const response = await axios.post(`http://localhost:3430/Appointment/UploadReports`, {
      ...updatedData,
      healthStatus: base64Image
    });
    // console.log(base64Image);
    const updatedAppointmentData = response.data;

    setIsSnackbarOpen(true);
    setCompanyName("");
    setEmployeeId("");
    setEmployeeName("");
    setAgencyName("");
    setHospitalName("");
    setHospitalId("");
    setHospitalAddress("");
    setPolicyName("");
    setPurpose("");
    setDate("");
    setSlot("");
    setEmailId("");
    setStatus("");
    // setImageBytes(null);

    setSnackbarMessage("Patient Health Status Updated Successfully");
    setIsSnackbarOpen(true);
  } catch (error) {
    console.error('Error updating appointment:', error);
  }
};
  }
    

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    // Handle the uploaded file, e.g., send it to the server
    console.log('Uploaded file:', file);
    setImageBytes(file);
  };

  return (
    <React.Fragment>
      <Navbar />
      <Container component="main" maxWidth="lg">
        <Box
          sx={{
            marginTop: 3,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            boxShadow: 8
          }}
        >
          <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 4 }}>
            Update Patient Health Status
          </Typography>

          <Box component="form" sx={{ mt: 3, width: '100%', maxWidth: '900px' }} onSubmit={submitHandler}>
            <Grid container spacing={2} justifyContent="center">
              <Grid item xs={12}>
                <Stack spacing={2} direction="row" alignItems="center" justifyContent="space-between">
                  <TextField
                    required
                    fullWidth
                    id="ApplicationId"
                    label="Application Id"
                    onChange={(e) => setApplicationId(e.target.value)}
                    value={ApplicationId}
                    size='small'
                    error={applicationIdError}
                    helperText={applicationIdError ? 'Application ID is required' : ''}
                  >
                  </TextField>
                  <Button
                    variant="contained"
                    color="secondary"
                    sx={{ width: '250px' }}
                    endIcon={<SearchIcon />}
                    onClick={ApplicationIdHandle}
                  >
                    Search
                  </Button>
                </Stack>
              </Grid>

              <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  id="EmployeeName"
                  label="Employee Name"
                  onChange={(e) => setHospitalName(e.target.value)}
                  value={EmployeeName}
                  size='small'
                  aria-readonly
                >
                </TextField>
              </Grid>
              <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  id="HospitalName"
                  label="Hospital Name"
                  onChange={(e) => setHospitalName(e.target.value)}
                  value={HospitalName}
                  size='small'
                  inputProps={{ style: { textTransform: "uppercase" } }}
                  aria-readonly
                >
                </TextField>
              </Grid>
              <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  id="ComanyName"
                  label="Company Name"
                  onChange={(e) => setCompanyName(e.target.value)}
                  value={CompanyName}
                  size='small'
                  aria-readonly
                >

                </TextField>
              </Grid>
              <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  id="EmployeeId"
                  label="Employee Id"
                  onChange={(e) => setEmployeeId(e.target.value)}
                  value={EmployeeId}
                  size='small'
                  aria-readonly
                >
                </TextField>
             </Grid>

             <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  id="AgencyName"
                  label="Agency Name"
                  onChange={(e) => setAgencyName(e.target.value)}
                  value={AgencyName}
                  size='small'
                  aria-readonly
                >
                </TextField>
              </Grid>

              <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  id="HospitalId"
                  label="Hospital Id"
                  onChange={(e) => setHospitalId(e.target.value)}
                  value={HospitalId}
                  size='small'
                  aria-readonly
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  required
                  fullWidth
                  id="HospitalAddress"
                  label="Hospital Address"
                  onChange={(e) => setHospitalAddress(e.target.value)}
                  value={HospitalAddress}
                  size='small'
                  aria-readonly
                />
              </Grid>
              <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  id="EmailId"
                  label="Email Id"
                  onChange={(e) => setPurpose(e.target.value)}
                  value={EmailId}
                  size='small'
                  aria-readonly
                >
                </TextField>
              </Grid>

              <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  id="PolicyName"
                  label="Policy Name"
                  onChange={(e) => setHospitalName(e.target.value)}
                  value={PolicyName}
                  size='small'
                  aria-readonly
                >
                </TextField>
              </Grid>
              <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  id="purpose"
                  label="Purpose"
                  onChange={(e) => setPurpose(e.target.value)}
                  value={purpose}
                  size='small'
                  aria-readonly
                >

                </TextField>
              </Grid>

              <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  id="Date"
                  onChange={(e) => setDate(e.target.value)}
                  value={Date}
                  size='small'
                  type='date'
                  helperText='Appointment Date'
                  
              // aria-readonly
                />
              </Grid>

              <Grid item xs={4} sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center',mt:'2' }}>
                <TextField
                
                  required
                  fullWidth
                  id="Slot"
                  label="Slot"
                  onChange={(e) => setSlot(e.target.value)}
                  value={Slot}
                  size='small'
                  aria-readonly

                />
              </Grid>

              <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  id="status"
                  label="status"
                  onChange={(e) => setStatus(e.target.value)}
                  value={status}
                  size='small'
                  aria-readonly
                >

                </TextField>
              </Grid>
              
              <Grid item xs={4}>
                <TextField
                  required
                  fullWidth
                  type="date"
                  id="DiscgargeDate"
                 helperText="Discharge Date"
                  onChange={(e) => setDischargeDate(e.target.value)}
                  value={DischargeDate}
                  size='small'
                  // aria-readonly

                >

                </TextField>
              </Grid>


              {/* <Grid item xs={12}  sx={{ flow: 'flex' ,flexDirection: 'column'}} > */}


               
              <Grid item xs={8}>
                <TextField
                  fullWidth
                  name="imageField"
                  helperText="Patient Reports"
                  type='file'
                  accept=".png,.jpeg,.jpg,.pdf"
                 value={imageField.name} // Show the selected file's name
                  onChange={handleFileUpload}
                  inputProps={{ accept: '.png,.jpeg,.jpg,.pdf' }}
                  size="small"
                />
              </Grid>

            </Grid>


            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2, mb: 4 }}>
              <Button
                type="reset"
                variant="contained"
                endIcon={<ClearIcon />}
                sx={{ mr: 2 }}
                onClick={resetFields}
              >
                Clear Fields
              </Button>
              <Button
                type="submit"
                variant="contained"
                endIcon={<MonitorHeartIcon />}
              >
                Update Reports
              </Button>
            </Box>
          </Box>
        </Box>
        <Snackbar
          open={isSnackbarOpen}
          autoHideDuration={3000}
          onClose={handleSnackbarClose}
          anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        >
          <MuiAlert onClose={handleSnackbarClose} severity="success" sx={{ width: '100%' }}>
            {SnackbarMessage}
            </MuiAlert>
          
        </Snackbar>

        <Snackbar
        open={isErrorSnackbarOpen}
        autoHideDuration={3000}
        onClose={() => setIsErrorSnackbarOpen(false)}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <MuiAlert onClose={() => setIsErrorSnackbarOpen(false)} severity="warning" sx={{ width: '100%' }}>
          {errorSnackbarMessage}
        </MuiAlert>
      </Snackbar>

      </Container>
    </React.Fragment>
  )
}

export default UpdatePatientDetails;
