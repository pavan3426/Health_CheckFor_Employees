import React from 'react'
import Card from '@mui/material/Card';
import Grid from '@mui/material/Unstable_Grid2';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import Container from '@mui/material/Container';
import ImageList from '@mui/material/ImageList';
import ImageListItem from '@mui/material/ImageListItem';
import Navbar from '../NavBar'
import AddHospitalImg from '../HospitalIcons/AddHospital.png'
import UpdateHospitalImg from '../HospitalIcons/UpdateHospital.png'
import UpdatePatientStatusImg from '../HospitalIcons/UpdatePatientStatus.png'
import Bookings from '../Hospital/Bookings';
import ViewBookings from '../HospitalIcons/ViewBookings.png'
import { Link } from 'react-router-dom';
const HospitalHomePage = () => {
  let cards = [
    {
      title: "Update Patient Status",
      image: UpdatePatientStatusImg,
      link: '/updatePatientStatus',
      id: 1
    },{
      title: "View Bookings",
      image: ViewBookings,
      link: '/viewBookings',
      id: 2
    },
    // {
    //     title: "Add New Hospital",        
    //     image: AddHospitalImg,
    //     link: '/addNewHospital',
    //     id: 1
    // },
    // {
    //     title: "Modify Hospital Details",       
    //     image: UpdateHospitalImg,
    //     link: '/modifyHospitalDetails',
    //     id: 2
    // },

  
]
const hospitalName = window.sessionStorage.getItem('organizationName');

  return (
    <React.Fragment>
      <Navbar />
      <Grid  container
       sx={{
            marginTop: 1,
            display: 'flex',
            flexDirection: 'column',
            marginLeft : 3
            // alignItems: 'center',
          }}>
       <Typography component="h1" variant="h5" fontWeight='bold' sx={{ mt: 1 }} 
       > 
       Welcome To {hospitalName} Hospital Admin Page
       </Typography> 
         </Grid>

      <Container sx={{ py: 4 }} maxWidth="lg">
        <Grid container spacing={3}>
          {cards.map((card) => (
            <Grid item key={card.id} xs={12} sm={6} md={4} lg={4} >
              <CardActionArea component={Link} to={card.link}>
                <Card sx={{ height: '70%', display: 'flex', flexDirection: 'column', justifyContent:'center', alignItems:'center'}}>
                  <ImageList sx={{ width: 200, m: 1 }}>
                    <ImageListItem>
                      <img src={card.image} alt={card.title} />
                    </ImageListItem>
                  </ImageList>
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Typography gutterBottom variant="h5" component="h2" sx={{textAlign:'center'}}>
                      {card.title}
                    </Typography>
                  </CardContent>
                </Card>
              </CardActionArea>
            </Grid>
          ))}
        </Grid>
      </Container>
    </React.Fragment>
  )
}

export default HospitalHomePage
