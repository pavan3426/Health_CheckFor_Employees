package HCE.EmployeeModule.Service;


import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import HCE.EmployeeModule.Entity.AppointmentEO;
import HCE.EmployeeModule.Interface.AppointmentInterface;
import HCE.EmployeeModule.Repository.AppointmentRepository;


/**
 * Service class for managing appointment-related operations.
 * Author: Pavan Kumar Boyapati
 */
@Service
@Transactional
public class AppointmentService implements AppointmentInterface {

	
	@Autowired
	private AppointmentRepository appointmentRepository;
	
	@Autowired
    private JavaMailSender javaMailSender; 
	  
	 /**
     * Send an email.
     *
     * @param to The recipient's email address.
     * @param subject The subject of the email.
     * @param text The content of the email.
     */
	
    public void sendEmail(String to, String subject, String text) {
        // TODO Auto-generated method stub

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(text);
        javaMailSender.send(message);
    }
	
    /**
     * Book an appointment.
     *
     * @param appointment The appointment entity to book.
     * @return The booked appointment entity.
     */
	public AppointmentEO bookAppointment(AppointmentEO appointment) {
        // Fetch the last application ID from the collection
        String lastApplicationId = getLastApplicationId();
        if(lastApplicationId == null){
        	 return appointmentRepository.save(appointment);
        }

        // Generate the new application ID by incrementing the last one
        String newApplicationId = generateNewApplicationId(lastApplicationId);

        // Set the new application ID and save the appointment
        appointment.setApplicationId(newApplicationId);
        return appointmentRepository.save(appointment);
    }

	 /**
     * Generate a new application ID by incrementing the last one.
     *
     * @param lastApplicationId The last used application ID.
     * @return The new application ID.
     */
    private String generateNewApplicationId(String lastApplicationId) {
        int lastId = Integer.parseInt(lastApplicationId);
        int newId = lastId + 1;
        return String.valueOf(newId);
    }
   
    /**
     * Find an appointment by its ID and agency name.
     *
     * @param id The ID of the appointment.
     * @param agencyName The name of the agency associated with the appointment.
     * @return An optional containing the found appointment entity, or empty if not found.
     */
	public Optional<AppointmentEO> findByIdAndAgencyName(String id,String agencyName){
		 return appointmentRepository.findByIdAndAgencyName(id,agencyName);
	}
	

    /**
     * Get the last application ID from the collection.
     *
     * @return The last application ID, or null if not found.
     */
    public String getLastApplicationId() {
	        AppointmentEO lastAppointment = appointmentRepository.findTopByOrderByApplicationIdDesc();
	        if (lastAppointment != null) {
	            return lastAppointment.getApplicationId();
	        }
	        return null; // No documents found
	    }
    /**
     * Find appointments within a date range and associated with a specific hospital name.
     *
     * @param start The start date of the range.
     * @param end The end date of the range.
     * @param hospitalName The name of the hospital associated with the appointments.
     * @return A list of appointment entities within the specified date range and hospital name.
     */
	    
    public List<AppointmentEO> findByDateBetweenAndHospitalName(Date start, Date end, String hospitalName) {
        return appointmentRepository.findByDateBetweenAndHospitalName(start, end, hospitalName);
    }
    
    /**
     * Get all appointments.
     *
     * @return A list of all appointment entities.
     */
    public List<AppointmentEO> getAllAppointments() {
        return appointmentRepository.findAll();
    }
    /**
     * Find appointments associated with a specific employee ID.
     *
     * @param employeeId The ID of the employee associated with the appointments.
     * @return A list of appointment entities associated with the specified employee ID.
     */
    public List<AppointmentEO> findByEmpId(String employeeId) {
        return appointmentRepository.findByEmployeeId(employeeId);
    }


    /**
     * Find appointments associated with a specific agency name.
     *
     * @param agencyName The name of the agency associated with the appointments.
     * @return A list of appointment entities associated with the specified agency name.
     */
    public List<AppointmentEO> getAppointmentsByAgencyName(String agencyName) {
        return appointmentRepository.findByAgencyName(agencyName);
    }

    /**
     * Find an appointment by its ID.
     *
     * @param id The ID of the appointment.
     * @return An optional containing the found appointment entity, or empty if not found.
     */
	@Override
	public Optional<AppointmentEO> findById(String id) {
		// TODO Auto-generated method stub
		return appointmentRepository.findById(id);
	}



	
   
	    

	    
}
