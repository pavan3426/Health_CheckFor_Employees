package HCE.EmployeeModule;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.core.io.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.MediaType;

import HCE.EmployeeModule.Entity.AppointmentEO;
import HCE.EmployeeModule.Repository.AppointmentRepository;
import HCE.EmployeeModule.Service.AppointmentService;

/**
 * Controller class for managing appointment-related operations. Author: Pavan
 * Kumar Boyapati
 */

@RestController
@RequestMapping("/Appointment")
@CrossOrigin(origins = "http://localhost:3000") // Adjust origin as needed

public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;

	@Autowired
	private AppointmentRepository appRepo;

	/**
	 * Book an appointment or update an existing one.
	 *
	 * @param appointEO
	 *            The appointment entity to be booked or updated.
	 * @return The application ID of the booked or updated appointment.
	 */

	@RequestMapping(value = "/Book", method = RequestMethod.POST)
	public String bookAppoint(@RequestBody AppointmentEO appointEO) {
		AppointmentEO newAppointment;
		if (appointEO.getApplicationId() == null) {
			appointEO.setApplicationId("15082301");
			newAppointment = appointmentService.bookAppointment(appointEO);

			String template = "Your Appointment Details\n\n" + "Hello " + newAppointment.getEmployeeName() + ",\n\n"
					+ "Thank you for booking an appointment with " + newAppointment.getHospitalName() + " through "
					+ newAppointment.getAgencyName() + ". Here are your appointment details:\n\n" + "- Appointment ID: "
					+ newAppointment.getApplicationId() + "\n" + "- Hospital: " + newAppointment.getHospitalName()
					+ "\n" + "-Hospital Address: " + newAppointment.getHospitalAddress() + "\n" + "- Date: "
					+ newAppointment.getDate() + "\n" + "- Slot: " + newAppointment.getSlot() + "\n\n"
					+ "Please note that your appointment is currently in " + newAppointment.getStatus() + " status.\n\n"
					+ "If you have any questions or need further assistance, please contact us via mail.\n\n"
					+ "Best regards,\n" + newAppointment.getAgencyName();

			// Then use the template in your email sending code
			appointmentService.sendEmail(newAppointment.getEmail(), "Your Appointment Details", template);

			return newAppointment.getApplicationId();

		} else {

			newAppointment = appointmentService.bookAppointment(appointEO);
			String template = "Your Appointment Details\n\n" + "Hello " + newAppointment.getEmployeeName() + ",\n\n"
					+ "Thank you for booking an appointment with " + newAppointment.getHospitalName() + " through "
					+ newAppointment.getAgencyName() + ". Here are your appointment details:\n\n" + "- Appointment ID: "
					+ newAppointment.getApplicationId() + "\n" + "- Hospital: " + newAppointment.getHospitalName()
					+ "\n" + "-Hospital Address: " + newAppointment.getHospitalAddress() + "\n" + "- Date: "
					+ newAppointment.getDate() + "\n" + "- Slot: " + newAppointment.getSlot() + "\n\n"
					+ "Please note that your appointment is currently in " + newAppointment.getStatus() + " status.\n\n"
					+ "If you have any questions or need further assistance, please contact us via mail.\n\n"
					+ "Best regards,\n" + newAppointment.getAgencyName();

			return appointEO.getApplicationId();
		}
	}

	/**
	 * Reschedule an existing appointment.
	 *
	 * @param appointEO
	 *            The appointment entity to be rescheduled.
	 * @return The rescheduled appointment entity if successful, or "Not Found"
	 *         if not.
	 */
	@RequestMapping(value = "/Reschedule", method = RequestMethod.POST)
	public ResponseEntity<Object> reschedule(@RequestBody AppointmentEO appointEO) {
		Optional<AppointmentEO> app = appointmentService.findById(appointEO.getApplicationId());
		if (app.get().getEmployeeId().equals(appointEO.getEmployeeId())
				&& (app.get().getStatus().equals("Pending") || app.get().getStatus().equals("Approved"))) {

			return ResponseEntity.ok(app.get());
		} else {
			return ResponseEntity.ok("Not Found");
		}
	}

	/**
	 * Cancel an appointment by the patient.
	 *
	 * @param appointEO
	 *            The appointment entity to be cancelled.
	 * @return The cancelled appointment entity if successful, or a 404 response
	 *         if not found.
	 */
	@RequestMapping(value = "/cancelledByPatient", method = RequestMethod.POST)
	public ResponseEntity<Object> cancelled(@RequestBody AppointmentEO appointEO) {
		Optional<AppointmentEO> app = appointmentService.findById(appointEO.getApplicationId());
		if (app.isPresent()) {
			String rescheduledTemplate = "Cancelled Appointment Details\n\n" + "Hello " + appointEO.getEmployeeName()
					+ ",\n\n" + "We want to inform you that your appointment with " + appointEO.getHospitalName()
					+ " through " + appointEO.getAgencyName()
					+ " has cancelled by you. Here are the Appointment details:\n\n" + "- Appointment ID: "
					+ appointEO.getApplicationId() + "\n" + "- Hospital: " + appointEO.getHospitalName() + "\n"
					+ "- Date: " + appointEO.getDate() + "\n" + "- Slot: " + appointEO.getSlot() + "\n\n" +

					"Please note that your appointment is cancelled by you.\n\n"
					+ "If you have any questions or need further assistance, please contact us.\n\n" + "Best regards,\n"
					+ appointEO.getAgencyName();

			// Then use the template in your email sending code
			appointmentService.sendEmail(appointEO.getEmail(), "Rescheduled Appointment Details", rescheduledTemplate);

			return ResponseEntity.ok(app.get());
		} else {
			return ResponseEntity.ok("Not Found"); // Return a 404 Not Found
													// response
		}
	}

	/**
	 * Check if the appointment's hospital name matches the provided hospital
	 * name.
	 *
	 * @param appointEO
	 *            The appointment entity to be checked.
	 * @return The appointment entity if hospital names match, or a 404 response
	 *         if not found.
	 */
	@RequestMapping(value = "/checkPatient", method = RequestMethod.POST)
	public ResponseEntity<Object> CheckPatient(@RequestBody AppointmentEO appointEO) {
		Optional<AppointmentEO> app = appointmentService.findById(appointEO.getApplicationId());

		if (app.isPresent()) {
			boolean flag = app.get().getHospitalName().equals(appointEO.getHospitalName());

			if (flag == true) {
				return ResponseEntity.ok(app);
			}

			return ResponseEntity.ok("Not Found");

		} else {

			return ResponseEntity.ok("Not Found");
		}
	}

	/**
	 * Get the last application ID from the collection.
	 *
	 * @return The last application ID if found, or a 404 response if not found.
	 */
	@GetMapping("/last-application-id")
	public ResponseEntity<String> getLastApplicationId() {
		String lastApplicationId = appointmentService.getLastApplicationId();
		if (lastApplicationId != null) {
			return ResponseEntity.ok(lastApplicationId);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No documents found.");
		}
	}

	/**
	 * Update an existing appointment.
	 *
	 * @param updatedAppointment
	 *            The updated appointment entity.
	 * @return The updated appointment entity if successful, or a 404 response
	 *         if not found.
	 */

	@PostMapping("/Update")
	public ResponseEntity<Object> updateAppointment(@RequestBody AppointmentEO updatedAppointment) {
		Optional<AppointmentEO> existingAppointment = appointmentService
				.findById(updatedAppointment.getApplicationId());

		if (existingAppointment.isPresent()) {
			AppointmentEO appointmentToUpdate = existingAppointment.get();
			// Update fields as needed
			appointmentToUpdate.setCompanyName(updatedAppointment.getCompanyName());
			appointmentToUpdate.setEmployeeId(updatedAppointment.getEmployeeId());
			appointmentToUpdate.setAgencyName(updatedAppointment.getAgencyName());
			appointmentToUpdate.setEmployeeName(updatedAppointment.getEmployeeName());
			appointmentToUpdate.setHospitalId(updatedAppointment.getHospitalId());
			appointmentToUpdate.setHospitalName(updatedAppointment.getHospitalName());
			appointmentToUpdate.setHospitalAddress(updatedAppointment.getHospitalAddress());
			appointmentToUpdate.setPolicyName(updatedAppointment.getPolicyName());
			appointmentToUpdate.setPurpose(updatedAppointment.getPurpose());
			appointmentToUpdate.setDate(updatedAppointment.getDate());
			appointmentToUpdate.setSlot(updatedAppointment.getSlot());
			appointmentToUpdate.setEmail(updatedAppointment.getEmail());
			appointmentToUpdate.setStatus(updatedAppointment.getStatus());
			// appointmentToUpdate.setHealthstatus(updatedAppointment.getHealthstatus());
			AppointmentEO updated = appRepo.save(appointmentToUpdate);
			appRepo.save(updatedAppointment);

			String rescheduledTemplate = "Rescheduled Appointment Details\n\n" + "Hello "
					+ updatedAppointment.getEmployeeName() + ",\n\n"
					+ "We want to inform you that your appointment with " + updatedAppointment.getHospitalName()
					+ " through " + updatedAppointment.getAgencyName()
					+ " has been rescheduled.\n\n Here are the updated details:\n\n" + "- Appointment ID: "
					+ updatedAppointment.getApplicationId() + "\n" + "- Hospital: "
					+ updatedAppointment.getHospitalName() + "\n" + "- Date: " + updatedAppointment.getDate() + "\n"
					+ "- Slot: " + updatedAppointment.getSlot() + "\n\n"
					+ "Your appointment was previously scheduled for:\n" + "- Date: "
					+ existingAppointment.get().getDate() + "\n" + "- Slot: " + existingAppointment.get().getSlot()
					+ "\n\n" + "Please note that your appointment is now in " + updatedAppointment.getStatus()
					+ " status.\n\n" + "If you have any questions or need further assistance, please contact us.\n\n"
					+ "Best regards,\n" + updatedAppointment.getAgencyName();

			// Then use the template in your email sending code
			appointmentService.sendEmail(updatedAppointment.getEmail(), "Rescheduled Appointment Details",
					rescheduledTemplate);
			return ResponseEntity.ok(updated);

		} else {
			return ResponseEntity.ok("Not Updated");
		}

	}

	/**
	 * Upload health reports and update appointment status.
	 *
	 * @param updateReports
	 *            The appointment entity with updated health reports.
	 * @return The updated appointment entity if successful, or a 404 response
	 *         if not found.
	 */

	@PostMapping("/UploadReports")
	public ResponseEntity<Object> UploadReports(@RequestBody AppointmentEO updateReports) {
		String applicationId = updateReports.getApplicationId();
		// System.out.println(updateReports);
		Optional<AppointmentEO> existingAppointment = appointmentService.findById(applicationId);
		// System.out.println(existingAppointment);
		if (existingAppointment.isPresent()) {
			AppointmentEO appointmentToUpdate = existingAppointment.get();
			// Update fields as needed
			appointmentToUpdate.setStatus(updateReports.getStatus());
			appointmentToUpdate.setDischargeDate(updateReports.getDischargeDate());
			appointmentToUpdate.setHealthStatus(updateReports.getHealthStatus());

			String rescheduledTemplate = "\n\n" + "Hello " + updateReports.getEmployeeName() + ",\n\n"
					+ "Tnaks for choosing  " + updateReports.getHospitalName()
					+ ". I hove you are doing well and good Just Now, we updated your reports  in online and you booked an appointment through "
					+ updateReports.getAgencyName() + "Agency.\n\n Here are the some details of appointment :\n\n"
					+ "- Appointment ID: " + updateReports.getApplicationId() + "\n" + "- Hospital: "
					+ updateReports.getHospitalName() + "\n" + "-Hospital Address" + updateReports.getHospitalAddress()
					+ "\n" + "- Date: " + updateReports.getDate() + "\n" + "- Slot: " + updateReports.getSlot() + "\n"
					+ "-Discharge Date " + updateReports.getDischargeDate() + "\n" + "-Status "
					+ updateReports.getStatus() + "\n\n" +

					"Please note that you can see all the detils in portal for that you just nees login into portal and check it \n\n"
					+ "If you have any questions or need further assistance, please contact us.\n\n" + "Best regards,\n"
					+ updateReports.getHospitalName() + "\n" + updateReports.getHospitalAddress() + ".";

			// Then use the template in your email sending code
			appointmentService.sendEmail(updateReports.getEmail(), "Appointment Approved", rescheduledTemplate);
			appRepo.save(appointmentToUpdate);
			return ResponseEntity.ok("updated");

		} else {
			return ResponseEntity.ok("Uploaded Not Successfull");
		}

	}

	/**
	 * Get appointments within a date range for a specific hospital.
	 *
	 * @param startDate
	 *            The start date of the range.
	 * @param endDate
	 *            The end date of the range.
	 * @param appEO
	 *            The appointment entity containing hospital name.
	 * @return List of appointments within the specified date range for the
	 *         hospital.
	 */
	@RequestMapping(value = "/ViewBookings/{startDate}/{endDate}", method = RequestMethod.POST)
	public ResponseEntity<List<AppointmentEO>> getAppointmentsByDateRange(@PathVariable String startDate,
			@PathVariable String endDate, @RequestBody AppointmentEO appEO) {
		List<AppointmentEO> appointments;
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date startD = dateFormat.parse(startDate);
			Date endD = dateFormat.parse(endDate);

			appointments = appointmentService.findByDateBetweenAndHospitalName(startD, endD, appEO.getHospitalName());
			;

			if (!appointments.isEmpty()) {
				return ResponseEntity.ok(appointments);
			}

		} catch (ParseException e) {

			System.out.println(e);
		}
		return ResponseEntity.ok(new ArrayList<>());
	}

	/**
	 * Get all appointments for a specific agency.
	 *
	 * @param appoint
	 *            The appointment entity containing agency name.
	 * @return List of all appointments for the agency.
	 */
	@PostMapping("/all")
	public ResponseEntity<List<AppointmentEO>> getAllAppointments(@RequestBody AppointmentEO appoint) {
		List<AppointmentEO> appointments = appointmentService.getAppointmentsByAgencyName(appoint.getAgencyName());

		if (!appointments.isEmpty()) {
			return ResponseEntity.ok(appointments);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<>());
		}
	}

	/**
	 * Get all appointments for all agencies.
	 *
	 * @return List of all appointments for all agencies.
	 */
	@GetMapping("/allAppointments")
	public ResponseEntity<List<AppointmentEO>> allAppointmentsForCompany() {
		List<AppointmentEO> appointments = appRepo.findAll();

		if (!appointments.isEmpty()) {
			return ResponseEntity.ok(appointments);
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ArrayList<>());
		}
	}

	/**
	 * Approve an appointment.
	 *
	 * @param appoint
	 *            The appointment entity with updated status.
	 * @return The updated appointment entity if successful, or a 404 response
	 *         if not found.
	 */
	@PostMapping("/approved")
	public ResponseEntity<Object> acceptAppointment(@RequestBody AppointmentEO appoint) {
		Optional<AppointmentEO> updatedAppointment = appointmentService.findById(appoint.getApplicationId());
		if (updatedAppointment.isPresent()) {
			AppointmentEO appointment = updatedAppointment.get();
			appointment.setStatus(appoint.getStatus());
			appRepo.save(appointment);

			String rescheduledTemplate = "\n\n" + "Hello " + appointment.getEmployeeName() + ",\n\n"
					+ "We want to inform you that your appointment with " + appointment.getHospitalName() + " through "
					+ appointment.getAgencyName()
					+ " has been 'Approved' by Agency.\n\n Here are the updated details:\n\n" + "- Appointment ID: "
					+ appointment.getApplicationId() + "\n" + "- Hospital: " + appointment.getHospitalName() + "\n"
					+ "-Hospital Address" + appointment.getHospitalAddress() + "\n" + "- Date: " + appointment.getDate()
					+ "\n" + "- Slot: " + appointment.getSlot() + "\n\n" +

					"Please note that your appointment is now in " + appointment.getStatus() + "  by agency\n\n"
					+ "If you have any questions or need further assistance, please contact us.\n\n" + "Best regards,\n"
					+ appointment.getAgencyName();

			// Then use the template in your email sending code
			appointmentService.sendEmail(appointment.getEmail(), "Appointment Approved", rescheduledTemplate);

			return ResponseEntity.ok(appRepo.save(appointment));
		} else {
			return ResponseEntity.ok("null");
		}

	}

	/**
	 * Reject an appointment.
	 *
	 * @param appoint
	 *            The appointment entity with updated status.
	 * @return The updated appointment entity if successful, or a 404 response
	 *         if not found.
	 */
	@PostMapping("/rejected")
	public ResponseEntity<Object> RejectAppointment(@RequestBody AppointmentEO appoint) {
		Optional<AppointmentEO> updatedAppointment = appointmentService.findById(appoint.getApplicationId());
		if (updatedAppointment.isPresent()) {
			AppointmentEO appointment = updatedAppointment.get();
			appointment.setStatus("Rejected");
			appRepo.save(appointment);

			String rescheduledTemplate = "\n\n" + "Hello " + appointment.getEmployeeName() + ",\n\n"
					+ "We want to inform you that your appointment with " + appointment.getHospitalName() + " through "
					+ appointment.getAgencyName()
					+ " has been 'Rejected' by Agency.\n\n Here are the updated details:\n\n" + "- Appointment ID: "
					+ appointment.getApplicationId() + "\n" + "- Hospital: " + appointment.getHospitalName() + "\n"
					+ "-Hospital Address" + appointment.getHospitalAddress() + "\n" + "- Date: " + appointment.getDate()
					+ "\n" + "- Slot: " + appointment.getSlot() + "\n\n" +

					"Please note that your appointment is now in " + appointment.getStatus() + " by agency\n\n"
					+ "If you have any questions or need further assistance, please contact us.\n\n" + "Best regards,\n"
					+ appointment.getAgencyName();

			// Then use the template in your email sending code
			appointmentService.sendEmail(appointment.getEmail(), "Appointment Rejected", rescheduledTemplate);

			return ResponseEntity.ok(appRepo.save(appointment));
		} else {
			return ResponseEntity.ok("null");
		}

	}

	/**
	 * Get an appointment by its ID and agency name.
	 *
	 * @param appoint
	 *            The appointment entity with application ID and agency name.
	 * @return The appointment entity if found, or a 404 response if not found.
	 */
	@PostMapping("/appointment")
	public ResponseEntity<Optional<AppointmentEO>> GetAppointment(@RequestBody AppointmentEO appoint) {
		// String applicationId = appoint.getApplicationId();

		Optional<AppointmentEO> existingAppointment = appointmentService
				.findByIdAndAgencyName(appoint.getApplicationId(), appoint.getAgencyName());

		if (existingAppointment != null) {
			return ResponseEntity.ok(existingAppointment);
		} else {
			// Return a response with a custom message when no appointments are
			// found

			return (ResponseEntity<Optional<AppointmentEO>>) ResponseEntity.status(HttpStatus.NOT_FOUND);
		}

	}

	/**
	 * Get health status appointments by employee ID.
	 *
	 * @param appEO
	 *            The appointment entity containing employee ID.
	 * @return List of health status appointments for the employee.
	 */
	@PostMapping("/healthStatusByEmpId")
	public ResponseEntity<List<AppointmentEO>> getAppointmentsByempId(@RequestBody AppointmentEO appEO) {
		List<AppointmentEO> appointments = appointmentService.findByEmpId(appEO.getEmployeeId());

		if (appointments != null && !appointments.isEmpty()) {
			return ResponseEntity.ok(appointments);
		} else {
			String message = "No appointments found for employee ID: " + appEO.getEmployeeId();
			return ResponseEntity.notFound().build();
		}

	}

	/**
	 * Get health status report PDF by application ID.
	 *
	 * @param applicationId
	 *            The application ID for the health status report.
	 * @return Health status report PDF as a resource, or a 404 response if not
	 *         found.
	 */
	@GetMapping("/reports/{applicationId}")
	public ResponseEntity<Resource> getPdf(@PathVariable String applicationId) {
		System.out.println("Inside 1");
		System.out.println(applicationId);
		System.out.println("Inside 2");
		AppointmentEO claimEO = appRepo.findById(applicationId).orElse(null); // Assuming
																				// you
																				// can
																				// retrieve
																				// the
																				// document
																				// by
																				// fileId

		System.out.println(claimEO);
		if (claimEO != null) {
			Resource resource = new ByteArrayResource(claimEO.getHealthStatus());
			return ResponseEntity.ok()
					.header(HttpHeaders.CONTENT_DISPOSITION,
							"attachment; filename=\"" + claimEO.getHealthStatus() + "\"")
					.contentType(MediaType.APPLICATION_OCTET_STREAM).contentLength(claimEO.getHealthStatus().length)
					.body(resource);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

}
