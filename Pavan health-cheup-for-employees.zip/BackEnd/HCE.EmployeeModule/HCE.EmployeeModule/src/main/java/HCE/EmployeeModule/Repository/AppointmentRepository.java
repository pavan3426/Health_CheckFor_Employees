package HCE.EmployeeModule.Repository;


import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.http.ResponseEntity;

import HCE.EmployeeModule.Entity.AppointmentEO;

/**
 * Repository interface for managing appointment entities.
 *Author: Pavan Kumar Boyapati
 */
public interface AppointmentRepository extends  MongoRepository<AppointmentEO, String>{
	
	/**
	 * Find the latest appointment by ordering them by application ID in descending order.
	 *
	 * @return The latest appointment entity.
	 */
	AppointmentEO findTopByOrderByApplicationIdDesc();

	/**
	 * Insert an existing appointment entity.
	 *
	 * @param existingAppointment The existing appointment entity to insert.
	 * @return A response entity indicating the success of the insertion.
	 */
	
	ResponseEntity<Object> insert(Optional<AppointmentEO> existingAppointment);

	/**
	 * Find appointments within a date range.
	 *
	 * @param startDate The start date of the range.
	 * @param endDate The end date of the range.
	 * @return A list of appointment entities within the specified date range.
	 */
	
	List<AppointmentEO> findByDateBetween(Date startDate, Date endDate);


	/**
	 * Find appointments within a date range and associated with a specific hospital name.
	 *
	 * @param start The start date of the range.
	 * @param end The end date of the range.
	 * @param hospitalName The name of the hospital associated with the appointments.
	 * @return A list of appointment entities within the specified date range and hospital name.
	 */
	
	List<AppointmentEO> findByDateBetweenAndHospitalName(Date start, Date end, String hospitalName);


	/**
	 * Find appointments associated with a specific employee ID.
	 *
	 * @param employeeId The ID of the employee associated with the appointments.
	 * @return A list of appointment entities associated with the specified employee ID.
	 */
	
	List<AppointmentEO> findByEmployeeId(String employeeId);
	
	/**
	 * Find appointments associated with a specific agency name.
	 *
	 * @param agencyName The name of the agency associated with the appointments.
	 * @return A list of appointment entities associated with the specified agency name.
	 */
	
	List<AppointmentEO> findByAgencyName(String agencyName);
	
	/**
	 * Find an appointment by its ID and agency name using a custom query.
	 *
	 * @param id The ID of the appointment to find.
	 * @param agencyName The name of the agency associated with the appointment.
	 * @return An optional containing the found appointment entity, or empty if not found.
	 */
	
	@Query("{'_id': ?0, 'agencyName': ?1}")
	Optional<AppointmentEO> findByIdAndAgencyName(String id, String agencyName);


	

}
