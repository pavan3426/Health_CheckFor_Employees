package HCE.EmployeeModule.Entity;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Entity class representing booking start and end dates. Author: Pavan Kumar
 * Boyapati
 */
public class BookingsEO {

	/*
	 * Start date of the booking.
	 */
	private Date StartDate;

	/*
	 * End date of the booking.
	 */
	private Date EndDate;

	/**
	 * Default constructor.
	 */
	public BookingsEO() {
		super();
	}

	/**
	 * Parameterized constructor to initialize booking start and end dates.
	 *
	 * @param startDate
	 *            The start date of the booking.
	 * @param endDate
	 *            The end date of the booking.
	 */
	public BookingsEO(Date startDate, Date endDate) {
		super();
		StartDate = startDate;
		EndDate = endDate;
	}

	/**
	 * Get the start date of the booking.
	 *
	 * @return The start date.
	 */
	public Date getStartDate() {
		return StartDate;
	}

	/**
	 * Set the start date of the booking.
	 *
	 * @param startDate
	 *            The start date.
	 */
	public void setStartDate(Date startDate) {

		Date dateString = startDate;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yy:mm:dd");

		try {
			// Now, let's extract year, month, and day to create the equivalent
			// date object
			int year = dateString.getYear() + 1900; // Year is 1900-based
			int month = dateString.getMonth();
			int day = dateString.getDate();

			// Create a Date object using the extracted values
			Date convertedDate = new Date(year, month, day);
			this.StartDate = convertedDate;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Get the end date of the booking.
	 *
	 * @return The end date.
	 */
	public Date getEndDate() {
		return EndDate;
	}

	/**
	 * Set the end date of the booking.
	 *
	 * @param endDate
	 *            The end date.
	 */
	public void setEndDate(Date endDate) {
		Date dateString = endDate;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yy:mm:dd");

		try {
			// Now, let's extract year, month, and day to create the equivalent
			// date object
			int year = dateString.getYear() + 1900; // Year is 1900-based
			int month = dateString.getMonth();
			int day = dateString.getDate();

			// Create a Date object using the extracted values
			Date convertedDate = new Date(year, month, day);
			this.EndDate = convertedDate;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Get the string representation of the booking.
	 *
	 * @return A string representation of booking start and end dates.
	 */
	@Override
	public String toString() {
		return "BookingsEO [StartDate=" + StartDate + ", EndDate=" + EndDate + "]";
	}

}
