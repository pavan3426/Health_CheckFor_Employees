package HCE.EmployeeModule.Interface;


import java.util.Date;
import java.util.List;
import java.util.Optional;

import HCE.EmployeeModule.Entity.AppointmentEO;

/**
 * Interface representing operations related to appointment bookings.
 * Author: Pavan Kumar Boyapati
 */
public interface AppointmentInterface {
	
	/**
	 * Book an appointment by creating a new appointment entity.
	 *
	 * @param appointEO The appointment entity to be booked.
	 * @return The booked appointment entity.
	 */
	
	public AppointmentEO bookAppointment(AppointmentEO appointEO);
	
	/**
	 * Find an appointment by its ID and agency name.
	 *
	 * @param id The ID of the appointment to find.
	 * @param agencyName The name of the agency associated with the appointment.
	 * @return An optional containing the found appointment entity, or empty if not found.
	 */
	
	public Optional<AppointmentEO> findByIdAndAgencyName(String id,String agencyName);
	
	/**
	 * Find an appointment by its ID.
	 *
	 * @param id The ID of the appointment to find.
	 * @return An optional containing the found appointment entity, or empty if not found.
	 */
	
	public Optional<AppointmentEO> findById(String id);
	
	/**
	 * Find appointments within a date range and associated with a specific hospital name.
	 *
	 * @param start The start date of the range.
	 * @param end The end date of the range.
	 * @param hospitalName The name of the hospital associated with the appointments.
	 * @return A list of appointment entities within the specified date range and hospital name.
	 */
	
	 public List<AppointmentEO> findByDateBetweenAndHospitalName(Date start, Date end, String hospitalName);
	 
	
}
