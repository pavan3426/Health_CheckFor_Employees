package HCE.EmployeeModule.Entity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "APPOINTMENT")
/**
 * Entity class representing an appointment.
 *  Author: Pavan Kumar Boyapati
 */
public class AppointmentEO {

	/**
	 * Unique identifier for the appointment.
	 */
	@Id
	private String applicationId;

	/**
	 * Name of the company associated with the appointment.
	 */
	private String companyName;

	/**
	 * Employee ID for the appointment.
	 */
	private String employeeId;

	/**
	 * Name of the agency responsible for the appointment.
	 */
	private String agencyName;

	/**
	 * Name of the employee for the appointment.
	 */
	private String employeeName;

	/**
	 * ID of the hospital for the appointment.
	 */
	private String hospitalId;

	/**
	 * Name of the hospital for the appointment.
	 */
	private String hospitalName;

	/**
	 * Address of the hospital for the appointment.
	 */
	private String hospitalAddress;

	/**
	 * Name of the policy associated with the appointment.
	 */
	private String policyName;

	/**
	 * Purpose or reason for the appointment.
	 */
	private String purpose;

	/**
	 * Date of the appointment.
	 */
	private Date date;

	/**
	 * Time slot for the appointment.
	 */
	private String slot;

	/**
	 * Email address associated with the appointment.
	 */
	private String email;

	/**
	 * Current status of the appointment.
	 */
	private String status;

	private byte[] healthStatus;
	private Date dischargeDate;

	/**
	 * Default constructor.
	 */
	public AppointmentEO() {
		super();
	}


	


	/**
	 * Constructs a new AppointmentEO instance with the provided information.
	 *
	 * @param applicationId   The ID of the application.
	 * @param companyName     The name of the company.
	 * @param employeeId      The ID of the employee.
	 * @param agencyName      The name of the agency.
	 * @param employeeName    The name of the employee.
	 * @param hospitalId      The ID of the hospital.
	 * @param hospitalName    The name of the hospital.
	 * @param hospitalAddress The address of the hospital.
	 * @param policyName      The name of the policy.
	 * @param purpose         The purpose of the appointment.
	 * @param date            The date of the appointment.
	 * @param slot            The time slot of the appointment.
	 * @param email           The email of the employee.
	 * @param status          The status of the appointment.
	 * @param healthStatus    The health status information.
	 * @param dischargeDate   The discharge date, if applicable.
	 */

	public AppointmentEO(String applicationId, String companyName, String employeeId, String agencyName,
			String employeeName, String hospitalId, String hospitalName, String hospitalAddress, String policyName,
			String purpose, Date date, String slot, String email, String status, byte[] healthStatus,
			Date dischargeDate) {
		super();
		this.applicationId = applicationId;
		this.companyName = companyName;
		this.employeeId = employeeId;
		this.agencyName = agencyName;
		this.employeeName = employeeName;
		this.hospitalId = hospitalId;
		this.hospitalName = hospitalName;
		this.hospitalAddress = hospitalAddress;
		this.policyName = policyName;
		this.purpose = purpose;
		this.date = date;
		this.slot = slot;
		this.email = email;
		this.status = status;
		this.healthStatus = healthStatus;
		this.dischargeDate = dischargeDate;
	}

	/**
	 * Get the unique identifier for the appointment.
	 * 
	 * @return The application ID.
	 */
	public String getApplicationId() {
		return applicationId;
	}
	
	/**
	 * Set the unique identifier for the appointment.
	 * 
	 * @param applicationId
	 *            The application ID to set.
	 */
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * Get the name of the company associated with the appointment.
	 * 
	 * @return The company name.
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * Set the name of the company associated with the appointment.
	 * 
	 * @param companyName
	 *            The company name to set.
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * Get the employee ID for the appointment.
	 * 
	 * @return The employee ID.
	 */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
	 * Set the employee ID for the appointment.
	 * 
	 * @param employeeId
	 *            The employee ID to set.
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * Get the name of the agency responsible for the appointment.
	 * 
	 * @return The agency name.
	 */
	public String getAgencyName() {
		return agencyName;
	}

	/**
	 * Set the name of the agency responsible for the appointment.
	 * 
	 * @param agencyName
	 *            The agency name to set.
	 */
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	/**
	 * Get the name of the employee for the appointment.
	 * 
	 * @return The employee's name.
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * Set the name of the employee for the appointment.
	 * 
	 * @param employeeName
	 *            The employee's name.
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/**
	 * Get the ID of the hospital where the appointment is booked.
	 * 
	 * @return The hospital ID.
	 */
	public String getHospitalId() {
		return hospitalId;
	}

	/**
	 * Set the ID of the hospital where the appointment is booked.
	 * 
	 * @param hospitalId
	 *            The hospital ID.
	 */
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}

	/**
	 * Get the name of the hospital where the appointment is booked.
	 * 
	 * @return The hospital name.
	 */
	public String getHospitalName() {
		return hospitalName;
	}

	/**
	 * Set the name of the hospital where the appointment is booked.
	 * 
	 * @param hospitalName
	 *            The hospital name.
	 */
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	/**
	 * Get the address of the hospital where the appointment is booked.
	 * 
	 * @return The hospital address.
	 */
	public String getHospitalAddress() {
		return hospitalAddress;
	}

	/**
	 * Set the address of the hospital where the appointment is booked.
	 * 
	 * @param hospitalAddress
	 *            The hospital address.
	 */
	public void setHospitalAddress(String hospitalAddress) {
		this.hospitalAddress = hospitalAddress;
	}

	/**
	 * Get the name of the policy associated with the appointment.
	 * 
	 * @return The policy name.
	 */
	public String getPolicyName() {
		return policyName;
	}

	/**
	 * Set the name of the policy associated with the appointment.
	 * 
	 * @param policyName
	 *            The policy name.
	 */
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	/**
	 * Get the purpose of the appointment.
	 * 
	 * @return The appointment purpose.
	 */
	public String getPurpose() {
		return purpose;
	}

	/**
	 * Set the purpose of the appointment.
	 * 
	 * @param purpose
	 *            The appointment purpose.
	 */
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	/**
	 * Get the date of the appointment.
	 * 
	 * @return The appointment date.
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * Set the date of the appointment.
	 * 
	 * @param date
	 *            The appointment date.
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * Get the time slot of the appointment.
	 * 
	 * @return The time slot.
	 */
	public String getSlot() {
		return slot;
	}

	/**
	 * Set the time slot of the appointment.
	 * 
	 * @param slot
	 *            The time slot.
	 */
	public void setSlot(String slot) {
		this.slot = slot;
	}

	/**
	 * Get the email address of the employee for communication.
	 * 
	 * @return The email address.
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Set the email address of the employee for communication.
	 * 
	 * @param email
	 *            The email address.
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Get the current status of the appointment.
	 * 
	 * @return The appointment status.
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * Set the current status of the appointment.
	 * 
	 * @param status
	 *            The appointment status.
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * Get the health status information as binary data.
	 * 
	 * @return The health status data.
	 */
	public byte[] getHealthStatus() {
		return healthStatus;
	}

	/**
	 * Set the health status information as binary data.
	 * 
	 * @param healthStatus
	 *            The health status data.
	 */
	public void setHealthStatus(byte[] healthStatus) {
		this.healthStatus = healthStatus;
	}

	/**
	 * Get the date of discharge from the hospital.
	 * 
	 * @return The discharge date.
	 */
	public Date getDischargeDate() {
		return dischargeDate;
	}

	/**
	 * Set the date of discharge from the hospital.
	 * 
	 * @param dischargeDate
	 *            The discharge date.
	 */
	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	/**
	 * Returns a string representation of the AppointmentEO instance.
	 */
	@Override
	public String toString() {
		return "AppointmentEO [applicationId=" + applicationId + ", companyName=" + companyName + ", employeeId="
				+ employeeId + ", agencyName=" + agencyName + ", employeeName=" + employeeName + ", hospitalId="
				+ hospitalId + ", hospitalName=" + hospitalName + ", hospitalAddress=" + hospitalAddress
				+ ", policyName=" + policyName + ", purpose=" + purpose + ", date=" + date + ", slot=" + slot
				+ ", email=" + email + ", status=" + status + ", healthStatus=" + Arrays.toString(healthStatus)
				+ ", dischargeDate=" + dischargeDate + "]";
	}

}
