package HCE.HealthCheckForEmployees.Entity;

import org.springframework.data.annotation.Id;

/**
 * Class representing a policy with its name and description.
 * Author: Pavan Kumar Boyapati
 */

public class SetPolicy {
	
	// Name of the policy.
	private String policyName;
	
	// Description of the policy.
	private String policyDescription;

	/**
     * Default constructor.
     */
	
	public SetPolicy() {
		super();
	}

	/**
     * Parameterized constructor to initialize the SetPolicy object.
     *
     * @param policyName The name of the policy.
     * @param policyDescription The description of the policy.
     */
	
	public SetPolicy(String policyName, String policyDescription) {
		super();
		this.policyName = policyName;
		this.policyDescription = policyDescription;
	}


	/**
     * Get the name of the policy.
     *
     * @return The policy name.
     */
	public String getPolicyName() {
		return policyName;
	}

	/**
     * Set the name of the policy.
     *
     * @param policyName The policy name to set.
     */
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	/**
     * Get the description of the policy.
     *
     * @return The policy description.
     */
	public String getPolicyDescription() {
		return policyDescription;
	}

	/**
     * Set the description of the policy.
     *
     * @param policyDescription The policy description to set.
     */
	public void setPolicyDescription(String policyDescription) {
		this.policyDescription = policyDescription;
	}

	/**
     * Generate a string representation of the SetPolicy object.
     *
     * @return A string representation including policyName and policyDescription.
     */
	@Override
	public String toString() {
		return "SetPolicy [policyName=" + policyName + ", policyDescription=" + policyDescription + "]";
	}
	
	

}
