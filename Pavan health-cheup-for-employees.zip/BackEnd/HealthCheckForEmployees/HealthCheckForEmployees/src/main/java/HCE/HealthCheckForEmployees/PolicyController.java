package HCE.HealthCheckForEmployees;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import HCE.HealthCheckForEmployees.Entity.PolicyEO;
import HCE.HealthCheckForEmployees.Entity.SetPolicy;
import HCE.HealthCheckForEmployees.Service.PolicyService;

/**
 * RestController class for managing policies related operations.
 * Author: Pavan Kumar Boyapati
 */

@RestController
@RequestMapping("/Policy")
@CrossOrigin(origins = "http://localhost:3000")
public class PolicyController {

    @Autowired
    private PolicyService policyServiceRef;
    
    
    /**
     * Retrieves policies based on the provided role name and company name.
     *
     * @param policyEO The PolicyEO object containing role name and company name.
     * @return List of SetPolicy objects containing policy details if found, otherwise an empty list.
     */
    
    
    @RequestMapping(value="/getPolicies",method=RequestMethod.POST)
    public  List<SetPolicy> getPolicy(@RequestBody PolicyEO policyEO){
    	   	
    	 PolicyEO policyFromDB = policyServiceRef.findPolicyByRoleNameAndCompanyName(
                 policyEO.getRoleName(), policyEO.getCompanyName());
    	 return policyFromDB.getPolicy();
    	
    }
    
    /**
     * Sets policy for a specific role and company.
     *
     * @param policyEO The PolicyEO object containing role name, company name, and policy details.
     * @return ResponseEntity containing the updated policy details if updated,
     *         or the newly added policy details if added.
     */
    
    @RequestMapping(value = "/setPolicy", method = RequestMethod.POST)
    public ResponseEntity<PolicyEO> setPolicy(@RequestBody PolicyEO policyEO) {
        PolicyEO policyFromDB = policyServiceRef.findPolicyByRoleNameAndCompanyName(
                policyEO.getRoleName(), policyEO.getCompanyName());
        
        if (policyFromDB != null) {
        	List<SetPolicy> updatePolices =policyEO.getPolicy();
        	List<SetPolicy> existingPolicies = policyFromDB.getPolicy();
        	// Loop through updated policy to Update Existing or add new Policy
        	for(SetPolicy updatePolicy : updatePolices ){
        		boolean policyFound = false;
        		//Loop through existing policy to find update if policy matches
        		for(SetPolicy existingPolicy : existingPolicies){
        			if(existingPolicy.getPolicyName().equals(updatePolicy.getPolicyName())){
//        				update existing policy
        				existingPolicy.setPolicyName(updatePolicy.getPolicyName());
        				existingPolicy.setPolicyDescription(updatePolicy.getPolicyDescription());
        				policyFound =true;
        				break;
        			}
        		}
        		//if policy id Not Found
        		if(!policyFound){
//        			System.out.println("Adding to db" + existingPolicies.addAll(updatePolices));
        			existingPolicies.addAll(updatePolices);
//        			 return ResponseEntity.ok(updatePolices + "updated");
        			
        		}
        	}
        	
        	//save updated policy
        	
        	policyServiceRef.savePolicy(policyFromDB);
            return ResponseEntity.ok(policyFromDB);
        } 
        else {
        	policyServiceRef.addPolicy(policyEO);
        	System.out.println("Adding new Policy" + policyServiceRef.addPolicy(policyEO));
            return ResponseEntity.ok(policyEO);
        }
    }
}
        	
 