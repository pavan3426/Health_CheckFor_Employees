package HCE.HealthCheckForEmployees.Repository;

import org.springframework.stereotype.Repository;

import HCE.HealthCheckForEmployees.Entity.AgencyEO;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * Repository interface for accessing and managing AgencyEO objects in the database.
 * Author: Pavan Kumar Boyapati
 */

@Repository
public interface AgencyRepository extends MongoRepository <AgencyEO,String>{
	


}
