package HCE.HealthCheckForEmployees.Repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import HCE.HealthCheckForEmployees.Entity.EmployeeEO;
import HCE.HealthCheckForEmployees.Entity.PolicyEO;


/**
 * Repository interface for accessing and managing AgencyEO objects in the database.
 * Author: Pavan Kumar Boyapati
 */
@Repository
public interface EmployeeRepository extends  MongoRepository<EmployeeEO,String>{
	
	 /**
     * Retrieve distinct role names from the database.
     *
     * @return List of distinct role names.
     */
	
	
	 @Aggregation(pipeline = {
		        "{$group: {_id: '$roleName'}}",
		        "{$project: {roleName: '$_id', _id: 0}}"
		    })
   public List<String> findDistinctRoleNames();
	 
	 /**
	     * Retrieve all employees from the database.
	     *
	     * @return List of all EmployeeEO objects.
	     */
	public List<EmployeeEO> findAll();


	 /**
     * Retrieve an employee by company name and employee ID.
     *
     * @param companyName The name of the company associated with the employee.
     * @param employeeId The unique identifier of the employee.
     * @return An Optional containing the EmployeeEO if found, empty otherwise.
     */
	
	public Optional<EmployeeEO> findByCompanyNameAndEmployeeId( String companyName, String employeeId);
	 
	

	
	
	

}
