package HCE.HealthCheckForEmployees.Service;

import java.util.List;

import HCE.HealthCheckForEmployees.Entity.LoginEO;
/**
 * Service interface for managing user login details.
 * Author: Pavan Kumar Boyapati
 */

public interface LoginService {
	
	/**
     * Retrieve user login details based on the provided username and password.
     *
     * @param userName The username of the user.
     * @param password The password of the user.
     * @return The LoginEO object representing the user's login details, or null if not found.
     */
	 public LoginEO findByUserNameAndPassword(String userName, String password);

}
