package HCE.HealthCheckForEmployees.Entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Entity class representing an insurance agency's details.
 * Author: Pavan Kumar Boyapati
 */

@Document(collection="AGENCY")
public class AgencyEO {
	
	 // Name of the company associated with the agency.
	private String companyName;
	
	// Name of the agency.
	private String agencyName;
	
	 // Unique identifier for the insurance agency.
	@Id
	private String insuranceAgencyId;
	
	// Address of the agency.
	private String agencyAddress;

	/**
     * Default constructor.
     */
	
	public AgencyEO() {
		super();
	}
	
	 /**
     * Parameterized constructor to initialize the AgencyEO object.
     *
     * @param companyName The name of the company associated with the agency.
     * @param agencyName The name of the agency.
     * @param insuranceAgencyId The unique identifier for the insurance agency.
     * @param agencyAddress The address of the agency.
     */
	
	public AgencyEO(String companyName, String agencyName, String insuranceAgencyId, String agencyAddress) {
		super();
		this.companyName = companyName;
		this.agencyName = agencyName;
		this.insuranceAgencyId = insuranceAgencyId;
		this.agencyAddress = agencyAddress;
	}

	/**
     * Get the name of the company associated with the agency.
     *
     * @return The company name.
     */
	public String getCompanyName() {
		return companyName;
	}

	/**
     * Set the name of the company associated with the agency.
     *
     * @param companyName The company name to set.
     */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
     * Get the name of the agency.
     *
     * @return The agency name.
     */
	public String getAgencyName() {
		return agencyName;
	}

	/**
     * Set the name of the agency.
     *
     * @param agencyName The agency name to set.
     */
	public void setAgencyName(String agencyName) {
		this.agencyName = agencyName;
	}

	/**
     * Get the unique identifier for the insurance agency.
     *
     * @return The insurance agency's unique identifier.
     */
	public String getInsuranceAgencyId() {
		return insuranceAgencyId;
	}

	/**
     * Set the unique identifier for the insurance agency.
     *
     * @param insuranceAgencyId The unique identifier to set.
     */
	public void setInsuranceAgencyId(String insuranceAgencyId) {
		this.insuranceAgencyId = insuranceAgencyId;
	}

	/**
     * Get the address of the agency.
     *
     * @return The agency's address.
     */
	public String getAgencyAddress() {
		return agencyAddress;
	}

	/**
     * Set the address of the agency.
     *
     * @param agencyAddress The agency's address to set.
     */
	public void setAgencyAddress(String agencyAddress) {
		this.agencyAddress = agencyAddress;
	}

	/**
     * Generate a string representation of the AgencyEO object.
     *
     * @return A string representation including companyName, agencyName, insuranceAgencyId, and agencyAddress.
     */
	@Override
	public String toString() {
		return "AgencyEO [companyName=" + companyName + ", agencyName=" + agencyName + ", insuranceAgencyId="
				+ insuranceAgencyId + ", agencyAddress=" + agencyAddress + "]";
	}

	
	

}
