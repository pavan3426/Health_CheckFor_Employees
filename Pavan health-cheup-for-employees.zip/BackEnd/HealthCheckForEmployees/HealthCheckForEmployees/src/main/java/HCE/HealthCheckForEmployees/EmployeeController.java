package HCE.HealthCheckForEmployees;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import HCE.HealthCheckForEmployees.Entity.EmployeeEO;
import HCE.HealthCheckForEmployees.Repository.EmployeeRepository;
//import HCE.HealthCheckForEmployees.Entity.PolicyEO;
import HCE.HealthCheckForEmployees.Service.AgencyInterface;
import HCE.HealthCheckForEmployees.Service.EmployeeService;

/**
 * RestController class for managing employee-related endpoints.
 * Author: Pavan Kumar Boyapati
 */

@RestController
@RequestMapping("/Company")
@CrossOrigin(origins = "http://localhost:3000")
public class EmployeeController  {
	
	
	@Autowired
	private EmployeeService empServiceRef;
	
	@Autowired
	AgencyInterface agencyInterfaceRef;
	
	@Autowired
	EmployeeRepository empRepository;
	
	/**
     * Adds a new employee to the system.
     *
     * @param empEO The EmployeeEO object representing the employee to be added.
     * @return The added EmployeeEO object.
     * @throws Exception if an employee with the same ID already exists.
     */
	@RequestMapping(value="/addEmployee", method=RequestMethod.POST)
	@CrossOrigin()
	public EmployeeEO addNewEmployee(@RequestBody EmployeeEO empEO) throws Exception{
		Optional<EmployeeEO> emp = empRepository.findById(empEO.getEmployeeId());
		if(!emp.isPresent()){
		return empServiceRef.addEmployee(empEO);
		}
		else{
			 throw new Exception("Employee with ID " + empEO.getEmployeeId() + " already exists.");
		}

	}
	
	/**
     * Retrieves a list of distinct roles in the system.
     *
     * @return ResponseEntity containing the list of distinct roles or NO_CONTENT if empty.
     */
	
	@RequestMapping(value="/getAllRoles", method= RequestMethod.GET)

	 public ResponseEntity<List<String>> getDistinctRoles() {
        List<String> roles = empServiceRef.findRoleName();

        if (roles.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<>(roles, HttpStatus.OK);
    }
	
	 /**
     * Retrieves employee details based on company name and employee ID.
     *
     * @param empRef The EmployeeEO object containing company name and employee ID.
     * @return ResponseEntity containing the retrieved EmployeeEO object or NOT_FOUND if not found.
     */
	@PostMapping(value="/getEmployeeDetails")

	 public ResponseEntity<EmployeeEO> getEmployeeDetails(@RequestBody EmployeeEO empRef) {
       Optional<EmployeeEO> roles = empServiceRef.findByCompanyNameAndEmployeeId(empRef.getCompanyName(), empRef.getEmployeeId());
       

       if (roles.isPresent()) {
           return ResponseEntity.ok(roles.get());
       }

       return ResponseEntity.notFound().build();
   }
	
	 /**
     * Retrieves a list of all employees in the system.
     *
     * @return List of EmployeeEO objects.
     */
	@RequestMapping(value="/all", method=RequestMethod.GET)
	public List<EmployeeEO> all(){
		return empServiceRef.findAll();
	}
	
	 /**
     * Updates an existing employee in the system.
     *
     * @param employeeEO The EmployeeEO object representing the updated employee data.
     * @return The updated EmployeeEO object.
     */
	
	@RequestMapping(value = "/updateEmployee",method=RequestMethod.POST)
	@CrossOrigin()
	public EmployeeEO updateEmployee(@RequestBody EmployeeEO employeeEO){
//		System.out.println(employeeEO);
		return empServiceRef.updateEmployee(employeeEO);
	}
	
	 /**
     * Retrieves an employee's details based on employee ID.
     *
     * @param employeeEO The EmployeeEO object containing the employee ID.
     * @return Optional containing the retrieved EmployeeEO object or an empty Optional if not found.
     */
	@RequestMapping(value = "/getRoleById",method=RequestMethod.POST)
	@CrossOrigin()
	public Optional<EmployeeEO> getRoleById(@RequestBody EmployeeEO employeeEO){
		return empServiceRef.findById(employeeEO.getEmployeeId());
	}
	


	
	
	
	
}
