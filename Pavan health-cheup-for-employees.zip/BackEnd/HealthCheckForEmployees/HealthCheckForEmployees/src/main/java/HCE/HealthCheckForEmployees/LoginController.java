package HCE.HealthCheckForEmployees;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import HCE.HealthCheckForEmployees.Entity.LoginEO;
import HCE.HealthCheckForEmployees.Service.LoginService;

/**
 * RestController class for managing user login and retrieving role and organization information.
 * Author: Pavan Kumar Boyapati
 */

@RestController
@RequestMapping("/LoginPage")
@CrossOrigin(origins = "http://localhost:3000")

public class LoginController {

	
	@Autowired
	LoginService loginServiceRef;
	
	/**
     * Retrieves the user's role and organization based on the provided login credentials.
     *
     * @param loginEO The LoginEO object containing user's login credentials (userName and password).
     * @return ResponseEntity containing the user's role and organization if valid credentials,
     *         or NOT_FOUND if the credentials are invalid.
     */
	
	    @PostMapping("/getRoleAndOrganization")
	    public ResponseEntity<LoginEO> getRoleAndOrganization(@RequestBody LoginEO loginEO) {
	        String userName = loginEO.getUserName();
	        String password = loginEO.getPassword();
	        
	        LoginEO userDetails = loginServiceRef.findByUserNameAndPassword(userName, password);
	        
	        if (userDetails != null) {
	            LoginEO response = new LoginEO();
	            response.setRoleName(userDetails.getRoleName());
	            response.setOrganizationName(userDetails.getOrganizationName());
	            return ResponseEntity.ok(response);
	        } else {
	            return ResponseEntity.notFound().build();
	        }
	    }
	
	
}
