package HCE.HealthCheckForEmployees.Service;

import java.util.List;
import java.util.Optional;

import HCE.HealthCheckForEmployees.Entity.AgencyEO;

/**
 * Service interface for managing AgencyEO objects.
 * Author: Pavan Kumar Boyapati
 */

public interface AgencyInterface {
	
	/**
     * Add a new agency to the database.
     *
     * @param agencyEO The AgencyEO object representing the agency to be added.
     * @return The AgencyEO object representing the added agency.
     */
	
	public AgencyEO addAgency(AgencyEO agencyEO);
	

    /**
     * Retrieve a list of all agencies from the database.
     *
     * @return A list of AgencyEO objects representing all agencies.
     */
	
	public List<AgencyEO> getAll();
	
	/**
     * Update an existing agency in the database.
     *
     * @param agencyEO The AgencyEO object representing the updated agency information.
     * @return The AgencyEO object representing the updated agency.
     */
	
	public AgencyEO updateAgency(AgencyEO agencyEO);
	
}
