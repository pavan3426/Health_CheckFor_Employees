package HCE.HealthCheckForEmployees.Entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Entity class representing a policy associated with a company and role.
 * Author: Pavan Kumar Boyapati
 */

@Document(collection="POLICY")
public class PolicyEO {
	
	// Name of the company to which the policy is associated.	
	private String companyName;
	
	// Unique identifier for the role associated with the policy.
	@Id
	private String roleName;
	
	// List of policies associated with the role and company.
	private List<SetPolicy> policy;
	
	 /**
     * Default constructor.
     */
	public PolicyEO() {
		super();
	}

	/**
     * Parameterized constructor to initialize the PolicyEO object.
     *
     * @param companyName The name of the company.
     * @param roleName The name of the role.
     * @param policy The list of policies associated with the role and company.
     */
	public PolicyEO(String companyName, String roleName, List<SetPolicy> policy) {
		super();
		this.companyName = companyName;
		this.roleName = roleName;
		this.policy = policy;
	}


	/**
     * Get the name of the company to which the policy is associated.
     *
     * @return The company name.
     */
	public String getCompanyName() {
		return companyName;
	}

	/**
     * Set the name of the company to which the policy is associated.
     *
     * @param companyName The company name to set.
     */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
     * Get the unique identifier for the role associated with the policy.
     *
     * @return The role name.
     */
	public String getRoleName() {
		return roleName;
	}

	/**
     * Set the unique identifier for the role associated with the policy.
     *
     * @param roleName The role name to set.
     */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	/**
     * Get the list of policies associated with the role and company.
     *
     * @return The list of policies.
     */
	public List<SetPolicy> getPolicy() {
		return policy;
	}

	/**
     * Set the list of policies associated with the role and company.
     *
     * @param policy The list of policies to set.
     */
	public void setPolicy(List<SetPolicy> policy) {
		this.policy = policy;
	}

	/**
     * Generate a string representation of the PolicyEO object.
     *
     * @return A string representation including companyName, roleName, and policy.
     */
	@Override
	public String toString() {
		return "PolicyEO [companyName=" + companyName + ", roleName=" + roleName + ", policy=" + policy + "]";
	}
	

}
