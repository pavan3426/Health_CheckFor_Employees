package HCE.HealthCheckForEmployees.Service;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import HCE.HealthCheckForEmployees.Entity.EmployeeEO;
import HCE.HealthCheckForEmployees.Entity.PolicyEO;


/**
 * Service interface for managing EmployeeEO objects.
 * Author: Pavan Kumar Boyapati
 */

public interface EmployeeService {
	

    /**
     * Add a new employee to the database.
     *
     * @param empRef The EmployeeEO object representing the employee to be added.
     * @return The EmployeeEO object representing the added employee.
     */
	
	public EmployeeEO addEmployee(EmployeeEO empRef);
	
	 /**
     * Retrieve a list of distinct role names from the database.
     *
     * @return A list of strings representing distinct role names.
     */
	
	public List<String> findRoleName();
	
	 /**
     * Retrieve a list of all employees from the database.
     *
     * @return A list of EmployeeEO objects representing all employees.
     */
	
	public List<EmployeeEO> findAll();
	
	/**
     * Update an existing employee in the database.
     *
     * @param employeeEO The EmployeeEO object representing the updated employee information.
     * @return The EmployeeEO object representing the updated employee.
     */
	
	public EmployeeEO updateEmployee(EmployeeEO employeeEO);
	
	 /**
     * Retrieve an employee by their unique identifier.
     *
     * @param id The unique identifier of the employee.
     * @return An optional containing the EmployeeEO object if found, or empty if not found.
     */
	
	public Optional<EmployeeEO> findById(String id);
	
	 /**
     * Retrieve an employee by their company name and employee ID.
     *
     * @param companyName The name of the company associated with the employee.
     * @param employeeId The unique identifier of the employee.
     * @return An optional containing the EmployeeEO object if found, or empty if not found.
     */
	
	public Optional<EmployeeEO> findByCompanyNameAndEmployeeId(String companyName, String employeeId);
	
	
	

}
