package HCE.HealthCheckForEmployees.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import HCE.HealthCheckForEmployees.Entity.PolicyEO;
import HCE.HealthCheckForEmployees.Repository.PolicyRepository;
import HCE.HealthCheckForEmployees.Service.PolicyService;

/**
 * Implementation class for the PolicyService service.
 * Author: Pavan Kumar Boyapati
 */
@Service
public class PolicyServiceimpl implements PolicyService {

	@Autowired
	private PolicyRepository policyRepository;

	/**
	 * Retrieve a policy by its role name and company name.
	 *
	 * @param roleName     The role name associated with the policy.
	 * @param companyName The company name associated with the policy.
	 * @return The PolicyEO object representing the policy if found, or null if not.
	 */
	public PolicyEO findPolicyByRoleNameAndCompanyName(String roleName, String companyName) {
		return policyRepository.findByRoleNameAndCompanyName(roleName, companyName);
	}

	/**
	 * Update a policy in the database.
	 *
	 * @param policy The PolicyEO object representing the policy to be updated.
	 * @return The updated PolicyEO object.
	 */
	@Override
	public PolicyEO updatePolicy(PolicyEO policy) {
		return policyRepository.save(policy);
	}

	/**
	 * Add a new policy to the database.
	 *
	 * @param policy The PolicyEO object representing the policy to be added.
	 * @return The added PolicyEO object.
	 */
	@Override
	public PolicyEO addPolicy(PolicyEO policy) {
		return policyRepository.save(policy);
	}

	/**
	 * Save an existing policy in the database.
	 *
	 * @param existingPolicy The PolicyEO object representing the existing policy to be saved.
	 * @return The saved PolicyEO object.
	 */
	@Override
	public PolicyEO savePolicy(PolicyEO existingPolicy) {
		return policyRepository.save(existingPolicy);
	}
}





