package HCE.HealthCheckForEmployees.Entity;

import org.springframework.data.mongodb.core.mapping.Document;


/**
 * Entity class representing login details of a user.
 * Author: Pavan Kumar Boyapati
 */

@Document(collection="LOGINPAGE")

public class LoginEO {
	
	// Username of the user.
	private  String userName;
	
	// Password of the user.
	private String password;
	
	// Role name associated with the user.
	private String roleName;
	
	 // Organization name associated with the user.
	private String organizationName;

	/**
     * Default constructor.
     */
	
	public LoginEO() {
		super();
	}

	/**
     * Parameterized constructor to initialize the LoginEO object.
     *
     * @param userName The username of the user.
     * @param password The password of the user.
     * @param roleName The role name associated with the user.
     * @param organizationName The organization name associated with the user.
     */
	
	public LoginEO(String userName, String password, String roleName, String organizationName) {
		super();
		this.userName = userName;
		this.password = password;
		this.roleName = roleName;
		this.organizationName = organizationName;
	}


	/**
     * Get the username of the user.
     *
     * @return The username.
     */
	public String getUserName() {
		return userName;
	}

	/**
     * Set the username of the user.
     *
     * @param userName The username to set.
     */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
     * Get the password of the user.
     *
     * @return The password.
     */
	public String getPassword() {
		return password;
	}

	/**
     * Set the password of the user.
     *
     * @param password The password to set.
     */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
     * Get the role name associated with the user.
     *
     * @return The role name.
     */
	public String getRoleName() {
		return roleName;
	}

	/**
     * Set the role name associated with the user.
     *
     * @param roleName The role name to set.
     */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	/**
     * Get the organization name associated with the user.
     *
     * @return The organization name.
     */
	public String getOrganizationName() {
		return organizationName;
	}

	/**
     * Set the organization name associated with the user.
     *
     * @param organizationName The organization name to set.
     */
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	/**
     * Generate a string representation of the LoginEO object.
     *
     * @return A string representation including userName, password, roleName, and organizationName.
     */
	@Override
	public String toString() {
		return "LoginEO [userName=" + userName + ", password=" + password + ", roleName=" + roleName
				+ ", organizationName=" + organizationName + "]";
	}	
	

}
