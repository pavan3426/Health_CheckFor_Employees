package HCE.HealthCheckForEmployees.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import HCE.HealthCheckForEmployees.Entity.AgencyEO;
import HCE.HealthCheckForEmployees.Repository.AgencyRepository;
import HCE.HealthCheckForEmployees.Service.AgencyInterface;

/**
 * Implementation class for the AgencyInterface service.
 * Author: Pavan Kumar Boyapati
 */

@Service
public class AgencyInterfaceImpl implements AgencyInterface {
	
	@Autowired
	AgencyRepository agencyRepository;
	

    /**
     * Add a new agency.
     *
     * @param agencyEO The AgencyEO object containing the details of the new agency.
     * @return The added AgencyEO object.
     */
	
	@Override
	public AgencyEO addAgency(AgencyEO agencyEO) {
		
		System.out.println(agencyEO);
		
		return agencyRepository.save(agencyEO) ;
	}

	 /**
     * Retrieve a list of all agencies.
     *
     * @return A list of AgencyEO objects representing all agencies.
     */
	
	@Override
	public List<AgencyEO> getAll() {
		// TODO Auto-generated method stub
		return agencyRepository.findAll();
	}
	/**
     * Update an existing agency.
     *
     * @param agencyEO The AgencyEO object containing the updated agency details.
     * @return The updated AgencyEO object.
     */
	
	@Override
	public AgencyEO updateAgency(AgencyEO agencyEO) {
		return agencyRepository.save(agencyEO);
	}


}
