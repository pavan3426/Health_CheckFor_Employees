package HCE.HealthCheckForEmployees.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import HCE.HealthCheckForEmployees.Entity.PolicyEO;

/**
 * Repository interface for accessing and managing PolicyEO objects in the database.
 * Author: Pavan Kumar Boyapati
 */

@Repository
public interface PolicyRepository extends MongoRepository<PolicyEO,String> {
	
	/**
     * Retrieve a policy by its role name.
     *
     * @param roleName The role name associated with the policy.
     * @return The PolicyEO object representing the retrieved policy.
     */
	
	 PolicyEO findByRoleName(String roleName);


	    /**
	     * Retrieve a policy by its role name and company name.
	     *
	     * @param roleName The role name associated with the policy.
	     * @param companyName The company name associated with the policy.
	     * @return The PolicyEO object representing the retrieved policy.
	     */
	 
    PolicyEO findByRoleNameAndCompanyName(String roleName, String companyName);

}
