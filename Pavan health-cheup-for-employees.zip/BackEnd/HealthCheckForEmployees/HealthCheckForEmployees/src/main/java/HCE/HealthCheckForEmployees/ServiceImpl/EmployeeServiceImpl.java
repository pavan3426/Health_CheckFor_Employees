package HCE.HealthCheckForEmployees.ServiceImpl;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import HCE.HealthCheckForEmployees.Entity.EmployeeEO;
//import HCE.HealthCheckForEmployees.Entity.PolicyEO;
import HCE.HealthCheckForEmployees.Repository.EmployeeRepository;
import HCE.HealthCheckForEmployees.Service.EmployeeService;

/**
 * Implementation class for the EmployeeService service.
 * Author: Pavan Kumar Boyapati
 */

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepository empRepositoryRef;

	/**
     * Add a new employee.
     *
     * @param empRef The EmployeeEO object containing the details of the new employee.
     * @return The added EmployeeEO object.
     */
	
	@Override
	public EmployeeEO addEmployee(EmployeeEO empRef) {
		// TODO Auto-generated method stub
		return empRepositoryRef.save(empRef);
		
	}
	
	/**
     * Retrieve distinct role names.
     *
     * @return A list of distinct role names.
     */
	
	@Override
	public List<String> findRoleName() {
		// TODO Auto-generated method stub
		return empRepositoryRef.findDistinctRoleNames();
	}

	/**
     * Retrieve a list of all employees.
     *
     * @return A list of EmployeeEO objects representing all employees.
     */

	@Override
	public List<EmployeeEO> findAll() {
		// TODO Auto-generated method stub
//		System.out.println( empRepositoryRef.findAll());
		return  empRepositoryRef.findAll();
	}

	/**
     * Update an existing employee.
     *
     * @param employeeEO The EmployeeEO object containing the updated employee details.
     * @return The updated EmployeeEO object.
     */
	
	@Override
	public EmployeeEO updateEmployee(EmployeeEO employeeEO) {
		// TODO Auto-generated method stub
		return empRepositoryRef.save(employeeEO);
	}
	/**
     * Retrieve an employee by ID.
     *
     * @param id The ID of the employee.
     * @return An Optional containing the EmployeeEO object if found, or empty if not.
     */
	
	@Override
	public Optional<EmployeeEO> findById(String id) {
		// TODO Auto-generated method stub
		return empRepositoryRef.findById(id) ;
	}

	/**
     * Retrieve an employee by company name and employee ID.
     *
     * @param companyName The name of the company associated with the employee.
     * @param employeeId The ID of the employee.
     * @return An Optional containing the EmployeeEO object if found, or empty if not.
     */
	
	@Override
	public Optional<EmployeeEO> findByCompanyNameAndEmployeeId(String companyName, String employeeId) {
		// TODO Auto-generated method stub
		return empRepositoryRef.findByCompanyNameAndEmployeeId(companyName, employeeId);
	}
	



}
