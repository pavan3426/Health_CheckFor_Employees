package HCE.HealthCheckForEmployees;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import HCE.HealthCheckForEmployees.Entity.AgencyEO;
import HCE.HealthCheckForEmployees.Service.AgencyInterface;

/**
 * RestController class for managing agency-related endpoints.
 * Author: Pavan Kumar Boyapati
 */

@RestController
@RequestMapping("/Agency")
@CrossOrigin(origins = "http://localhost:3000")
public class AgencyController {
	
	@Autowired
	AgencyInterface agencyInterfaceRef;
	
	/**
     * Endpoint to add a new agency.
     *
     * @param agencyEO The AgencyEO object containing agency details.
     * @return ResponseEntity with a message indicating success or failure.
     */
	
	@RequestMapping(value="/addAgency", method=RequestMethod.POST)
	@CrossOrigin()
	public ResponseEntity<String> addNewAgency(@RequestBody AgencyEO agencyEO) {
	    AgencyEO addedAgency = agencyInterfaceRef.addAgency(agencyEO);

	    if (addedAgency != null) {
	        return new ResponseEntity<>("Agency added successfully", HttpStatus.CREATED);
	    } else {
	        return new ResponseEntity<>("Failed to add agency", HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}
	

	/**
     * Endpoint to retrieve all agencies.
     *
     * @return List of AgencyEO objects representing all agencies.
     */

	@RequestMapping(value="/getAll" , method= RequestMethod.GET)
	@CrossOrigin()
	public List<AgencyEO> findAll(){
		return agencyInterfaceRef.getAll();
	}
	
	/**
     * Endpoint to update an existing agency.
     *
     * @param agencyEO The updated AgencyEO object.
     * @return ResponseEntity with a message indicating success or failure.
     */
	
	@RequestMapping(value = "/updateAgency", method = RequestMethod.POST)
	@CrossOrigin(origins = "http://localhost:3000") // Allow requests from your frontend
	public ResponseEntity<String> updateAgency(@RequestBody AgencyEO agencyEO) {
	    AgencyEO updateAgency = agencyInterfaceRef.updateAgency(agencyEO);

	    if (updateAgency != null) {
	        return ResponseEntity.ok("Updated Successfully");
	    } else {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to Update");
	    }
	}


}
