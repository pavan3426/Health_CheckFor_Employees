package HCE.HealthCheckForEmployees.Service;

import HCE.HealthCheckForEmployees.Entity.PolicyEO;

/**
 * Service interface for managing policy-related operations.
 * Author: Pavan Kumar Boyapati
 */

public interface PolicyService {
	
	/**
     * Retrieve the policy associated with a specific role and company.
     *
     * @param roleName The name of the role.
     * @param companyName The name of the company.
     * @return The PolicyEO object representing the policy details, or null if not found.
     */
	public PolicyEO findPolicyByRoleNameAndCompanyName(String roleName, String companyName);

	 /**
     * Update an existing policy.
     *
     * @param policy The PolicyEO object containing the updated policy details.
     * @return The updated PolicyEO object.
     */
	
	public PolicyEO updatePolicy(PolicyEO policy) ;

	 /**
     * Add a new policy.
     *
     * @param policy The PolicyEO object containing the new policy details.
     * @return The added PolicyEO object.
     */
	
	public PolicyEO addPolicy(PolicyEO policy) ;
	    
	/**
     * Save an existing policy.
     *
     * @param existingPolicy The PolicyEO object containing the existing policy details to be saved.
     * @return The saved PolicyEO object.
     */
	
	public PolicyEO savePolicy(PolicyEO existingPolicy);


}
