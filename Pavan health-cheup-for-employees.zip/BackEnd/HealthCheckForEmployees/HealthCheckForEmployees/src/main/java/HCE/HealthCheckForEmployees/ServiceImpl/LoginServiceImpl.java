package HCE.HealthCheckForEmployees.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import HCE.HealthCheckForEmployees.Entity.LoginEO;
import HCE.HealthCheckForEmployees.Repository.LoginRepository;
import HCE.HealthCheckForEmployees.Service.LoginService;

/**
 * Implementation class for the LoginService service.
 * Author: Pavan Kumar Boyapati
 */
@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
    private LoginRepository loginRepository;

    /**
     * Retrieve a user's login details by username and password.
     *
     * @param userName The username of the user.
     * @param password The password of the user.
     * @return The LoginEO object representing the user's login details if found, or null if not.
     */
    public LoginEO findByUserNameAndPassword(String userName, String password) {
        return loginRepository.findByUserNameAndPassword(userName, password);
    }
}
