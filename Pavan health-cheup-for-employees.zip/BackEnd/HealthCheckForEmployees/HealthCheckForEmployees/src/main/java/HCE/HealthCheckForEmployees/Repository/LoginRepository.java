package HCE.HealthCheckForEmployees.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import HCE.HealthCheckForEmployees.Entity.LoginEO;

/**
 * Repository interface for accessing and managing LoginEO objects in the database.
 * Author: Pavan Kumar Boyapati
 */

public interface LoginRepository extends MongoRepository<LoginEO,String> {

	
	/**
     * Retrieve a user's login details by username and password.
     *
     * @param userName The username of the user.
     * @param password The password of the user.
     * @return The LoginEO object representing the user's login details.
     */
	
	public LoginEO findByUserNameAndPassword(String userName, String password);
                                                
}
