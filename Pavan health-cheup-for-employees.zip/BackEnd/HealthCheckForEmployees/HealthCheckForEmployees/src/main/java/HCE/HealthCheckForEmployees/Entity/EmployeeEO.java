package HCE.HealthCheckForEmployees.Entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
/**
 * Entity class representing an employee's details.
 * Author: Pavan Kumar Boyapati
 */
@Document(collection="COMPANY")
public class EmployeeEO {
	
	// Name of the company associated with the employee.
	private String companyName;
		
	    // Unique identifier for the employee.
	@Id
	private String employeeId;
		
	    // Name of the employee.
		private String employeeName;
		
	    // Role of the employee.
		private String roleName;
		
	    // Contact number of the employee.
		private String contactNumber;
		
	    // Aadhar number of the employee.
		private String aadharNumber;
		
	    // Permanent address of the employee.
		private String permanentAddress;
		
	    // Temporary address of the employee.
		private String temporaryAddress;
	
	
	

	/**
     * Default constructor.
     */
	
	public EmployeeEO() {
		super();
	}

	/**
     * Parameterized constructor to initialize the EmployeeEO object.
     *
     * @param companyName The name of the company associated with the employee.
     * @param employeeId The unique identifier for the employee.
     * @param employeeName The name of the employee.
     * @param roleName The role of the employee.
     * @param contactNumber The contact number of the employee.
     * @param aadharNumber The Aadhar number of the employee.
     * @param permanentAddress The permanent address of the employee.
     * @param temporaryAddress The temporary address of the employee.
     */
	
	public EmployeeEO(String companyName, String employeeId, String employeeName, String roleName, String contactNumber,
			String aadharNumber, String permanentAddress, String temporaryAddress) {
		super();
		this.companyName = companyName;
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.roleName = roleName;
		this.contactNumber = contactNumber;
		this.aadharNumber = aadharNumber;
		this.permanentAddress = permanentAddress;
		this.temporaryAddress = temporaryAddress;
	}

	/**
     * Get the name of the company associated with the employee.
     *
     * @return The company name.
     */
	public String getCompanyName() {
		return companyName;
	}

	/**
     * Set the name of the company associated with the employee.
     *
     * @param companyName The company name to set.
     */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
     * Get the unique identifier for the employee.
     *
     * @return The employee's unique identifier.
     */
	public String getEmployeeId() {
		return employeeId;
	}

	/**
     * Set the unique identifier for the employee.
     *
     * @param employeeId The unique identifier to set.
     */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
     * Get the name of the employee.
     *
     * @return The employee's name.
     */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
     * Set the name of the employee.
     *
     * @param employeeName The employee's name to set.
     */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/**
     * Get the role of the employee.
     *
     * @return The employee's role.
     */
	public String getRoleName() {
		return roleName;
	}

	/**
     * Set the role of the employee.
     *
     * @param roleName The employee's role to set.
     */
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	/**
     * Get the contact number of the employee.
     *
     * @return The employee's contact number.
     */
	public String getContactNumber() {
		return contactNumber;
	}

	/**
     * Set the contact number of the employee.
     *
     * @param contactNumber The employee's contact number to set.
     */
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	/**
     * Get the Aadhar number of the employee.
     *
     * @return The employee's Aadhar number.
     */
	public String getAadharNumber() {
		return aadharNumber;
	}

	/**
     * Set the Aadhar number of the employee.
     *
     * @param aadharNumber The employee's Aadhar number to set.
     */
	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	/**
     * Get the permanent address of the employee.
     *
     * @return The employee's permanent address.
     */
	public String getPermanentAddress() {
		return permanentAddress;
	}

	/**
     * Set the permanent address of the employee.
     *
     * @param permanentAddress The employee's permanent address to set.
     */
	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	/**
     * Get the temporary address of the employee.
     *
     * @return The employee's temporary address.
     */
	public String getTemporaryAddress() {
		return temporaryAddress;
	}

	/**
     * Set the temporary address of the employee.
     *
     * @param temporaryAddress The employee's temporary address to set.
     */
	public void setTemporaryAddress(String temporaryAddress) {
		this.temporaryAddress = temporaryAddress;
	}

	/**
     * Generate a string representation of the EmployeeEO object.
     *
     * @return A string representation including companyName, employeeId, employeeName, roleName, contactNumber, aadharNumber, permanentAddress, and temporaryAddress.
     */
	@Override
	public String toString() {
		return "EmployeeEO [companyName=" + companyName + ", employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", roleName=" + roleName + ", contactNumber=" + contactNumber + ", aadharNumber="
				+ aadharNumber + ", permanentAddress=" + permanentAddress + ", temporaryAddress=" + temporaryAddress
				+ "]";
	}



	
	

}
