package HCE.Agency.Entity;

import org.springframework.data.annotation.Id;

/**
 * Entity class representing partner hospitals associated with agencies.
 * Author: Pavan Kumar Boyapati
 */
public class PartnerEO {
	
	 /*
     * Unique identifier for the partner hospital.
     */
	   @Id
	private String hospitalId;
	
	   /*
	     * Name of the partner hospital.
	     */
	private String hospitalName;
	
	/*
     * Address of the partner hospital.
     */
	private String hospitalAddress;

	/**
     * Default constructor.
     */
	public PartnerEO() {
		super();
	}

	   /**
     * Parameterized constructor to initialize the PartnerEO object.
     *
     * @param hospitalId       The unique identifier for the partner hospital.
     * @param hospitalName     The name of the partner hospital.
     * @param hospitalAddress  The address of the partner hospital.
     */
	public PartnerEO(String hospitalId, String hospitalName, String hospitalAddress) {
		super();
		this.hospitalId = hospitalId;
		this.hospitalName = hospitalName;
		this.hospitalAddress = hospitalAddress;
	}

	 /*
     * Get the partner hospital's unique identifier.
     *
     * @return The partner hospital's unique identifier.
     */
    public String getHospitalId() {
        return hospitalId;
    }

    /*
     * Set the partner hospital's unique identifier.
     *
     * @param hospitalId The unique identifier to set.
     */
    public void setHospitalId(String hospitalId) {
        this.hospitalId = hospitalId;
    }

    /*
     * Get the partner hospital's name.
     *
     * @return The partner hospital's name.
     */
    public String getHospitalName() {
        return hospitalName;
    }

    /*
     * Set the partner hospital's name.
     *
     * @param hospitalName The name to set.
     */
    public void setHospitalName(String hospitalName) {
        this.hospitalName = hospitalName;
    }

    /*
     * Get the partner hospital's address.
     *
     * @return The partner hospital's address.
     */
    public String getHospitalAddress() {
        return hospitalAddress;
    }

    /*
     * Set the partner hospital's address.
     *
     * @param hospitalAddress The address to set.
     */
    public void setHospitalAddress(String hospitalAddress) {
        this.hospitalAddress = hospitalAddress;
    }

    /*
     * Generate a string representation of the PartnerEO object.
     *
     * @return A string representation including hospitalId, hospitalName, and hospitalAddress.
     */
    @Override
    public String toString() {
        return "PartnerEO [hospitalId=" + hospitalId + ", hospitalName=" + hospitalName + ", hospitalAddress="
                + hospitalAddress + "]";
    }
	    
	    
}
