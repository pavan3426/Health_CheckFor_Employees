package HCE.Agency.Entity;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Entity class representing insurance agencies and their partners.
 * Author: Pavan Kumar Boyapati
 */
@Document(collection = "INSURANCRAGENCY")
public class AgencyEO {
	
	/*
     * Unique identifier for the agency.
     */
	    @Id
	    private String id;

	    /*
	     * Name of the agency.
	     */
	    private String agencyName;
	    
	    /*
	     * List of partners associated with the agency.
	     */
	    private List<PartnerEO> partners;

	    
	    /**
	     * Default constructor.
	     */
	    public AgencyEO() {
			super();
		}
	    

	    /**
	     * Parameterized constructor to initialize the AgencyEO object.
	     *
	     * @param id          The unique identifier for the agency.
	     * @param agencyName  The name of the agency.
	     * @param partners    List of partners associated with the agency.
	     */
		public AgencyEO(String id, String agencyName, List<PartnerEO> partners) {
			super();
			this.id = id;
			this.agencyName = agencyName;
			this.partners = partners;
		}

		/*
	     * Get the agency's unique identifier.
	     *
	     * @return The agency's unique identifier.
	     */
	    public String getId() {
	        return id;
	    }

	    /*
	     * Set the agency's unique identifier.
	     *
	     * @param id The unique identifier to set.
	     */
	    public void setId(String id) {
	        this.id = id;
	    }

	    /*
	     * Get the agency's name.
	     *
	     * @return The agency's name.
	     */
	    public String getAgencyName() {
	        return agencyName;
	    }

	    /*
	     * Set the agency's name.
	     *
	     * @param agencyName The name to set.
	     */
	    public void setAgencyName(String agencyName) {
	        this.agencyName = agencyName;
	    }

	    /*
	     * Get the list of partners associated with the agency.
	     *
	     * @return The list of partners.
	     */
	    public List<PartnerEO> getPartners() {
	        return partners;
	    }

	    /*
	     * Set the list of partners associated with the agency.
	     *
	     * @param partners The list of partners to set.
	     */
	    public void setPartners(List<PartnerEO> partners) {
	        this.partners = partners;
	    }

	    /*
	     * Generate a string representation of the AgencyEO object.
	     *
	     * @return A string representation including id, agencyName, and partners.
	     */
	    @Override
	    public String toString() {
	        return "AgencyEO [id=" + id + ", agencyName=" + agencyName + ", partners=" + partners + "]";
	    }
	}

