package HCE.Agency.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import HCE.Agency.Entity.AgencyEO;

/**
 * Spring Data MongoDB repository for AgencyEO entities.
  * Author: Pavan Kumar Boyapati
 */
public interface AgencyRepository extends MongoRepository<AgencyEO,String> {


	

}
