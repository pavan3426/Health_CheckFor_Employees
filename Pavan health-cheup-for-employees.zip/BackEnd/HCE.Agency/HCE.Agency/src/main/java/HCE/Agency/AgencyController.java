package HCE.Agency;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import HCE.Agency.Entity.AgencyEO;
import HCE.Agency.Entity.PartnerEO;
import HCE.Agency.Service.AgencyService;

/**
 * Controller class for handling agency-related operations.
 * Author: Pavan Kumar Boyapati
 */

@RestController
@RequestMapping("/Agency")
@CrossOrigin(origins = "http://localhost:3000") // Adjust origin as needed
public class AgencyController {

    @Autowired
    private AgencyService agencyService;

    /**
     * Update or add an agency along with its partners.
     *
     * @param agencyEO The agency entity containing the updated information.
     * @return ResponseEntity containing the updated or added agency entity.
     */
    
   @RequestMapping(value = "/setAgency", method = RequestMethod.POST)
    public ResponseEntity<AgencyEO> updateAgency(@RequestBody AgencyEO agencyEO) {
        AgencyEO existingAgency = agencyService.findAgencyById(agencyEO.getId());
        if (existingAgency != null) {
            List<PartnerEO> updatedPartners = agencyEO.getPartners();
            List<PartnerEO> existingPartners = existingAgency.getPartners();

            // Loop through the updated partners to update existing or add new partners
            for (PartnerEO updatedPartner : updatedPartners) {
                boolean partnerFound = false;

                // Loop through the existing partners to find and update if partner ID matches
                for (PartnerEO existingPartner : existingPartners) {
                    if (existingPartner.getHospitalId().equals(updatedPartner.getHospitalId())) {
                        // Update existing partner data
                        existingPartner.setHospitalName(updatedPartner.getHospitalName());
                        existingPartner.setHospitalAddress(updatedPartner.getHospitalAddress());
                        partnerFound = true;
                        break;
                    }
                }

                // If partner ID not found, add new partner
                if (!partnerFound) {
                    existingPartners.add(updatedPartner);
                }
            }

            // Save the updated agency
            agencyService.saveAgency(existingAgency);
            

            return ResponseEntity.ok(existingAgency);
        } else {
        	agencyService.addPartnerToAgency(agencyEO);
            return ResponseEntity.ok(agencyEO);
        }
    }
   
   /**
    * Retrieve hospitals associated with an agency.
    *
    * @param agencyEO The agency entity containing the agency name.
    * @return An Optional containing the agency entity with associated hospitals.
    */
   
   @RequestMapping(value = "/getHospitals", method = RequestMethod.POST)
   public Optional<AgencyEO> getHospitals(@RequestBody AgencyEO agencyEO){
	   String agencyName= agencyEO.getAgencyName();
	   	return agencyService.getHospital(agencyName);

	   
   }
   
   /**
    * Retrieve partnered hospitals for an agency.
    *
    * @param agencyEO The agency entity containing the agency ID.
    * @return The agency entity with partnered hospitals.
    */
   
   @RequestMapping(value="getPartners",method =RequestMethod.POST)
   public AgencyEO getPartneredHospitals (@RequestBody AgencyEO agencyEO){
	   
	 return agencyService.findAgencyById(agencyEO.getId());
   }


}
