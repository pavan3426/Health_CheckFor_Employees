package HCE.Agency.Service;

import java.util.Optional;

import HCE.Agency.Entity.AgencyEO;
import HCE.Agency.Entity.PartnerEO;

/**
 * Service interface for managing agency-related operations.
 * Author: Pavan Kumar Boyapati
 */

public interface AgencyService {
	
	 /**
     * Add partner information to an existing agency.
     *
     * @param agencyEO The agency entity to which a partner is to be added.
     * @return The agency entity after adding the partner.
     */
	 AgencyEO addPartnerToAgency(AgencyEO agencyEO);
	 
	 /**
	     * Find an agency by its unique identifier.
	     *
	     * @param agencyId The unique identifier of the agency.
	     * @return The agency entity if found, otherwise null.
	     */
	 public AgencyEO findAgencyById(String agencyId);
	 
	 /**
	     * Save/update an agency entity.
	     *
	     * @param agency The agency entity to be saved/updated.
	     * @return The saved/updated agency entity.
	     */
	 	 public AgencyEO saveAgency(AgencyEO agency);
	 	 
	 	/**
	      * Retrieve an agency along with associated hospitals based on agency name.
	      *
	      * @param agencyname The name of the agency.
	      * @return An Optional containing the agency entity with associated hospitals.
	      */
	 	 public Optional<AgencyEO> getHospital(String agencyname);
	 

}
