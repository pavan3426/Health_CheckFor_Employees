package HCE.Agency.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.data.mongodb.core.MongoTemplate;
import HCE.Agency.Entity.AgencyEO;
import HCE.Agency.Entity.PartnerEO;
import HCE.Agency.Repository.AgencyRepository;
import HCE.Agency.Service.AgencyService;

/**
 * Implementation of the AgencyService interface.
 * Author: Pavan Kumar Boyapati
 */

@Service
public class AgencyServiceImpl implements AgencyService {
	 @Autowired
	    private AgencyRepository agencyRepository;

	   
	 /**
	     * Add partner information to an existing agency.
	     *
	     * @param agency The agency entity to which a partner is to be added.
	     * @return The agency entity after adding the partner.
	     */
	 
	    @Override
	    public AgencyEO addPartnerToAgency(AgencyEO agency) {
	           
	            return agencyRepository.save(agency);
	    }

	    /**
	     * Find an agency by its unique identifier.
	     *
	     * @param agencyId The unique identifier of the agency.
	     * @return The agency entity if found, otherwise null.
	     */
		@Override
		 public AgencyEO findAgencyById(String agencyId) {
	        // Implement your logic to find an agency by ID from the repository
	        return agencyRepository.findById(agencyId).orElse(null);
	    }
		
		 /**
	     * Save/update an agency entity.
	     *
	     * @param agency The agency entity to be saved/updated.
	     * @return The saved/updated agency entity.
	     */
		@Override
		public AgencyEO saveAgency(AgencyEO agency) {
	        // Implement your logic to save an agency to the repository
	        return agencyRepository.save(agency);
	    }
		
		/**
	     * Retrieve an agency along with associated hospitals based on agency name.
	     *
	     * @param agencyname The name of the agency.
	     * @return An Optional containing the agency entity with associated hospitals.
	     */
		@Override
		public Optional<AgencyEO> getHospital(String agencyname) {
			List<AgencyEO> agencyEOList = agencyRepository.findAll();
			
			Optional<AgencyEO> matchingAgency = agencyEOList.stream()
		            .filter(agency -> agency.getAgencyName().equalsIgnoreCase(agencyname))
		            .findFirst();
		    
		    return matchingAgency;
		}

		
	
		
}
